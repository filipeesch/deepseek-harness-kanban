import type { DiscoveryFs } from './filesystem.js';
import type { DiscoveryEvidence } from './mounts.js';
import type { SharingCommandRunner } from '../command-runner.js';
export interface MacosAdapterOptions {
    home: string;
    fs: DiscoveryFs;
    runner: SharingCommandRunner;
}
/**
 * macOS evidence: the File Provider locations under `~/Library/CloudStorage`,
 * the per-account mount points in the Drive preferences, and the legacy
 * `/Volumes` mounts older builds used. Any source may be missing.
 */
export declare class MacosDriveDiscoveryAdapter {
    private readonly options;
    readonly model: "macos";
    constructor(options: MacosAdapterOptions);
    discover(): Promise<DiscoveryEvidence>;
    private addCloudStorage;
    private addPreferences;
    private addLegacyVolumes;
    /** The account label already known for a mount that contains the new path. */
    private findAccount;
    /** One root reported once; the first evidence wins and later ones merge labels. */
    private deduplicate;
    private reasonOf;
}
//# sourceMappingURL=platform-macos.d.ts.map