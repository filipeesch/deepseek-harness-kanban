import type { Command, ContextOperation, Problem, Task } from '../shared/types.js';
import type { DestructiveRequest } from './destructive-dialogs.js';
export interface CommandFailureAdvice {
    notice?: Problem;
    discard?: DestructiveRequest;
}
export interface CommandFailureInput {
    command: Command;
    problem: Problem;
    task?: Task;
    priorOperation?: ContextOperation;
    allowDiscard: boolean;
}
/** Classifies a failed command into a board notice and an optional discard confirmation. */
export declare function adviseCommandFailure({ command, problem, task, priorOperation, allowDiscard }: CommandFailureInput): CommandFailureAdvice;
//# sourceMappingURL=command-failure.d.ts.map