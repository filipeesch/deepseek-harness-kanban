/** Native agent-preset roster and selection behind the drawer's mode seat. */
export interface ModeOption {
    readonly id: string;
    readonly name?: string;
    readonly description?: string;
    readonly isDefault?: boolean;
}
export interface ModeSelectResult {
    readonly ok: boolean;
    /** The id the host actually accepted, when it returns one. */
    readonly id?: string;
    readonly message?: string;
}
export interface ModePort {
    list(): Promise<readonly ModeOption[]>;
    select(sessionId: string, id: string): Promise<ModeSelectResult>;
}
/** Minimal native config read for the coding-tools gate; deployment data stays optional. */
export interface ModeConfigSource {
    developerTools(): boolean;
}
export interface ModePortSource {
    getSnapshot(): ModePort | null;
    subscribe(listener: () => void): () => void;
}
/** Let the hosted seat start before an optional Remote namespace is mounted. */
export declare function createModePortSource(initialNamespace: unknown, config: ModeConfigSource): ModePortSource & {
    set(namespace: unknown): void;
};
export declare class ModePortError extends Error {
    constructor(message: string);
}
/**
 * Adapt the native remote namespace into the small port the mode seat owns.
 * Array order is preserved; broken presets and coding-tools-gated entries are
 * removed exactly where the native picker would filter them.
 */
export declare function createModePort(remote: unknown, config?: ModeConfigSource): ModePort | null;
//# sourceMappingURL=mode-port.d.ts.map