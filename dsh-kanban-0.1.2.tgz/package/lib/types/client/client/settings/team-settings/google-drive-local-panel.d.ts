import React from 'react';
import type { ClientApi, HubSharingView, HubState } from '../../../shared/types.js';
import type { Act } from './shared.js';
export declare function GoogleDriveLocalStoragePanel({ hub, sharing, act, pending, api }: {
    hub: HubState;
    sharing?: HubSharingView;
    act: Act;
    pending: string | null;
    api?: ClientApi;
}): React.JSX.Element;
//# sourceMappingURL=google-drive-local-panel.d.ts.map