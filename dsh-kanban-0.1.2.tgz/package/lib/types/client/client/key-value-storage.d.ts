/** Minimal string storage port; adapters decide where preferences live. */
export interface KeyValueStorage {
    get(key: string): string | null;
    set(key: string, value: string | null): void;
}
/** Browser adapter; storage failures are best effort and never break the board. */
export declare function browserStorage(): KeyValueStorage;
//# sourceMappingURL=key-value-storage.d.ts.map