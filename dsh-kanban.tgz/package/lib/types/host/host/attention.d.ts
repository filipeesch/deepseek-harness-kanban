import type { ConversationFacts } from '../shared/types.js';
import type { ConversationFactsSource } from './native-facts.js';
export { MAX_READ_RETRIES } from './conversation-facts-cache.js';
/** One task whose conversations contribute to its attention. */
export interface AttentionTask {
    id: string;
    sessionIds: readonly string[];
    /** Closed conversations are historical and resolve last. */
    closedSessionIds?: readonly string[];
    /** Active tasks (running or auto mode enabled) resolve their facts before historically idle ones. */
    priority?: 'active' | 'normal';
}
export interface AttentionCoordinatorOptions {
    source: ConversationFactsSource;
    tasks: () => readonly AttentionTask[];
    runPendingWork: () => Promise<void>;
    onChange: () => void;
    report: (error: unknown) => void;
    /** Called once per resolved background fact batch so the caller can publish the new projection. */
    onFacts?: () => void;
    /** Background read concurrency; the cache defaults it. */
    concurrency?: number;
    /** Batch coalescing seam for tests. */
    schedule?: (run: () => void) => void;
    debounceMs?: number;
    reconcileMs?: number;
}
/** Compare two conversation-fact projections for the host's publish-on-change rule. */
export declare function sameConversationFacts(left: Record<string, ConversationFacts>, right: Record<string, ConversationFacts>): boolean;
/**
 * Owns the per-conversation fact cache, its invalidation, and the presentation
 * projection. Presentation never awaits a cold read; admission reads the uncached
 * facts source, so a partial or fallback presentation can never feed an automatic
 * decision.
 */
export declare class AttentionCoordinator {
    private readonly options;
    private readonly facts;
    private readonly debounceMs;
    private readonly reconcileMs;
    private timer;
    private timerKind;
    private last;
    private presented;
    private readonly dirty;
    private ticking;
    private tickAgain;
    private disposed;
    constructor(options: AttentionCoordinatorOptions);
    /** One conversation's durable read for admission paths; never queued behind presentation. */
    read(sessionId: string): Promise<ConversationFacts>;
    /** Drop one conversation's cached facts, or every conversation's facts, for the next tick. */
    invalidate(sessionId?: string): void;
    /** Invalidate the affected facts, reset its retry allowance, and coalesce an activity refresh. */
    touch(sessionId?: string): void;
    /**
     * Resolve the requested conversations before an explicit snapshot response. Every
     * other conversation keeps its resolved cache and continues in the background queue;
     * an explicit refresh never turns into a full cold re-read.
     */
    refresh(sessionIds: readonly string[], tasks?: readonly AttentionTask[]): Promise<Record<string, ConversationFacts>>;
    /**
     * The resolved presentation with no read scheduled or awaited. A command response
     * uses it so the command itself never starts a conversation-fact read.
     */
    presentCache(tasks?: readonly AttentionTask[]): Record<string, ConversationFacts>;
    /** Ask for one task's conversations to be resolved before historically idle ones. */
    prioritize(sessionIds: readonly string[]): void;
    /** The presentation projection: resolved facts only, with background reads scheduled. */
    present(tasks?: readonly AttentionTask[]): Record<string, ConversationFacts>;
    /** Awaiting projection: every conversation's durable facts, used by explicit refreshes and tests. */
    project(tasks?: readonly AttentionTask[]): Promise<Record<string, ConversationFacts>>;
    dispose(): void;
    /** A background batch resolved: refresh the presentation and publish only a real change. */
    private factsSettled;
    /** Every conversation the board currently presents, from the last snapshot or the task list. */
    private sessionIds;
    private markDirty;
    private ensurePresentation;
    private schedule;
    private arm;
    /** Conversations to re-read: touched edges, active work, and reads inside the retry allowance. */
    private reconcileIds;
    private tick;
}
//# sourceMappingURL=attention.d.ts.map