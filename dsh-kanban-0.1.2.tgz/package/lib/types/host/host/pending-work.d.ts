/** Runs the pending-work steps that must precede an attention projection tick. */
export interface PendingWorkOptions {
    resumeWorktrees: () => Promise<void>;
    dispatchPending: () => Promise<void>;
    report?: (error: unknown) => void;
}
/**
 * Keeps worktree resume and confirmed-transition driving out of the attention
 * coordinator. A failing step is reported and does not prevent the other.
 */
export declare class PendingWorkRunner {
    private readonly options;
    constructor(options: PendingWorkOptions);
    run(): Promise<void>;
}
//# sourceMappingURL=pending-work.d.ts.map