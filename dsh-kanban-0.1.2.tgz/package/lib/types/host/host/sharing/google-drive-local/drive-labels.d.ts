export interface DriveFolderGroup {
    id: 'my-drive' | 'shared-drives';
    label: string;
}
/** The recognized group for a folder name, or undefined when the name is unknown. */
export declare function groupForFolderName(name: string): DriveFolderGroup | undefined;
/** The account folder prefix used by the macOS File Provider mount name. */
export declare const CLOUD_STORAGE_ACCOUNT_PREFIX = "GoogleDrive-";
/** The account label carried by a File Provider folder name, when it has one. */
export declare function accountFromCloudStorageName(name: string): string | undefined;
//# sourceMappingURL=drive-labels.d.ts.map