import type { SharingAuthView } from '../../shared/types.js';
import { type CredentialStore } from './credentials.js';
export declare const DEFAULT_GOOGLE_DRIVE_CLIENT_ID = "542662301814-0ientrpp3q20vb1ld5v5p6td4fjgct50.apps.googleusercontent.com";
export declare const GOOGLE_DRIVE_SCOPE = "https://www.googleapis.com/auth/drive";
export interface GoogleDriveAuthOptions {
    credentials?: CredentialStore;
    clientId?: string;
    clientSecret?: string;
    fetch?: typeof fetch;
    now?: () => number;
    onChange?: () => void;
}
/**
 * Installed-application OAuth for Google Drive. The browser signs in on
 * Google, the loopback callback lands here, and the grant lives in the host
 * credential store; no token ever reaches the client.
 */
export declare class GoogleDriveAuthService {
    private readonly credentials;
    private readonly clientId;
    private readonly clientSecret;
    private readonly fetchImpl;
    private readonly now;
    private readonly onChange;
    private pending;
    private generation;
    private reconnectRequired;
    private lastError;
    private drives;
    private folders;
    constructor(options?: GoogleDriveAuthOptions);
    private get store();
    private notify;
    /** Begin authorization and return the URL the user must open. */
    start(): Promise<string>;
    cancel(): Promise<void>;
    disconnect(): Promise<void>;
    /** Complete the loopback callback; public so the acceptance and unit tests can drive it. */
    handleCallback(code: string, state: string): Promise<void>;
    /** A valid access token, refreshed through the credential store when needed. */
    accessToken(): Promise<string>;
    /** Force a refresh-token exchange; used after an API 401. */
    refreshAccessToken(): Promise<string>;
    status(): Promise<SharingAuthView>;
    private driveClient;
    listDrives(): Promise<Array<{
        id: string;
        name: string;
    }>>;
    listFolders(input?: {
        driveId?: string;
        parentId?: string;
    }): Promise<Array<{
        id: string;
        name: string;
    }>>;
    private authorizationUrlForPending;
    private handleRequest;
    private tokenRequest;
    private userEmail;
    private revoke;
}
//# sourceMappingURL=google-drive-auth.d.ts.map