import React from 'react';
import { type RunCommand } from './ui.js';
export declare function CreateHubDialog({ run, onClose, onCreated }: {
    run: RunCommand;
    onClose: () => void;
    onCreated: (id: string) => void;
}): React.JSX.Element;
export declare function CreateBoardDialog({ hubId, run, onClose, onCreated }: {
    hubId: string;
    run: RunCommand;
    onClose: () => void;
    onCreated: (id: string) => void;
}): React.JSX.Element;
//# sourceMappingURL=create-dialogs.d.ts.map