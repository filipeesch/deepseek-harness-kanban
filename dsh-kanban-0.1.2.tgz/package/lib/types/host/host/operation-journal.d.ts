import type { ContextOperation, HubState, Task } from '../shared/types.js';
/** The narrow write surface a journal needs, satisfied by the coordinator's store. */
export interface JournalStore {
    transactTask<T>(taskId: string, change: (draft: HubState) => T): Promise<T>;
}
export declare function requireTask(state: HubState, taskId: string): Task;
/**
 * Owns the persisted operation record: its phase, error, and progress. Every
 * write is guarded by the operation identity, so a replaced operation can never
 * receive progress from an older one.
 */
export declare class OperationJournal {
    private readonly store;
    private readonly now;
    constructor(store: JournalStore, now?: () => string);
    update(taskId: string, operationId: string, change: (task: Task, operation: ContextOperation) => void): Promise<void>;
}
//# sourceMappingURL=operation-journal.d.ts.map