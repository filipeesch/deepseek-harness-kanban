import React from 'react';
import type { Problem } from '../shared/types.js';
export interface ClosedConversationsMenuProps {
    closed: readonly string[];
    label: (sessionId: string) => string;
    pending: boolean;
    error: Problem | null;
    /** Called when the popover opens so a stale reopen notice can be cleared. */
    onOpen: () => void;
    onReopen: (sessionId: string) => Promise<boolean>;
    onReopened: (sessionId: string) => void;
}
/**
 * Closed task conversations live behind an on-demand popover so history never
 * competes with the conversation body. The chip is a toolbar sibling, not a tab.
 */
export declare function ClosedConversationsMenu({ closed, label, pending, error, onOpen, onReopen, onReopened }: ClosedConversationsMenuProps): React.JSX.Element | null;
//# sourceMappingURL=closed-conversations.d.ts.map