import type { QuestionPage, QuestionRound } from '../shared/types.js';
/** Structural input accepted by the published SDK's canonical SessionEvent union. */
export interface QuestionEvent {
    readonly type: string;
    readonly seq: number;
    readonly data: unknown;
}
export type ProjectionEvent = {
    kind: 'call';
    seq: number;
    turn: number;
    callId: string;
    name: string;
} | {
    kind: 'ptc-start';
    seq: number;
    callId: string;
    rootCallId: string;
    parentCallId: string;
} | {
    kind: 'native-page';
    seq: number;
    turn: number;
    callId: string;
    page: QuestionPage;
} | {
    kind: 'ptc-page';
    seq: number;
    callId: string;
    rootCallId: string;
    parentCallId: string;
    page: QuestionPage;
} | {
    kind: 'end';
    seq: number;
    turn: number;
} | {
    kind: 'human';
    seq: number;
};
/** Minimal projection data only: no transcripts, tool arguments, or human message text. */
export interface QuestionIndexSnapshot {
    version: 1;
    sessions: Array<{
        sessionId: string;
        events: ProjectionEvent[];
        dismissedTurns?: number[];
    }>;
}
/** One conversation's durable projection record, independent of board or task state. */
export interface QuestionSessionRecord {
    version: 1;
    sessionId: string;
    events: ProjectionEvent[];
    dismissedTurns?: number[];
}
/** Canonical-event projection independent of native registration, storage, and presentation. */
export declare class QuestionIndex {
    private events;
    private dismissed;
    private rounds;
    private revisions;
    private allRounds;
    private listeners;
    private disposed;
    constructor(snapshot?: unknown);
    /** Returns whether new relevant canonical information was admitted. Replay duplicates are no-ops. */
    apply(sessionId: string, event: QuestionEvent): boolean;
    /** Stable snapshots between changes, suitable for useSyncExternalStore consumers. */
    getRounds(sessionId?: string): readonly QuestionRound[];
    /** Monotonic per-conversation projection revision; unrelated sessions never advance it. */
    revisionOf(sessionId: string): number;
    /** Includes incomplete rounds while questions are still arriving; no native tool is blocked. */
    pending(sessionId?: string): boolean;
    /** Restore previously dismissed turns when a durable write could not be completed. */
    undismiss(sessionId: string, turns: readonly number[]): void;
    /** Permanently hide every supplied round in one conversation. Returns how many turns were newly dismissed. */
    dismiss(sessionId: string, roundIds: readonly string[]): number;
    subscribe(listener: () => void): () => void;
    serialize(): QuestionIndexSnapshot;
    /** One conversation's projection record, or undefined when it holds no events or dismissals. */
    serializeSession(sessionId: string): QuestionSessionRecord | undefined;
    /** Drop stored question-page payloads for dismissed turns while retaining call/end/human evidence. */
    private serializeEvents;
    /**
     * Merge one durable record, validating every event before touching state.
     * Existing sequences win so canonical replay stays authoritative.
     */
    restoreSession(record: unknown): boolean;
    /** Replace atomically with validated projection data; completeness is reconstructed from actual end records. */
    load(snapshot: unknown): void;
    dispose(): void;
    private rebuild;
    private emit;
}
//# sourceMappingURL=indexer.d.ts.map