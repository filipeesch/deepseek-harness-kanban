import { type AutoAdvancePlan } from '../domain/auto-advance.js';
import type { HubState, PendingUserWork, Task } from '../shared/types.js';
import type { LocatedTask } from './hub-repository.js';
/** The task scope and the ports one automatic advance admission needs. */
export interface AutoAdvanceAdmissionDeps {
    locate(taskId: string): LocatedTask;
    transact(hubId: string, change: (draft: HubState) => void): Promise<unknown>;
    /** The first open conversation, creating one when every tab is closed. */
    resolveSession(task: Task): Promise<string>;
    /** Pending user work across every conversation of the task, read fresh. */
    pending(task: Task): Promise<PendingUserWork>;
    dispatch(): Promise<void>;
    report(error: unknown): void;
}
/**
 * The one host admission path for an automatic advance: validate the task and
 * the captured destination, resolve the target conversation, re-read pending
 * user work immediately before the durable decision, persist exactly one
 * transition, and let the drain place and dispatch it.
 *
 * A task that is busy, moved, or still owed user input is skipped without a
 * pause. A destination that no longer resolves, or a task that changed before
 * the transaction committed, throws and the coordinator records the admission
 * failure instead of retrying silently.
 */
export declare function admitAutoAdvance(deps: AutoAdvanceAdmissionDeps, taskId: string, plan: AutoAdvancePlan): Promise<void>;
//# sourceMappingURL=auto-advance-admission.d.ts.map