import type { Board, BoardState, Command, HubState, KanbanSnapshot, Task } from '../shared/types.js';
export declare const ACTIVE_HUB_KEY = "dsh.kanban.activeHub";
export declare const ACTIVE_BOARDS_KEY = "dsh.kanban.activeBoards";
export declare function readStorage(key: string): string | null;
export declare function writeStorage(key: string, value: string | null): void;
export declare function readBoardPreferences(): Record<string, string>;
export declare function writeBoardPreference(hubId: string, boardId: string, previous: Record<string, string>): Record<string, string>;
export declare function allTasks(snapshot: Pick<KanbanSnapshot, 'state'>): Task[];
export declare function boardView(hub: HubState, board: Board, settings: KanbanSnapshot['state']['settings']): BoardState;
export declare function hubProjectView(hub: HubState): BoardState;
export declare function normalizeSnapshot(snapshot: KanbanSnapshot): KanbanSnapshot;
export declare function scopedCommand(command: Command, hubId: string | undefined, boardId: string | undefined, multiHub: boolean, multiBoard: boolean): Command;
//# sourceMappingURL=hub-view.d.ts.map