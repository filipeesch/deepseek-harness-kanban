import type { Context } from '@deepseek-ai/cordis';
declare module '@deepseek-ai/dsh-api-session-controller/client' {
    interface SessionReferenceSourceMap {
        kanbanTaskDrawer: unknown;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        'kanban.conversation': {
            kind: 'single';
            scope: 'session';
        };
        'kanban.session.header': {
            kind: 'single';
            scope: 'session';
        };
    }
}
export declare const name = "kanban-client";
export declare const inject: string[];
/** Real client plugin: no replacement server, global Session selection, or native acknowledgement writes. */
export declare function apply(raw: Context): Promise<() => Promise<void>>;
//# sourceMappingURL=client.d.ts.map