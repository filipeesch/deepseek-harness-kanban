import React from 'react';
import type { SharingStorage } from '../../../shared/types.js';
import { type IconProps } from '../../icons.js';
export interface StorageMeta {
    label: string;
    description: string;
    Icon: (props: IconProps) => React.JSX.Element;
}
/** One card per storage; the icon and description live beside the id, not in the panel. */
export declare const STORAGE_META: Record<SharingStorage, StorageMeta>;
/**
 * The storage chooser as a radio group of cards. While a Hub is bound every
 * card is disabled: changing the storage requires Disconnect, and the selected
 * card is the bound one.
 */
export declare function StorageCards({ value, onChange, locked, busy }: {
    value: SharingStorage;
    onChange: (value: SharingStorage) => void;
    locked: boolean;
    busy: boolean;
}): React.JSX.Element;
//# sourceMappingURL=storage-cards.d.ts.map