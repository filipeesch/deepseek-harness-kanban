import React from 'react';
import type { Problem } from '../shared/types.js';
import type { SharedWorktreeBlocker } from '../shared/worktree-blockers.js';
import type { DestructiveRequest } from './destructive-dialogs.js';
/**
 * Explicit consent for removing a checkout that is shared outside the task's
 * lineage. The directory is removed, so the dialog lists every affected task
 * and conversation and requires an opt-in.
 */
export declare function ForceRemovalDialog({ request, blockers, sessionTitles, pending, problem, onCancel, onConfirm }: {
    request: DestructiveRequest;
    blockers: SharedWorktreeBlocker[];
    sessionTitles?: {
        title(sessionId: string): string | undefined;
    };
    pending: boolean;
    problem: Problem | null;
    onCancel: () => void;
    onConfirm: () => void;
}): React.JSX.Element;
//# sourceMappingURL=force-removal-dialog.d.ts.map