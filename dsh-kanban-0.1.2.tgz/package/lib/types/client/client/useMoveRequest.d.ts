import type { BoardState, Column, Command, KanbanSnapshot, Problem, Task } from '../shared/types.js';
export interface OptimisticMove {
    taskId: string;
    columnId: string;
    beforeTaskId: string | null;
}
export interface MoveConfirmation {
    taskId: string;
    taskTitle: string;
    fromColumnId: string;
    toColumnId: string;
    fromName: string;
    toName: string;
    workflowName: string;
}
/** One validated move intent, handed to the client preparation before the move is applied. */
export interface MoveIntent {
    task: Task;
    column: Column;
    beforeTaskId: string | null;
}
export interface MoveRequestOptions {
    state: BoardState | null;
    run: (command: Command) => Promise<KanbanSnapshot>;
    onImmediateError: (error: unknown) => void;
    onMoved?: (result: KanbanSnapshot, task: Task, column: Column) => void;
    /** Runs after every validation and the restricted-move confirmation; false cancels the move. */
    beforeApply?: (intent: MoveIntent) => Promise<boolean>;
}
export interface MoveRequest {
    optimistic: OptimisticMove | null;
    move: (task: Task, column: Column, beforeTaskId?: string | null) => Promise<boolean>;
    confirmation: MoveConfirmation | null;
    pending: boolean;
    error: Problem | null;
    canRetry: boolean;
    confirm: () => Promise<void>;
    cancel: () => void;
}
/** Classifies moves, applies allowed and reorder requests, and owns the restricted-move confirmation lifecycle. */
export declare function useMoveRequest({ state, run, onImmediateError, onMoved, beforeApply }: MoveRequestOptions): MoveRequest;
//# sourceMappingURL=useMoveRequest.d.ts.map