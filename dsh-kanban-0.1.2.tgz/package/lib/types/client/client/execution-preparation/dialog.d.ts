import type { ExecutionPreparationController, PreparationState } from './controller.js';
import { type PreparationSeat } from './model-seat.js';
export interface ExecutionPreparationDialogProps {
    state: PreparationState;
    controller: ExecutionPreparationController;
    seat?: PreparationSeat;
}
/** The one preparation dialog: worktree question, provisioning, and the native model stage. */
export declare function ExecutionPreparationDialog({ state, controller, seat }: ExecutionPreparationDialogProps): import("react").JSX.Element;
//# sourceMappingURL=dialog.d.ts.map