import type { HubSharingService } from './service.js';
export interface SharingPollSchedulerOptions {
    service: Pick<HubSharingService, 'publishedHubs' | 'check' | 'busy'>;
    setTimer?: (callback: () => void, ms: number) => unknown;
    clearTimer?: (handle: unknown) => void;
    report?: (error: unknown) => void;
    /** A due check waits briefly when the Hub lane is busy rather than dropping the tick. */
    busyRetryMs?: number;
}
/**
 * Host-side automatic check scheduler. One timer per published Hub, driven by
 * that Hub's interval; `0` disables automatic checks. Timers are injectable so
 * tests can advance a fake clock.
 */
export declare class SharingPollScheduler {
    private readonly options;
    private readonly schedules;
    private readonly setTimer;
    private readonly clearTimer;
    private disposed;
    constructor(options: SharingPollSchedulerOptions);
    /** Reconcile the desired per-Hub schedules with the current publishing state. */
    sync(): void;
    dispose(): void;
    private cancel;
    private schedule;
    private tick;
}
//# sourceMappingURL=scheduler.d.ts.map