import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
import type { SharedHubDocument } from '../../domain/sharing/document.js';
import type { OrphanMap, BoardBindings } from '../../domain/sharing/identity.js';
import type { ProviderState, SharingBinding } from './provider.js';
export interface StoredSharedDocument {
    token: string;
    document: SharedHubDocument;
}
/** One Hub's local publishing state. A record exists only while the Hub is published. */
export interface HubSharingRecord {
    version: 2;
    hubId: string;
    binding: SharingBinding;
    /** Provider-owned synchronization state, such as a Drive cursor and revision. */
    providerState: ProviderState;
    /** Hub revision whose content is present in the last published document. */
    syncedRevision: number | null;
    /** Last received (merged) document used for three-way comparison. */
    base: StoredSharedDocument | null;
    /** Last document read from the provider. */
    seen: StoredSharedDocument | null;
    bindings: BoardBindings;
    orphans: OrphanMap;
    /** Keys removed only from this installation; the team document keeps them. */
    removed: Record<string, {
        boardId: string;
        name: string;
    }>;
    /** Keys this installation will drop from the team document on the next publish. */
    pendingRemovals: string[];
    /** The document read during connect, waiting for receive or publish-initial. */
    preview: StoredSharedDocument | null;
    lastCheck: {
        at: string;
        token: string;
    } | null;
    /** Last successful publish or team-update application, not every readable check. */
    lastSyncedAt?: string | null;
    /** A concurrent write that still requires an explicit review, independent of transient errors. */
    reviewRequired?: {
        code: string;
        message: string;
    } | null;
    /** A review the storage itself requires, such as a synchronization conflict copy. */
    storageReview?: {
        code: string;
        message: string;
        files: string[];
    } | null;
    lastError: {
        code: string;
        message: string;
    } | null;
}
export declare const HubSharingRecordSchema: z.ZodType<HubSharingRecord>;
/** Read either the current record shape or the Git-only v1 shape. */
export declare function migrateSharingRecord(raw: unknown): HubSharingRecord | undefined;
export interface HubSharingStore {
    load(hubId: string): HubSharingRecord | undefined;
    list(): HubSharingRecord[];
    save(record: HubSharingRecord): Promise<void>;
    delete(hubId: string): Promise<void>;
    close(): Promise<void>;
}
/**
 * Durable publishing state, independent from the Hub aggregate. Records are
 * validated on read; a corrupt record is quarantined with a typed error rather
 * than preventing the Hub domain from opening.
 */
export declare function openSharingStorage(ctx: Context, options?: {
    report?: (error: unknown) => void;
}): Promise<{
    storage: HubSharingStore;
    close: () => Promise<void>;
}>;
//# sourceMappingURL=state.d.ts.map