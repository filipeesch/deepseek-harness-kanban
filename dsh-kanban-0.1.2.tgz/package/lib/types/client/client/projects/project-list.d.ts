import React from 'react';
import type { Project, Task } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
/** Registry list: management only; creation and editing live in the dialog. */
export declare function ProjectList({ projects, tasks, revision, run, onAdd, onEdit }: {
    projects: Project[];
    tasks: Task[];
    revision: number;
    run: RunCommand;
    onAdd: () => void;
    onEdit: (project: Project) => void;
}): React.JSX.Element;
//# sourceMappingURL=project-list.d.ts.map