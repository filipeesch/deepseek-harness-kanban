import React from 'react';
import type { HubSharingView, HubState } from '../../../shared/types.js';
import type { Act } from './shared.js';
/** The folder the plugin proposes for this Hub; only this one may be created on connect. */
export declare function suggestedFolder(hubId: string): string;
export declare function LocalFolderStoragePanel({ hub, sharing, act, pending }: {
    hub: HubState;
    sharing?: HubSharingView;
    act: Act;
    pending: string | null;
}): React.JSX.Element;
//# sourceMappingURL=local-folder-panel.d.ts.map