import type { ISessions, SessionReference } from '@deepseek-ai/dsh-api-session-controller/client';
/**
 * The Session services a drawer lease needs: retain an exact Session, refresh a
 * catalog miss, and read the client catalog without opening anything.
 */
export type ConversationLeaseSessions = Pick<ISessions, 'retain' | 'refresh' | 'list' | 'subagentAddress'>;
/** A drawer conversation target: a Session id or a transient subagent address. */
export interface ConversationLeaseAddress {
    readonly parentSessionId: string;
    readonly childSessionId: string;
    readonly mode: 'one-shot' | 'continuable' | 'unknown';
}
export type ConversationLeaseTarget = string | ConversationLeaseAddress;
/** The services a mounted task drawer injects into its lease scope. */
export interface ConversationLeaseEnvironment {
    readonly sessions: ConversationLeaseSessions;
    readonly lifetime: AbortSignal;
}
/** One conversation's retained state, as the drawer consumes it. */
export interface ConversationLeaseState {
    readonly status: 'pending' | 'ready' | 'error';
    readonly reference?: SessionReference;
    readonly error?: string;
}
export type ConversationLeaseSnapshot = Readonly<Record<string, ConversationLeaseState>>;
/**
 * Owns the native Session references of one mounted task drawer. A root lease
 * survives conversation tab and drawer-section switches; a peek lease is
 * released by its consumer. Nothing here awaits history settling: a retained
 * reference is published as soon as it exists.
 */
export declare class ConversationLeaseRegistry {
    private readonly environment;
    private readonly roots;
    private readonly peeks;
    private readonly listeners;
    private readonly onLifetimeAbort;
    private snapshot;
    /** Set only by the plugin lifetime abort; a StrictMode unmount must leave the registry reusable. */
    private terminated;
    constructor(environment: ConversationLeaseEnvironment);
    getSnapshot: () => ConversationLeaseSnapshot;
    subscribe: (listener: () => void) => (() => void);
    /** Retain one conversation root; idempotent, and a no-op after an error until retry. */
    acquireRoot(target: ConversationLeaseTarget): void;
    /**
     * Retain one transient peeked conversation.
     * @returns the idempotent release for that peek.
     */
    acquirePeek(target: ConversationLeaseTarget): () => void;
    /** Retry one failed acquisition, keeping a peek transient. */
    retry(target: ConversationLeaseTarget): void;
    /** Release one root lease. */
    release(key: string): void;
    /** Release every root lease that no longer belongs to the task's open conversations. */
    retainOnly(openSessionIds: readonly string[]): void;
    /** Release every retained conversation. */
    releaseAll(): void;
    /** Release everything and stop observing the lifetime; the instance remains usable for a remount. */
    dispose(): void;
    private acquire;
    /** A string Session id is catalogued when the client already lists it or owns its address. */
    private catalogHas;
    private retain;
    private refreshThenRetain;
    private current;
    private releaseFrom;
    private publish;
}
/** Subscribe one conversation to a registry snapshot. */
export declare function useConversationLeaseState(registry: ConversationLeaseRegistry, key: string): ConversationLeaseState | undefined;
//# sourceMappingURL=conversation-leases.d.ts.map