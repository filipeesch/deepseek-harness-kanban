import type { Workflow } from '../shared/types.js';
export interface WorkflowIssue {
    code: string;
    message: string;
    /** Offsets are UTF-16 document offsets, matching the editor's positions. */
    from?: number;
    to?: number;
}
export interface WorkflowDiagnostic {
    from: number;
    to: number;
    severity: 'error';
    message: string;
}
export interface WorkflowAnalysis {
    status: 'valid' | 'invalid';
    workflow?: Workflow;
    issues: WorkflowIssue[];
    diagnostics: WorkflowDiagnostic[];
}
/** Analyze workflow YAML locally with the same schema the host trusts. */
export declare function analyzeWorkflow(yaml: string): WorkflowAnalysis;
//# sourceMappingURL=workflow-diagnostics.d.ts.map