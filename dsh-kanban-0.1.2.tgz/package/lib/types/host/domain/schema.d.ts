import { z } from 'zod';
import { type BoardState } from '../shared/types.js';
/** Validates persisted data without resetting unknown versions or dropping orphaned records. */
export declare const BoardStateSchema: z.ZodType<BoardState>;
export declare function initialState(): BoardState;
//# sourceMappingURL=schema.d.ts.map