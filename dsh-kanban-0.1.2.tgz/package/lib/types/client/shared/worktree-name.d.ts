/** Lowercase ASCII slug derived from a task title, used as the default branch name. */
export declare function taskTitleSlug(title: string): string;
/** Join a configured worktree base path with a branch name without Node path semantics. */
export declare function worktreePathForBranch(basePath: string | undefined, branchName: string): string;
//# sourceMappingURL=worktree-name.d.ts.map