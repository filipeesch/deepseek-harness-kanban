import React from 'react';
import type { HubSharingView, HubState } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
export declare function HubSettings({ hub, hubCount, run, sharing, onDeleted, onBoardCreated }: {
    hub: HubState;
    hubCount: number;
    run: RunCommand;
    sharing?: HubSharingView;
    onDeleted?: () => void;
    onBoardCreated?: (id: string) => void;
}): React.JSX.Element;
//# sourceMappingURL=hub-settings.d.ts.map