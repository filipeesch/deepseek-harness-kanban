import type { Context } from '@deepseek-ai/cordis';
import type { GitExecutor, SessionPort, ProjectProbe, WorkspacePort } from '../shared/ports.js';
import type { ConversationFactsReader } from './conversation-facts.js';
import { type SessionHistoryReader } from './session-history.js';
/** Optional Host integrations the native adapters read; absent creates the public history reader. */
export interface NativePortsOptions {
    conversationFacts?: ConversationFactsReader;
    history?: SessionHistoryReader;
}
/** Native adapters own no session history, permission grants, or replacement runtime. */
export declare function createNativePorts(ctx: Context, options?: NativePortsOptions): {
    sessions: SessionPort;
    executor: GitExecutor;
    workspaces: WorkspacePort;
    probe: ProjectProbe;
};
//# sourceMappingURL=native.d.ts.map