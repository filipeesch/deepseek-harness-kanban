import React from 'react';
import type { BoardState, Task } from '../shared/types.js';
import { type RunCommand } from './ui.js';
import { type TaskPageState } from './page-state.js';
export declare function NewTaskDialog({ state, run, onClose, onCreated }: {
    state: BoardState;
    run: RunCommand;
    onClose: () => void;
    onCreated: (id: string) => void;
}): React.JSX.Element;
type TaskPanelProps = {
    task: Task;
    state: BoardState;
    run: RunCommand;
    viewState?: TaskPageState;
};
export declare function InfoPanel(props: TaskPanelProps): React.JSX.Element;
export {};
//# sourceMappingURL=forms.d.ts.map