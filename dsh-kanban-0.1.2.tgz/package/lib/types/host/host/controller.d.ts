import { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Command, HostSnapshot, LocalDriveRequest, LocalDriveResult, Outcome, ProjectLocation, QuestionFeedFrame, QuestionRound, SharingCommand } from '../shared/types.js';
import type { KanbanApp } from './app.js';
export declare class KanbanController extends TypertRemoteService {
    private readonly app;
    constructor(ctx: Context, app: KanbanApp);
    private owner;
    private attempt;
    snapshot(): Promise<Outcome<HostSnapshot>>;
    command(request: Command): Promise<Outcome<HostSnapshot>>;
    sharing(request: SharingCommand): Promise<Outcome<HostSnapshot>>;
    branches(request: {
        taskId: string;
    }): Promise<Outcome<string[]>>;
    worktreeDefault(request: {
        taskId: string;
    }): Promise<Outcome<{
        branchName: string;
        path: string;
    }>>;
    detectProject(request: {
        path: string;
    }): Promise<Outcome<ProjectLocation>>;
    localDrive(request: LocalDriveRequest): Promise<Outcome<LocalDriveResult>>;
    dismissQuestions(request: {
        sessionId: string;
        roundId: string;
    }): Promise<Outcome<QuestionRound[]>>;
    follow(signal: AbortSignal): AsyncGenerator<HostSnapshot>;
    /**
     * One conversation's question projection, independent of board and attention work.
     * A baseline frame precedes updates; unrelated sessions never advance this revision.
     */
    questionsFollow(request: {
        sessionId: string;
    }, signal: AbortSignal): AsyncGenerator<QuestionFeedFrame>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        kanbanController: KanbanController;
    }
}
//# sourceMappingURL=controller.d.ts.map