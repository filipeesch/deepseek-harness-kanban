import type { Project, Task } from '../shared/types.js';
import type { OperationJournal } from './operation-journal.js';
export interface AdmissionStore {
    locate(taskId: string): {
        task: Task;
        project: Project;
    };
}
export interface DestructiveAdmissionJob {
    lane: string;
    taskId: string;
    operationId: string;
}
/** The one persisted-binding comparison shared by admission and the command path. */
export declare function bindingMatches(task: Task, expectedWorktreePath: string | null): boolean;
/**
 * Decides whether an already recorded destructive operation may be queued,
 * using persisted state only. The authoritative preflight — conversation
 * idleness, canonical target stability, checkout sharing, and local changes —
 * belongs to execution inside the queue lane, so admission never inspects Git,
 * native conversations, or the filesystem.
 */
export declare class DestructiveAdmission {
    private readonly store;
    private readonly journal;
    constructor(store: AdmissionStore, journal: OperationJournal);
    prepare(taskId: string): Promise<DestructiveAdmissionJob>;
}
//# sourceMappingURL=destructive-admission.d.ts.map