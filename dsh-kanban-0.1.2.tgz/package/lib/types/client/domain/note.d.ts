import type { Note } from '../shared/types.js';
/** Tags kept on one note; the UI and the tools use the same limits. */
export declare const MAX_NOTE_TAGS = 4;
/** Maximum stored length of a single normalized tag. */
export declare const MAX_NOTE_TAG_LENGTH = 15;
/** The fields a note write may carry. */
export interface NotePatch {
    content?: string;
    tags?: string[];
}
/** A note write. Creation requires content; an update requires content or tags. */
export interface NoteInput extends NotePatch {
    id?: string;
}
/** A validated write, split so callers never re-check content or tags. */
export type NoteWrite = {
    kind: 'create';
    content: string;
    tags?: string[];
} | {
    kind: 'update';
    id: string;
    content?: string;
    tags?: string[];
};
export declare function assertNoteTags(value: unknown): void;
/** Trim, lowercase, truncate, deduplicate, discard empties, and keep at most four. */
export declare function normalizeNoteTags(tags: readonly string[]): string[];
/** Normalized tags for comparison and display; stored legacy values are not rewritten. */
export declare function noteTagsOf(tags: readonly string[] | undefined): string[];
/** Replace a note's tags, removing the property when nothing remains. */
export declare function applyNoteTags(note: Note, tags: readonly string[]): void;
/** The one write rule shared by the Hub operations and the legacy board store. */
export declare function validateNoteWrite(input: NoteInput): NoteWrite;
//# sourceMappingURL=note.d.ts.map