/**
 * Coalesces Host publication requests into at most one publication per window.
 * The first request after a quiet period publishes immediately; a dirty state
 * left at the end of a window publishes on the trailing edge, so a burst of
 * Session events can never drop the final state.
 */
export interface PublishSchedulerOptions {
    publish: () => void;
    windowMs?: number;
    schedule?: (run: () => void, ms: number) => unknown;
    cancel?: (handle: unknown) => void;
}
export declare class PublishScheduler {
    private readonly options;
    private readonly windowMs;
    private readonly schedule;
    private readonly cancel;
    private timer;
    private windowOpen;
    private dirty;
    private disposed;
    constructor(options: PublishSchedulerOptions);
    /** Mark the Host state dirty and publish within the current or next window. */
    request(): void;
    /** Publish a dirty state now and close the current window. */
    flush(): void;
    dispose(): void;
    private openWindow;
    private deliver;
}
//# sourceMappingURL=publish-scheduler.d.ts.map