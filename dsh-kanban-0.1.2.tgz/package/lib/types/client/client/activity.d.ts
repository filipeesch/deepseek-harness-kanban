import React from 'react';
import type { Attention, BackgroundActivity } from '../shared/types.js';
/** Count copy derived from the activity families, e.g. "1 job · 2 schedules". */
export declare function backgroundSummary(items: readonly BackgroundActivity[]): string;
/** The labels of the unsettled activities, e.g. "Run tests · Research". */
export declare function backgroundDetails(items: readonly BackgroundActivity[]): string;
/** One background chip line: the family label alone, or the total once families mix. */
export declare function backgroundIndicatorText(items: readonly BackgroundActivity[]): string;
/** The count and the labels are both part of the indicator's accessible name. */
export declare function backgroundAccessibleName(items: readonly BackgroundActivity[]): string;
export declare function WorkingBadge({ decorative }: {
    decorative?: boolean;
}): React.JSX.Element;
/** Persistent live region: mounted empty while idle, its text changes once when a turn starts. */
export declare function WorkingAnnouncement({ running, label }: {
    running: boolean;
    label?: string;
}): React.JSX.Element;
/** The drawer header's turn execution and background labels, with no live region of its own. */
export declare function TaskActivity({ attention }: {
    attention: Attention;
}): React.JSX.Element | null;
//# sourceMappingURL=activity.d.ts.map