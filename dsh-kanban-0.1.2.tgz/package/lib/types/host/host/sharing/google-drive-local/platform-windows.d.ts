import type { DiscoveryFs } from './filesystem.js';
import type { DiscoveryEvidence } from './mounts.js';
import type { SharingCommandRunner } from '../command-runner.js';
export interface WindowsAdapterOptions {
    home: string;
    fs: DiscoveryFs;
    runner: SharingCommandRunner;
    env?: NodeJS.ProcessEnv;
}
/** A configured mount point is a volume root or a folder path, never a drive-relative `G:`. */
export declare function normalizeMountPoint(value: string): string;
/** The `DefaultMountPoint` value from one `reg query` result, or undefined. */
export declare function parseMountPoint(output: string): string | undefined;
/** Every volume root the system reports. */
export declare function parseVolumeRoots(output: string): string[];
/**
 * Windows evidence: the configured mount point in the DriveFS registry keys
 * (user, machine, and policy), whether the DriveFS key itself exists, and the
 * volumes the system reports. A folder name never establishes a mount by
 * itself, so an ordinary volume that happens to contain `My Drive` is not
 * treated as Google Drive.
 */
export declare class WindowsDriveDiscoveryAdapter {
    private readonly options;
    readonly model: "windows";
    constructor(options: WindowsAdapterOptions);
    discover(): Promise<DiscoveryEvidence>;
    private query;
    private deduplicate;
}
//# sourceMappingURL=platform-windows.d.ts.map