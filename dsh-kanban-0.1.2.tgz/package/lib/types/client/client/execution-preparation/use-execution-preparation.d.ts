import React from 'react';
import type { ClientApi } from '../../shared/types.js';
import { type ConversationLeaseEnvironment } from '../conversation-leases.js';
import { type RunCommand } from '../ui.js';
import type { PrepareExecution } from './contract.js';
import { type PreparationSeat } from './model-seat.js';
export interface ExecutionPreparationOptions {
    api: ClientApi;
    run: RunCommand;
    /** The native slots and locale; absent in isolated render harnesses. */
    seat?: PreparationSeat;
    /** The client session services; absent in isolated render harnesses. */
    leases?: ConversationLeaseEnvironment;
}
export interface ExecutionPreparation {
    prepare: PrepareExecution;
    dialog: React.ReactNode;
}
/**
 * Owns the first-execution preparation for one mounted board: the controller,
 * the session lease used by the native model seat, and the dialog element.
 */
export declare function useExecutionPreparation({ api, run, seat, leases }: ExecutionPreparationOptions): ExecutionPreparation;
//# sourceMappingURL=use-execution-preparation.d.ts.map