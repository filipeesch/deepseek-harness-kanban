import React, { type ReactNode } from 'react';
import type { StoredEntry } from '@deepseek-ai/dsh-client-ui-slots';
import { type NativeSlotKind } from './native-slot-descriptors.js';
/** Snapshot source exposed by a native inject face hook. */
export interface NativeSnapshotSource {
    getSnapshot(): unknown;
    subscribe(listener: () => void): () => void;
}
/** The subset of the native slot registry the manual host reads. */
export interface NativeSlotSource {
    entriesOfSlot(key: string): readonly StoredEntry[];
    subscribe(key: string, listener: () => void): () => void;
}
/** The locale service face the host binds to native entry namespaces. */
export interface NativeLocaleSource {
    bind(namespace: string): (key: string, params?: Record<string, unknown>) => string;
    getSnapshot(): {
        revision: number;
    };
    subscribe(listener: () => void): () => void;
}
export interface NativeSlotOverrideContext {
    slot: string;
    entry: StoredEntry;
    sessionId?: string;
}
/** Lets a host redirect native action callbacks without reimplementing the action. */
export type NativeFaceOverride = (face: Record<string, unknown>, context: NativeSlotOverrideContext) => Record<string, unknown>;
export interface NativeSlotHostProps {
    slot: string;
    kind: NativeSlotKind;
    source: NativeSlotSource;
    locale: NativeLocaleSource;
    standard: Record<string, unknown>;
    owner?: object;
    fallback?: ReactNode;
    /** Rendered before the native entries; used by the mode-seat action band. */
    before?: ReactNode;
    exclude?: (entry: StoredEntry) => boolean;
    override?: NativeFaceOverride;
    renderFactorySlot?: unknown;
}
/** Re-render a manual host when native entries register or unregister. */
export declare function useSlotEntries(source: NativeSlotSource, slot: string): readonly StoredEntry[];
/** Re-render labels when the active locale or dictionary revision changes. */
export declare function useLocaleRevision(locale: NativeLocaleSource): number;
/**
 * Factory for one native `use<Name>` selector hook. The returned function is
 * called by the native component during its own render; this factory itself
 * does not call a Hook.
 */
export declare function nativeSnapshotSelectorHook(source: NativeSnapshotSource | undefined): (selector?: (value: unknown) => unknown, equal?: unknown) => unknown;
/**
 * Render a native slot's entries through the pinned host assembly, without the
 * slot renderer's ownership check. This is the same deliberate bypass used by
 * the compact fallback row, generalized for the session header's child slots.
 */
export declare function NativeSlotHost({ slot, kind, source, locale, standard, owner, fallback, before, exclude, override, renderFactorySlot, }: NativeSlotHostProps): React.JSX.Element;
//# sourceMappingURL=native-slot-host.d.ts.map