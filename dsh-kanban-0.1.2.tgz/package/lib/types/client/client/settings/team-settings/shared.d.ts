import React from 'react';
import type { HubSharingView, HubState, Problem, SharingCommand } from '../../../shared/types.js';
export type Act = (label: string, command: SharingCommand) => Promise<boolean>;
export declare function VersionDiff({ detail }: {
    detail?: {
        local: string;
        team: string;
        localName: string;
        teamName: string;
    };
}): React.JSX.Element | null;
export declare function Blockers({ blockers }: {
    blockers: Array<{
        code: string;
        message: string;
    }>;
}): React.JSX.Element | null;
export declare function StatusLine({ sharing }: {
    sharing: HubSharingView;
}): React.JSX.Element;
/** The differences between the local Hub and the published configuration. */
export declare function ComparisonList({ sharing }: {
    sharing: HubSharingView;
}): React.JSX.Element;
/**
 * The two first-connection choices over a storage that already has a published
 * document. The storage supplies its own noun, notice, and footnote.
 */
export declare function ConnectionPreview({ hub, sharing, act, pending, noun, notice, footnote, disabled }: {
    hub: HubState;
    sharing: HubSharingView;
    act: Act;
    pending: string | null;
    noun: string;
    notice?: React.ReactNode;
    footnote?: React.ReactNode;
    disabled?: boolean;
}): React.JSX.Element;
/** The check interval, shared by every connected storage. */
export declare function IntervalSettings({ hubId, sharing, act, pending }: {
    hubId: string;
    sharing: HubSharingView;
    act: Act;
    pending: string | null;
}): React.JSX.Element;
/** Disconnect with its confirmation and the storage's own explanation. */
export declare function DisconnectAction({ hubId, act, pending, note }: {
    hubId: string;
    act: Act;
    pending: string | null;
    note: string;
}): React.JSX.Element;
/**
 * The surface every connected storage shares: status, blockers, the storage's
 * own actions, the check interval, and the per-board review.
 */
export declare function ConnectedStorageSurface({ hub, sharing, act, pending, summary, notice, actions, guidance, disconnectNote }: {
    hub: HubState;
    sharing: HubSharingView;
    act: Act;
    pending: string | null;
    summary?: React.ReactNode;
    notice?: React.ReactNode;
    actions: React.ReactNode;
    guidance?: React.ReactNode;
    disconnectNote: string;
}): React.JSX.Element;
export declare function BoardReview({ hubId, sharing, act, pending }: {
    hubId: string;
    sharing: HubSharingView;
    act: Act;
    pending: string | null;
}): React.JSX.Element;
export declare function RemovedBoards({ hubId, sharing, act, pending }: {
    hubId: string;
    sharing: HubSharingView;
    act: Act;
    pending: string | null;
}): React.JSX.Element | null;
export declare function ErrorBlock({ error }: {
    error: Problem | null;
}): React.JSX.Element;
//# sourceMappingURL=shared.d.ts.map