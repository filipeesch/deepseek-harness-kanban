import type { KanbanSnapshot, BoardState } from '../shared/types.js';
import { type RunCommand } from './ui.js';
export interface WorkflowEditorProps {
    state: BoardState;
    run: RunCommand;
    yaml: string;
    baseRevision: number;
    onYamlChange: (yaml: string) => void;
    onSaved: (snapshot: KanbanSnapshot) => void;
    onReload: () => void;
    /** Present only when the Hub is published; publishes this save immediately after it lands locally. */
    onShare?: () => Promise<void>;
}
/** Rich workflow YAML editor backed by the shared parser and a controlled CodeMirror surface. */
export declare function WorkflowEditor({ state, run, yaml, baseRevision, onYamlChange, onSaved, onReload, onShare }: WorkflowEditorProps): import("react").JSX.Element;
//# sourceMappingURL=workflow-editor.d.ts.map