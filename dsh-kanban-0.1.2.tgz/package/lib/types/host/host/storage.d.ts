import type { Context } from '@deepseek-ai/cordis';
import type { HubStorage, LegacyStateReader } from '../shared/ports.js';
/**
 * Open the Hub domain and, when needed, migrate the untouched legacy document.
 * The legacy domain is read once and never written.
 */
export declare function openKanbanStorage(ctx: Context, options?: {
    legacy?: LegacyStateReader;
    now?: () => string;
}): Promise<{
    storage: HubStorage;
    close: () => Promise<void>;
}>;
//# sourceMappingURL=storage.d.ts.map