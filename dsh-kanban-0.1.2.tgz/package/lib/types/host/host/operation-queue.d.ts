export interface OperationQueueJob {
    /** Destructive work is serialized inside a lane and may overlap across lanes. */
    lane: string;
    taskId: string;
    operationId: string;
    run: () => Promise<void>;
}
/**
 * FIFO host queue for destructive context operations with one lane per
 * repository. Each lane runs at most one job, so Git worktree metadata is never
 * touched twice at once while unrelated repositories keep making progress. The
 * queue never holds the command path: callers enqueue and return.
 */
export declare class OperationQueue {
    private readonly lanes;
    private readonly keys;
    private readonly idleWaiters;
    private disposed;
    get size(): number;
    /** Returns false when the queue is disposed; a duplicate operation is already queued and returns true. */
    enqueue(job: OperationQueueJob): boolean;
    /** Stop accepting work and prevent not-yet-started jobs from running. */
    dispose(): void;
    /** Resolve once every lane is idle and no queued job remains. */
    settle(): Promise<void>;
    private laneFor;
    private drain;
    private forget;
    private settleIdle;
}
//# sourceMappingURL=operation-queue.d.ts.map