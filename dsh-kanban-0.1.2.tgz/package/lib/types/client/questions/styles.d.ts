/**
 * Question strip styles. Every colour, radius, and focus ring comes from the
 * host theme tokens, so the strip follows light and dark appearance without a
 * second palette. Selectors stay scoped to the plugin's kq- classes.
 */
export declare const questionCss: string;
//# sourceMappingURL=styles.d.ts.map