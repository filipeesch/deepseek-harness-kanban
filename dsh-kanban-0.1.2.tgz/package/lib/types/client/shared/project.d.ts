import type { GitProject, Project } from './types.js';
/** A project is Git-backed exactly when it carries a non-empty Git root. */
export declare function isGitProject(project: Project): project is GitProject;
/** Narrow at the Git boundary; folder projects never reach a Git or worktree operation. */
export declare function requireGitProject(project: Project): GitProject;
//# sourceMappingURL=project.d.ts.map