import { type Diagnostic } from '@codemirror/lint';
export interface CodeEditorProps {
    value: string;
    onChange: (value: string) => void;
    label: string;
    readOnly?: boolean;
    diagnostics?: readonly Diagnostic[];
    onSaveShortcut?: () => void;
    describedBy?: string;
    className?: string;
}
/** Controlled CodeMirror host for workflow YAML; the view is created once per mount. */
export declare function CodeEditor({ value, onChange, label, readOnly, diagnostics, onSaveShortcut, describedBy, className }: CodeEditorProps): import("react").JSX.Element;
//# sourceMappingURL=code-editor.d.ts.map