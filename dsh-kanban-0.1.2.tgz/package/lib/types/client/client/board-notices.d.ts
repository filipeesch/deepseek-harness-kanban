import { type ReactNode } from 'react';
import type { Problem } from '../shared/types.js';
export interface BoardNoticesProps {
    loadError: Problem | null;
    actionError: Problem | null;
    onRetryLoad: () => void;
}
/** Board-level failures stay above the board body; the slot renders nothing while idle. */
export declare function BoardNotices({ loadError, actionError, onRetryLoad }: BoardNoticesProps): ReactNode;
//# sourceMappingURL=board-notices.d.ts.map