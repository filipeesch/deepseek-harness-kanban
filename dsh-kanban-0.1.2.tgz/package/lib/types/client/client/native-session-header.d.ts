import React, { type ReactNode } from 'react';
import { type NativeLocaleSource, type NativeSlotSource, type NativeSnapshotSource } from './native-slot-host.js';
import type { ModePort } from './mode-port.js';
import type { ConversationNavigation } from './conversation-navigation.js';
export interface NativeSessionHeaderProps {
    slots: NativeSlotSource;
    locale: NativeLocaleSource;
    standard: Record<string, unknown>;
    navigation: ConversationNavigation;
    modePort: ModePort | null;
    developerTools?: NativeSnapshotSource;
    renderFactorySlot?: unknown;
    /** Plugin-owned action rendered at the end of the native header row. */
    trailing?: ReactNode;
}
/**
 * Host the native session header above the native transcript. The child slots
 * are hosted manually because the slot renderer's ownership rules belong to
 * the native conversation root, which is private.
 */
export declare function NativeSessionHeader({ slots, locale, standard, navigation, modePort, developerTools, renderFactorySlot, trailing }: NativeSessionHeaderProps): React.JSX.Element;
//# sourceMappingURL=native-session-header.d.ts.map