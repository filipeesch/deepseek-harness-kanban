import React, { type ReactNode } from 'react';
import type { ConversationLeaseRegistry } from './conversation-leases.js';
/** Provide the lease scope owned by one mounted task drawer. */
export declare function ConversationLeasesProvider({ registry, children }: {
    registry: ConversationLeaseRegistry;
    children: ReactNode;
}): React.JSX.Element;
/** Read the drawer's lease scope; a conversation can only render inside a task drawer. */
export declare function useConversationLeases(): ConversationLeaseRegistry;
/** Read the drawer's lease scope when the current surface may render outside a leased drawer. */
export declare function useOptionalConversationLeases(): ConversationLeaseRegistry | null;
//# sourceMappingURL=conversation-lease-context.d.ts.map