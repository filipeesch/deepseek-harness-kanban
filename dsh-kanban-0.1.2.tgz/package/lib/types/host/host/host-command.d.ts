import { type ConfinedArgv } from '@deepseek-ai/dsh-sandbox';
import type { CommandResult } from '../shared/ports.js';
/** Spawn one exact argv with bounded output and lifetime; confinement wrapping is optional. */
export declare function executeCommand(argv: string[], cwd: string, wrapped: ConfinedArgv | undefined, signal: AbortSignal, timeout: AbortSignal): Promise<CommandResult>;
/** Run one plugin-owned, read-only host command without session confinement. */
export declare function runHostCommand(argv: string[], cwd: string, timeoutMs?: number): Promise<CommandResult>;
//# sourceMappingURL=host-command.d.ts.map