import React from 'react';
import type { ClientApi, Project } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
/** Focused create/edit surface; the registry list never embeds a form. */
export declare function ProjectEditorDialog({ api, hubId, expectedRevision, project, run, onClose, onSaved }: {
    api?: ClientApi;
    hubId?: string;
    expectedRevision?: number;
    project?: Project;
    run: RunCommand;
    onClose: () => void;
    onSaved: (id: string) => void;
}): React.JSX.Element;
//# sourceMappingURL=project-editor-dialog.d.ts.map