import type { ConversationFacts } from '../shared/types.js';
import { type KeyValueStorage } from './key-value-storage.js';
/**
 * One collaborator for per-conversation read state: which conversation is
 * displayed, which settled turn it acknowledged, and the durable record that
 * survives a reload.
 */
export declare class ConversationReadState {
    private readonly progress;
    private readonly tracker;
    constructor(storage?: KeyValueStorage);
    /** Refresh facts and acknowledge every conversation that is currently displayed. */
    sync(conversations: Readonly<Record<string, ConversationFacts>>): void;
    /** The acknowledged sequence for a conversation. */
    acknowledged(sessionId: string): number | undefined;
    /** Start reading one conversation; the returned release is idempotent. */
    view(sessionId: string): () => void;
    /** A closed tab stops notifying about the turn that had already settled. */
    close(sessionId: string): void;
    /** Drop acknowledgments for conversations that no longer belong to any task. */
    prune(known: ReadonlySet<string>): void;
    /** Persist coalesced acknowledgments immediately. */
    flush(): void;
}
//# sourceMappingURL=conversation-read-state.d.ts.map