import type { KanbanSnapshot, Task } from '../shared/types.js';
/**
 * Aggregated running work and attention for one Hub or board scope.
 * A task counts once no matter how many agents, subagents, jobs, or schedules it owns.
 */
export interface ScopeActivity {
    readonly runningTasks: number;
    /** The running tasks' titles, in task order, for the indicator's hover detail. */
    readonly runningTaskTitles: readonly string[];
    readonly unread: boolean;
    readonly awaitingReply: boolean;
    readonly failed: boolean;
}
export declare const EMPTY_SCOPE_ACTIVITY: ScopeActivity;
/**
 * A task runs while it has a running turn, an owned subagent still running, or
 * unsettled background work. Unread, awaiting-reply, and failure attention fold across the scope.
 */
export declare function projectScopeActivity(tasks: readonly Task[], attention: KanbanSnapshot['attention']): ScopeActivity;
//# sourceMappingURL=scope-activity.d.ts.map