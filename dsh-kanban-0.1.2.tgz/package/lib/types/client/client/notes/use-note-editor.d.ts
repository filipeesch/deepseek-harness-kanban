import type { Note, Problem } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
export type NoteEditorView = 'Edit' | 'Preview';
export interface NoteEditorController {
    content: string;
    tags: string[];
    view: NoteEditorView;
    pending: boolean;
    error: Problem | null;
    dirty: boolean;
    confirmingDelete: boolean;
    setContent(value: string): void;
    setTags(value: string[]): void;
    setView(value: NoteEditorView): void;
    save(): Promise<void>;
    requestDelete(): void;
    cancelDelete(): void;
    remove(): Promise<void>;
    close(): void;
}
/** One note draft: a fenced write lifetime keyed by the mounted task and note. */
export declare function useNoteEditor({ taskId, note, run, onSaved, onDeleted, onClose }: {
    taskId: string;
    note?: Note;
    run: RunCommand;
    onSaved(): void;
    onDeleted(): void;
    onClose(): void;
}): NoteEditorController;
//# sourceMappingURL=use-note-editor.d.ts.map