import type { Column, Workflow } from '../shared/types.js';
/** How a move from one existing stage to another relates to the workflow rule. */
export type TransitionAccess = 'reorder' | 'allowed' | 'restricted';
export interface TransitionDestination {
    column: Column;
    access: TransitionAccess | null;
}
/** Classifies a move between existing stages without applying any policy beyond the workflow. */
export declare function transitionAccess(workflow: Workflow, from: string, to: string): TransitionAccess | null;
/** Every workflow stage in workflow order, paired with its access from `from`. */
export declare function transitionDestinations(workflow: Workflow, from: string): TransitionDestination[];
/** A transition enters a different existing stage; same-stage ordering is separate. */
export declare function canTransition(workflow: Workflow, from: string, to: string): boolean;
//# sourceMappingURL=transitions.d.ts.map