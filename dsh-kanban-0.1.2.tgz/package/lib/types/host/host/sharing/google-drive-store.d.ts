import { type SharedHubDocument } from '../../domain/sharing/document.js';
import { GoogleDriveClient } from './google-drive-client.js';
import { type ProviderState, type SharingProviderDescriptor } from './provider.js';
import type { SharedConfigStore, SharedDocumentSnapshot } from './store.js';
export interface GoogleDriveStoreOptions {
    client: GoogleDriveClient;
    folderId: string;
    driveId?: string;
    state: ProviderState;
}
/**
 * One Hub document in a Drive folder. It owns the whole-document read/write
 * contract, the change cursor, and the best-effort concurrent-write check.
 */
export declare class GoogleDriveSharedConfigStore implements SharedConfigStore {
    private readonly client;
    private readonly folderId;
    private readonly stateValue;
    private folderChecked;
    constructor(options: GoogleDriveStoreOptions);
    state(): ProviderState;
    private get fileId();
    private get driveId();
    private rememberFile;
    private setWrittenFile;
    ensure(): Promise<void>;
    private advanceCursor;
    read(signal?: AbortSignal, cached?: SharedDocumentSnapshot | null): Promise<SharedDocumentSnapshot | null>;
    write(document: SharedHubDocument, options: {
        expectedToken: string | null;
        message: string;
    }, signal?: AbortSignal): Promise<{
        token: string;
    }>;
    destroy(): Promise<void>;
}
export interface GoogleDriveProviderOptions {
    auth: {
        accessToken(): Promise<string>;
        refreshAccessToken?(): Promise<string>;
    };
    fetch?: typeof fetch;
}
/** Parse a Drive folder link, `id=` URL, or raw id into a stable folder id. */
export declare function normalizeFolderAddress(value: string): string;
export declare function createGoogleDriveProviderDescriptor(options: GoogleDriveProviderOptions): SharingProviderDescriptor;
//# sourceMappingURL=google-drive-store.d.ts.map