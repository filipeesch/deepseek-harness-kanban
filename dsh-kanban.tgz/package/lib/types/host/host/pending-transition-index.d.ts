import type { TaskSummary } from './hub-repository.js';
/**
 * The task ids that currently hold a confirmed pending transition. It is derived from
 * repository state on every change, so command paths can skip the dispatch scan entirely
 * when nothing is pending instead of walking every task.
 */
export declare class PendingTransitionIndex {
    private ids;
    refresh(summaries: readonly TaskSummary[]): readonly string[];
    list(): readonly string[];
    get empty(): boolean;
}
//# sourceMappingURL=pending-transition-index.d.ts.map