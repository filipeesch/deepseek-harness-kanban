import type { Problem } from '../shared/types.js';
/** Convert any thrown value into the wire problem shape used by the UI. */
export declare function asProblem(error: unknown): Problem;
//# sourceMappingURL=problem.d.ts.map