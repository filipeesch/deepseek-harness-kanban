import type { Workflow } from '../shared/types.js';
export declare const DEFAULT_WORKFLOW_YAML: string;
/** Parse only the supported presentation/transition subset of workflow YAML. */
export declare function parseWorkflow(yaml: string): Workflow;
//# sourceMappingURL=workflow.d.ts.map