import type { HubState } from '../../shared/types.js';
import type { SharingPlan } from './plan.js';
export interface ApplySharingDeps {
    id: () => string;
    now: () => string;
}
export interface ApplySharingResult {
    created: Array<{
        boardId: string;
        key: string;
    }>;
}
/**
 * Apply a validated plan to one Hub draft. Every rule is checked before the
 * first mutation, so a rejected plan leaves the draft untouched; the caller
 * runs this inside a single Hub transaction.
 */
export declare function applySharingPlan(draft: HubState, plan: SharingPlan, deps: ApplySharingDeps): ApplySharingResult;
//# sourceMappingURL=apply.d.ts.map