import type { HubSharingView, SharingBoardState, SharingHubStatus } from '../../shared/types.js';
export declare const HUB_STATUS_LABEL: Record<SharingHubStatus, string>;
export declare const BOARD_STATE_LABEL: Record<SharingBoardState, string>;
export declare function boardSharing(view: HubSharingView | undefined, boardId: string): HubSharingView['boards'][number] | undefined;
export declare function isPubliclyEditable(view: HubSharingView | undefined): boolean;
/** Sharing is available only when the comparison has nothing blocking or unapplied. */
export declare function canShareFromEditor(view: HubSharingView | undefined, boardId: string): boolean;
//# sourceMappingURL=status.d.ts.map