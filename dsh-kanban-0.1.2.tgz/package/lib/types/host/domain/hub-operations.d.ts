import type { AutoModePause, Board, BoardSettings, HubState, HubTask, Note, Project, ProjectInput, Workflow } from '../shared/types.js';
import { type NoteInput } from './note.js';
export type { NoteInput } from './note.js';
export interface TaskTextPatch {
    title?: string;
    description?: string;
}
export interface OperationDeps {
    id: () => string;
    now: () => string;
}
export declare function requireBoard(hub: HubState, boardId: string): Board;
export declare function requireTask(hub: HubState, taskId: string): HubTask;
export declare function requireProject(hub: HubState, projectId: string): Project;
export declare function boardForTask(hub: HubState, task: HubTask): Board;
export declare function renameHub(hub: HubState, name: string, deps: OperationDeps): string;
export declare function addBoard(hub: HubState, name: string, deps: OperationDeps): Board;
export declare function renameBoard(hub: HubState, boardId: string, name: string, deps: OperationDeps): Board;
export declare function deleteBoard(hub: HubState, boardId: string, deps: OperationDeps): Board;
export declare function saveBoardWorkflow(hub: HubState, boardId: string, yaml: string, deps: OperationDeps): Workflow;
export declare function saveProject(hub: HubState, input: ProjectInput, deps: OperationDeps): Project;
export declare function deleteProject(hub: HubState, projectId: string, deps: OperationDeps): Project;
export declare function setProjectWorkspace(hub: HubState, projectId: string, workspaceId: string, owned: boolean, deps: OperationDeps): Project;
export declare function setTaskWorktreeWorkspace(hub: HubState, taskId: string, workspaceId: string, owned: boolean, deps: OperationDeps): HubTask;
export declare function createTask(hub: HubState, input: {
    boardId: string;
    projectId: string;
    title: string;
    description: string;
}, deps: OperationDeps): HubTask;
export declare function dismissWorktree(hub: HubState, taskId: string, deps: OperationDeps): HubTask;
export declare function setAutoMode(hub: HubState, taskId: string, enabled: boolean, deps: OperationDeps): HubTask;
export declare function pauseAutoMode(hub: HubState, taskId: string, pause: AutoModePause, deps: OperationDeps, expectedColumnId?: string): HubTask;
export declare function editTask(hub: HubState, taskId: string, patch: TaskTextPatch, deps: OperationDeps): HubTask;
export declare function addSession(hub: HubState, taskId: string, sessionId: string, deps: OperationDeps): HubTask;
export declare function closeSession(hub: HubState, taskId: string, sessionId: string, deps: OperationDeps): HubTask;
export declare function reopenSession(hub: HubState, taskId: string, sessionId: string, deps: OperationDeps): HubTask;
export declare function saveNote(hub: HubState, taskId: string, input: NoteInput, deps: OperationDeps): Note;
export declare function deleteNote(hub: HubState, taskId: string, noteId: string, deps: OperationDeps): Note;
export declare function placeTask(hub: HubState, taskId: string, columnId: string, beforeTaskId: string | null, enteredAt: number): void;
export declare function deleteTask(hub: HubState, taskId: string): HubTask;
export declare function normalizeSettings(input: BoardSettings): BoardSettings;
//# sourceMappingURL=hub-operations.d.ts.map