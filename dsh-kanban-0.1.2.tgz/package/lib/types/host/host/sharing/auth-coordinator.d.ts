import type { SharingAuthStatus, SharingAuthView, SharingCommand } from '../../shared/types.js';
import type { GoogleDriveAuthService } from './google-drive-auth.js';
/** The authorization operations the coordinator sequences; the OAuth service satisfies it. */
export interface GoogleDriveAuthPort {
    status(): Promise<SharingAuthView>;
    start(): Promise<string>;
    cancel(): Promise<void>;
    disconnect(): Promise<void>;
    listDrives(): Promise<Array<{
        id: string;
        name: string;
    }>>;
    listFolders(input?: {
        driveId?: string;
        parentId?: string;
    }): Promise<Array<{
        id: string;
        name: string;
    }>>;
}
/** The actions a device-level authorization surface can perform. */
export type GoogleDriveAuthAction = 'start' | 'cancel' | 'disconnect' | 'switch' | 'drives' | 'folders';
/** The narrow view of authorization the publishing service depends on. */
export interface SharingAuthorizationPort {
    status(): SharingAuthStatus;
    ensureConnected(): Promise<void>;
    cancel(): Promise<void>;
}
/** A publishing command that belongs to the authorization surface. */
export type AuthorizationCommand = Extract<SharingCommand, {
    type: 'sharing.auth.start' | 'sharing.auth.cancel' | 'sharing.auth.disconnect' | 'sharing.auth.switch' | 'sharing.drives' | 'sharing.folders';
}>;
/** Whether a publishing command belongs to the authorization surface. */
export declare function isAuthorizationCommand(command: SharingCommand): command is AuthorizationCommand;
export interface GoogleDriveAuthCoordinatorOptions {
    auth?: GoogleDriveAuthService | GoogleDriveAuthPort;
    onChange?: () => void;
}
/**
 * Owns the Google Drive authorization surface: the current view, the
 * sequential actions, and the cached status other components read. Publishing
 * operations never run inside it, so a slow sign-in cannot block a Hub lane.
 */
export declare class GoogleDriveAuthCoordinator implements SharingAuthorizationPort {
    private readonly options;
    private state;
    private tail;
    private disposed;
    constructor(options: GoogleDriveAuthCoordinatorOptions);
    view(): SharingAuthView;
    status(): SharingAuthStatus;
    /** Re-read the authorization state from the credential store. */
    refresh(): Promise<void>;
    /** Refuse a connection surface that needs an authorized account. */
    ensureConnected(): Promise<void>;
    cancel(): Promise<void>;
    /** Run one authorization action in order and publish the resulting view. */
    command(command: SharingCommand): Promise<void>;
    close(): Promise<void>;
    private problemOf;
    private run;
}
//# sourceMappingURL=auth-coordinator.d.ts.map