import type { StoredEntry } from '@deepseek-ai/dsh-client-ui-slots';
export type NativeSlotKind = 'single' | 'list';
/** Keep native work-details copy and hook names aligned with the host renderer. */
export declare function nativeHookPropName(source: string): string;
/** Order list winners the way the native actions/utilities bands render them. */
export declare function orderNativeListEntries(entries: readonly StoredEntry[]): readonly StoredEntry[];
/**
 * Select the entries a manual native-slot host can render.
 * Store-backed entries are excluded: a second store instance cannot control the
 * real native surface, so rendering one would be a broken affordance.
 */
export declare function renderableNativeEntries(entries: readonly StoredEntry[], kind: NativeSlotKind, options?: {
    exclude?: (entry: StoredEntry) => boolean;
    allowStore?: boolean;
}): readonly StoredEntry[];
/** Select the one native session-header entry; its own store seat is replaced by the host. */
export declare function selectNativeSessionHeaderEntry(entries: readonly StoredEntry[]): StoredEntry | undefined;
//# sourceMappingURL=native-slot-descriptors.d.ts.map