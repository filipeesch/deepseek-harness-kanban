/** The home-relative directory that holds the suggested per-Hub team folders. */
export declare const SUGGESTED_FOLDER_ROOT = ".dsh-kanban";
export interface FolderPathOptions {
    home?: string;
    cwd?: string;
    platform?: NodeJS.Platform;
}
/** Expand a leading `~` to the home directory, leaving every other path untouched. */
export declare function expandHome(value: string, home: string): string;
/** The lexical absolute form of a typed path, before any filesystem inspection. */
export declare function absoluteFolderPath(value: string, options?: FolderPathOptions): string;
/** The suggested default folder for one Hub. It is only a suggestion until the user connects. */
export declare function suggestedFolderPath(hubId: string, options?: FolderPathOptions): string;
/** Show a path relative to the home directory when it lives inside it. */
export declare function abbreviateHome(value: string, home: string): string;
/**
 * Directory identity used to detect that two bindings address one folder.
 * A case-insensitive filesystem resolves two spellings to one directory.
 */
export declare function folderIdentity(resolved: string, platform?: NodeJS.Platform): string;
/**
 * Whether one resolved path is the root itself or lies inside it, using the
 * same identity rule as a binding comparison. Both inputs are expected to be
 * resolved already; lexical `..` escapes are collapsed by `path.resolve`.
 */
export declare function isWithinPath(root: string, candidate: string, platform?: NodeJS.Platform): boolean;
export interface InspectedFolder {
    /** The canonical path with symbolic links resolved. */
    path: string;
    identity: string;
}
/**
 * Resolve and validate one directory: it must exist, be a directory, and be
 * writable. Every refusal is a distinct typed error so the interface can name
 * the condition that prevented the connection.
 */
export declare function inspectFolder(value: string, options?: FolderPathOptions): Promise<InspectedFolder>;
/** Create the suggested folder for a Hub. Any other path is the user's to create. */
export declare function createSuggestedFolder(hubId: string, options?: FolderPathOptions): Promise<void>;
/**
 * Resolve the managed publishing workspace before comparing it with an
 * inspected folder, so a symlinked ancestor cannot hide the overlap.
 */
export declare function resolveManagedRoot(managedRoot: string | undefined): Promise<string | undefined>;
/**
 * Refuse a directory that belongs to the plugin's own managed publishing
 * workspace, where a clone or an intermediate file would be mixed with team
 * configuration that this storage must not own.
 */
export declare function assertOutsideManagedRoot(resolved: string, managedRoot: string | undefined): void;
//# sourceMappingURL=local-folder-path.d.ts.map