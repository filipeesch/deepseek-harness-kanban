import type { Column, Task } from '../shared/types.js';
import { type AutoRunController, type AutoRunEntry, type AutoRunInput } from './auto-run.js';
import { type SessionTitleSource } from './conversation-label.js';
export declare function useAutoRunEntry(controller: AutoRunController, taskId: string): AutoRunEntry | undefined;
/** Whole seconds remaining at the deadline; recomputed locally so the controller never ticks. */
export declare function useCountdown(deadline: number | null): number;
export declare function CardInstructionAction({ task, column, controller, onRun }: {
    task: Task;
    column: Column;
    controller: AutoRunController;
    onRun?: (input: AutoRunInput) => void;
}): import("react").JSX.Element | null;
export declare function DrawerAutoRunNotice({ task, controller, columns, sessionTitles }: {
    task: Task;
    controller: AutoRunController;
    columns: readonly Column[];
    sessionTitles?: SessionTitleSource;
}): import("react").JSX.Element | null;
//# sourceMappingURL=auto-run-view.d.ts.map