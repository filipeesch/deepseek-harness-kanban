export interface DirectoryEntry {
    name: string;
    directory: boolean;
}
export interface DirectoryListing {
    entries: DirectoryEntry[];
    truncated: boolean;
}
/** The filesystem operations discovery needs; injectable so tests run without a real Drive. */
export interface DiscoveryFs {
    exists(value: string): Promise<boolean>;
    isDirectory(value: string): Promise<boolean>;
    /** Read at most `limit` entries; the flag reports whether more were present. */
    list(value: string, limit?: number): Promise<DirectoryListing>;
    realpath(value: string): Promise<string>;
}
export declare const nodeDiscoveryFs: DiscoveryFs;
//# sourceMappingURL=filesystem.d.ts.map