import type { DriveDiscoveryView } from '../../../shared/types.js';
import { DirectorySharedConfigStore, type DirectoryStoreOptions } from '../directory-store.js';
import { type FolderPathOptions } from '../local-folder-path.js';
import type { SharingProviderDescriptor } from '../provider.js';
import type { LocatedDriveFolder } from './discovery.js';
/** The discovery surface the descriptor and its store depend on. */
export interface DriveLocationResolver {
    locate(value: string): Promise<LocatedDriveFolder | undefined>;
    roots(): Promise<DriveDiscoveryView>;
    refresh(): Promise<DriveDiscoveryView>;
}
export interface GoogleDriveLocalStoreOptions extends DirectoryStoreOptions {
    /** The discovered location root the folder was selected in. */
    mountRoot: string;
    discovery: DriveLocationResolver;
    platform: NodeJS.Platform;
}
/**
 * A directory store that also proves its folder still belongs to the stored
 * Google Drive location. It re-resolves both paths before every operation, so a
 * folder replaced by an outward symlink can never be read or written, and it
 * refuses a location that discovery no longer reports.
 */
export declare class GoogleDriveLocalSharedConfigStore extends DirectorySharedConfigStore {
    private readonly driveOptions;
    constructor(driveOptions: GoogleDriveLocalStoreOptions);
    ensure(): Promise<void>;
    read(signal?: AbortSignal, cached?: Parameters<DirectorySharedConfigStore['read']>[1]): ReturnType<DirectorySharedConfigStore['read']>;
    write(document: Parameters<DirectorySharedConfigStore['write']>[0], options: Parameters<DirectorySharedConfigStore['write']>[1], signal?: AbortSignal): ReturnType<DirectorySharedConfigStore['write']>;
    private assertMount;
    private isDiscovered;
    private containsRoot;
}
export interface GoogleDriveLocalProviderOptions extends FolderPathOptions {
    discovery: DriveLocationResolver;
    /** A directory the plugin owns and never accepts as a team storage. */
    managedRoot?: string;
}
/** The Google Drive Local descriptor: continuous synchronization over a folder inside a Drive mount. */
export declare function createGoogleDriveLocalProviderDescriptor(options: GoogleDriveLocalProviderOptions): SharingProviderDescriptor;
//# sourceMappingURL=descriptor.d.ts.map