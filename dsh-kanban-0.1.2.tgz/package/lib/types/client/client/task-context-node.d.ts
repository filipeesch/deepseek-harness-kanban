import React from 'react';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { ChatNode, ChatNodeViewProps } from '@deepseek-ai/dsh-client-ui-chat/client';
import type { ContextProducerView, ConversationNodeDefinition, KnownContextForm } from '@deepseek-ai/dsh-client-ui-conversation/client';
import { type NativeSlotSource } from './native-slot-host.js';
export declare const TASK_CONTEXT_NODE_KIND = "kanban-task-context";
export declare const TASK_CONTEXT_SOURCE_KIND = "kanban-task";
/** Chat payload for the visible task-context row. */
export interface KanbanTaskContextData {
    readonly seq: number;
    readonly time: number;
    readonly content: readonly ContentBlock[];
    readonly source: unknown;
    readonly producer: ContextProducerView;
    readonly form: KnownContextForm | null;
}
declare module '@deepseek-ai/dsh-client-ui-chat/client' {
    interface ChatNodeDataMap {
        'kanban-task-context': KanbanTaskContextData;
    }
}
/**
 * Claim the durable `kanban-task` message before Chat's ordinary context
 * Definition hides it, and publish a visible custom node at its real position.
 */
export declare const taskContextDefinition: ConversationNodeDefinition<KanbanTaskContextData>;
export interface TaskContextNodeViewProps {
    node: ChatNode<'kanban-task-context'>;
    t?: ChatNodeViewProps<'kanban-task-context'>['t'];
    slots: NativeSlotSource;
}
/**
 * Delegate to the host's own context-row renderer so the visible row keeps the
 * native disclosure chrome and escaped-content behavior.
 */
export declare function TaskContextNodeView({ node, t, slots }: TaskContextNodeViewProps): React.JSX.Element;
export type TaskContextViewProps = ChatNodeViewProps<'kanban-task-context'>;
//# sourceMappingURL=task-context-node.d.ts.map