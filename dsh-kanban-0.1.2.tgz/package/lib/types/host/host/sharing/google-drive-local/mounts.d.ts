import type { DriveDiscoveryView, DriveLocationView } from '../../../shared/types.js';
/** A discovered Google Drive for desktop mount before it is projected for the client. */
export interface DriveMount {
    /** Stable identity: the root path. */
    id: string;
    rootPath: string;
    kind: 'account' | 'legacy';
    account?: string;
    driveName?: string;
    /** A source-specific explanation shown when the location is unavailable. */
    reason?: string;
}
/** One discovery source and whether it could be read. */
export interface DiscoverySourceResult {
    id: string;
    ok: boolean;
    reason?: string;
}
/** Everything one platform adapter can establish from local evidence. */
export interface DiscoveryEvidence {
    model: 'macos' | 'windows' | 'unsupported';
    mounts: DriveMount[];
    sources: DiscoverySourceResult[];
    /** Local evidence that the Drive for desktop application is present. */
    applicationDetected: boolean;
}
/** The projected discovery result the client consumes. */
export declare function projectDiscovery(evidence: DiscoveryEvidence, locations: DriveLocationView[]): DriveDiscoveryView;
//# sourceMappingURL=mounts.d.ts.map