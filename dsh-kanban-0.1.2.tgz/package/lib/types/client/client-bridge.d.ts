import { type ClientRemote } from '@deepseek-ai/dsh-api-gateway/client';
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol';
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionStatusSnapshot } from '@deepseek-ai/dsh-client-ui-session/client';
import type { KeyValueStorage } from './client/key-value-storage.js';
import type { KanbanRemote } from './remote.js';
import type { ClientApi, Outcome, Problem, QuestionRound } from './shared/types.js';
import { QuestionRoundCache, type QuestionRoundView } from './client/question-round-cache.js';
export interface BridgeStatus {
    error: Problem | null;
    connected: boolean;
}
export type BridgeRemote = Pick<ClientRemote, '$stream'> & {
    kanban: KanbanRemote;
};
/** Native transport result wraps the plugin's independent business Outcome. Unwrap BOTH. */
export declare function unwrap<T>(result: RemoteResult<Outcome<T>>): T;
/** One plugin-owned native feed; ordinary chats and Kanban share the same prepared question cache. */
export declare class ClientBridge {
    private readonly remote;
    private readonly nativeStatus;
    private readonly health;
    readonly status: HostObservable<BridgeStatus>;
    readonly questions: QuestionRoundCache;
    readonly questionsView: HostObservable<QuestionRoundView>;
    private readonly snapshots;
    private readonly running;
    private host;
    private merged;
    private clientEpoch;
    private readonly readState;
    private readonly composers;
    private readonly stopStatus;
    private control;
    private restarting;
    private disposed;
    readonly api: ClientApi;
    constructor(remote: BridgeRemote, nativeStatus: HostObservable<SessionStatusSnapshot>, options?: {
        storage?: KeyValueStorage;
    });
    private unarySnapshot;
    private makeControl;
    start(): void;
    retry(): void;
    private fail;
    private accept;
    /** A conversation whose tab just closed acknowledges the turn that had already settled. */
    private acknowledgeClosed;
    private publish;
    /** A conversation started running: ask the host for a freshly projected attention snapshot. */
    private refreshAttention;
    /** Acknowledge only the actually mounted/read drawer session, without native mainView writes. */
    viewSession(id: string): () => void;
    /** Prevent two plugin occurrences from mounting the same native composer simultaneously. */
    claimComposer(id: string): (() => void) | undefined;
    assertSubmissionAllowed(id: string): void;
    /** Track one conversation's question feed; the returned release closes it when the last holder leaves. */
    trackQuestions(id: string): () => void;
    /** Reopen a failed question feed without dropping the rounds already shown. */
    retryQuestions(id: string): void;
    /** Record that the host accepted the submission; a dropped round may now confirm it. */
    settleSubmission(id: string): void;
    /** Dismiss the displayed round and every other unresolved round in that conversation. */
    dismissQuestions(sessionId: string, roundId: string): Promise<readonly QuestionRound[]>;
    private openQuestionFeed;
    dispose(): Promise<void>;
}
//# sourceMappingURL=client-bridge.d.ts.map