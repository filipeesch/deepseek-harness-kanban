import type { GitPort, SessionPort } from '../shared/ports.js';
import type { GitProject, HubState, Project, Task } from '../shared/types.js';
import { type OperationJournal } from './operation-journal.js';
import { WorktreeSharingGuard } from './worktree-sharing.js';
export interface DestructiveStore {
    locate(taskId: string): {
        task: Task;
        project: Project;
        hub: HubState;
    };
    allTasks(): Task[];
    transactTask<T>(taskId: string, change: (draft: HubState) => T): Promise<T>;
}
/** Narrow view of the coordinator that destructive execution needs. */
export interface DestructiveOperationHost {
    read(taskId: string): {
        task: Task;
        project: Project;
        hub: HubState;
    };
    assertOpen(): void;
    signal: AbortSignal;
    idle(taskId: string, operationId: string): Promise<boolean>;
    switchDirectories(taskId: string, operationId: string, target: string, write: boolean, project: GitProject): Promise<boolean>;
    sourceUnchanged(taskId: string, expected: Project): void;
}
export interface DestructiveOperationOptions {
    now?: () => string;
    sharing?: WorktreeSharingGuard;
    onTaskDeleted?: (task: Task, project: Project) => Promise<void>;
}
type DriveResult = 'waiting' | 'done';
/**
 * Owns the journaled delete/remove execution that the host queue runs: the
 * authoritative preflight followed by the slow cleanup. It never schedules
 * itself and never runs on the interactive command path.
 */
export declare class DestructiveExecution {
    private readonly store;
    private readonly sessions;
    private readonly git;
    private readonly host;
    private readonly journal;
    private readonly now;
    private readonly sharing;
    private readonly onTaskDeleted?;
    readonly signal: AbortSignal;
    constructor(store: DestructiveStore, sessions: SessionPort, git: GitPort, host: DestructiveOperationHost, journal: OperationJournal, options?: DestructiveOperationOptions);
    private update;
    /** The authoritative preflight and the cleanup, both inside the queued lane. */
    drive(taskId: string, operationId: string): Promise<DriveResult>;
    private assertPreRemoval;
    private assertRemovalTarget;
    /** Force must not remove a checkout another task is actively operating on. */
    private assertNoActiveOperation;
    private markAffectedBindings;
    private affectedBindings;
    private removalProblem;
    private idle;
}
export {};
//# sourceMappingURL=destructive-operation.d.ts.map