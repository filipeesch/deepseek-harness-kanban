import React, { type ReactNode } from 'react';
import { type Attention, type BoardState, type ClientApi, type Column, type Task } from '../shared/types.js';
import { type RunCommand } from './ui.js';
import { type TaskPageState } from './page-state.js';
import type { AutoRunController } from './auto-run.js';
import type { SessionTitles } from './conversation-label.js';
import type { ConversationLineagePort, DrawerSubagentAddress } from './conversation-navigation.js';
import { type ConversationLeaseEnvironment } from './conversation-leases.js';
interface DrawerProps {
    task: Task;
    attention?: Attention;
    conversationAttention?: Readonly<Record<string, Attention>>;
    state: BoardState;
    api: ClientApi;
    run: RunCommand;
    autoRun?: AutoRunController;
    renderConversation: (id: string, target?: DrawerSubagentAddress) => ReactNode;
    onClose: () => void;
    onMove: (task: Task, column: Column, beforeTaskId?: string | null) => Promise<boolean>;
    onDanger: (task: Task, type: 'task.delete' | 'worktree.remove') => void;
    onToggleAutoMode?: (taskId: string, enabled: boolean) => void;
    autoModePending?: boolean;
    onForce?: (taskId: string) => void;
    viewState?: TaskPageState;
    sessionTitles?: SessionTitles;
    /** Lease scope for this drawer; omitted only by isolated render harnesses. */
    conversationLeases?: ConversationLeaseEnvironment;
    lineage?: ConversationLineagePort;
    /** Controlled investigation target; omitted keeps the drawer's transient local state. */
    peek?: DrawerSubagentAddress | null;
    onPeek?: (target: DrawerSubagentAddress | null) => void;
    entering?: boolean;
    closing?: boolean;
}
export declare function TaskDrawer({ task, attention, conversationAttention, state, api, run, autoRun, renderConversation, onClose, onMove, onDanger, onForce, onToggleAutoMode, autoModePending, viewState, sessionTitles, conversationLeases, lineage, peek: controlledPeek, onPeek, entering, closing }: DrawerProps): React.JSX.Element;
export {};
//# sourceMappingURL=drawer.d.ts.map