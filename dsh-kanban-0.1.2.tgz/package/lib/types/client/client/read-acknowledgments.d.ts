import type { KeyValueStorage } from './key-value-storage.js';
export declare const READ_ACKNOWLEDGMENTS_KEY = "dsh.kanban.readAcks";
/**
 * Per-conversation read progress. An absent entry means nothing was read, so a settled
 * turn reads as unread until the conversation is acknowledged. One versioned record
 * keeps the whole map durable behind the injected storage port.
 */
export declare class ReadAcknowledgments {
    private readonly storage;
    private readonly acknowledgedBySession;
    private pending;
    private dirty;
    constructor(storage: KeyValueStorage);
    /** The acknowledged turn sequence, or undefined when the conversation was never acknowledged. */
    acknowledged(sessionId: string): number | undefined;
    /** Advance the acknowledgment to `seq`; a lower or equal sequence is ignored. */
    acknowledge(sessionId: string, seq: number): void;
    /** Drop acknowledgments for conversations that no longer belong to any task. */
    prune(known: ReadonlySet<string>): void;
    /** Persist coalesced changes immediately, merging newer acknowledgments from another tab. */
    flush(): void;
    private schedule;
}
//# sourceMappingURL=read-acknowledgments.d.ts.map