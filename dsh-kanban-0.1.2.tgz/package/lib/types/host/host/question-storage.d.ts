import type { Context } from '@deepseek-ai/cordis';
import { z } from 'zod';
import type { QuestionSessionRecord } from '../questions/indexer.js';
/** Durable shape of one conversation's question projection. */
export declare const QuestionSessionRecordSchema: z.ZodObject<{
    version: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    events: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"human">;
        seq: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"end">;
        seq: z.ZodNumber;
        turn: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"call">;
        seq: z.ZodNumber;
        turn: z.ZodNumber;
        callId: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"native-page">;
        seq: z.ZodNumber;
        turn: z.ZodNumber;
        callId: z.ZodString;
        page: z.ZodObject<{
            question: z.ZodString;
            type: z.ZodEnum<{
                exclusive: "exclusive";
                non_exclusive: "non_exclusive";
                freetext: "freetext";
            }>;
            context: z.ZodOptional<z.ZodString>;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                description: z.ZodString;
            }, z.core.$strict>>>;
            weight: z.ZodOptional<z.ZodEnum<{
                critical: "critical";
                medium: "medium";
                easy: "easy";
            }>>;
            model_lean: z.ZodOptional<z.ZodString>;
            model_lean_reason: z.ZodOptional<z.ZodString>;
            answers_affect_followup: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"ptc-start">;
        seq: z.ZodNumber;
        callId: z.ZodString;
        rootCallId: z.ZodString;
        parentCallId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"ptc-page">;
        seq: z.ZodNumber;
        callId: z.ZodString;
        rootCallId: z.ZodString;
        parentCallId: z.ZodString;
        page: z.ZodObject<{
            question: z.ZodString;
            type: z.ZodEnum<{
                exclusive: "exclusive";
                non_exclusive: "non_exclusive";
                freetext: "freetext";
            }>;
            context: z.ZodOptional<z.ZodString>;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                description: z.ZodString;
            }, z.core.$strict>>>;
            weight: z.ZodOptional<z.ZodEnum<{
                critical: "critical";
                medium: "medium";
                easy: "easy";
            }>>;
            model_lean: z.ZodOptional<z.ZodString>;
            model_lean_reason: z.ZodOptional<z.ZodString>;
            answers_affect_followup: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>;
    }, z.core.$strict>], "kind">>;
    dismissedTurns: z.ZodOptional<z.ZodArray<z.ZodNumber>>;
}, z.core.$strict>;
/** Durable read/write surface owned by the host, never by a task record. */
export interface QuestionStore {
    load(sessionId: string): QuestionSessionRecord | undefined;
    save(sessionId: string, record: QuestionSessionRecord): Promise<void>;
}
/** Open the conversation-scoped question domain; the caller owns the returned close. */
export declare function openQuestionStorage(ctx: Context): Promise<{
    storage: QuestionStore;
    close: () => Promise<void>;
}>;
//# sourceMappingURL=question-storage.d.ts.map