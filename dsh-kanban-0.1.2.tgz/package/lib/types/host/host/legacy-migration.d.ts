import type { BoardState, HubState, KanbanMeta } from '../shared/types.js';
export declare const DEFAULT_HUB_ID = "default";
export declare const DEFAULT_BOARD_ID = "default-board";
export interface MigrationDeps {
    now: () => string;
}
/**
 * Map the previous single-board document into one Hub and one board.
 * The legacy document is never mutated. The board name is the workflow name
 * for a real legacy installation and `Kanban` for the untouched initial state.
 */
export declare function migrateLegacyState(state: BoardState, deps: MigrationDeps): {
    hub: HubState;
    meta: KanbanMeta;
};
//# sourceMappingURL=legacy-migration.d.ts.map