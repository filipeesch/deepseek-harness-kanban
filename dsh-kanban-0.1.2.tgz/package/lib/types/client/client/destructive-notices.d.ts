import React from 'react';
import type { Task } from '../shared/types.js';
/**
 * One board-level strip for destructive operations: queued/running work,
 * failures with their recovery actions, and retained plain checkouts. Per-task
 * detail stays in the card and the drawer.
 */
export declare function DestructiveOperationsNotice({ tasks, retained, onDismissRetained, onOpen, onRetry, onForce, onReturn }: {
    tasks: readonly Task[];
    retained: string | null;
    onDismissRetained: () => void;
    onOpen: (taskId: string) => void;
    onRetry: (taskId: string) => void;
    onForce: (taskId: string) => void;
    onReturn: (taskId: string) => void;
}): React.JSX.Element | null;
//# sourceMappingURL=destructive-notices.d.ts.map