import type { Project, Task } from '../shared/types.js';
import { type RunCommand } from './ui.js';
import { type WorktreeDraft } from './worktree-draft.js';
/** Conversation-area notice with a one-click create path and an explicit Git review path. */
export declare function WorktreeNotice({ task, project, draft, run, disabled, onReview }: {
    task: Task;
    project?: Project;
    draft: WorktreeDraft;
    run: RunCommand;
    disabled: boolean;
    onReview: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=worktree-notice.d.ts.map