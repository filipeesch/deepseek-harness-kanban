import React from 'react';
import type { Problem } from '../shared/types.js';
export interface TransitionOverrideDialogProps {
    taskTitle: string;
    workflowName: string;
    sourceName: string;
    destinationName: string;
    pending: boolean;
    problem: Problem | null;
    canRetry: boolean;
    onCancel: () => void;
    onConfirm: () => void;
}
export declare function TransitionOverrideDialog({ taskTitle, workflowName, sourceName, destinationName, pending, problem, canRetry, onCancel, onConfirm }: TransitionOverrideDialogProps): React.JSX.Element;
//# sourceMappingURL=transition-override-dialog.d.ts.map