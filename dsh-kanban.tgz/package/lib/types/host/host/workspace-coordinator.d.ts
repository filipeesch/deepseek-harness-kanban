import type { SessionPort, WorkspacePort } from '../shared/ports.js';
import type { HubTask, Project } from '../shared/types.js';
/** One task/project pair the coordinator may provision a workspace for. */
export interface WorkspaceTaskRef {
    hubId: string;
    task: HubTask;
    project: Project;
}
/** Durable workspace bindings owned by the Kanban state. */
export interface WorkspaceBindingStore {
    all(): WorkspaceTaskRef[];
    setProjectWorkspace(hubId: string, projectId: string, workspaceId: string, owned: boolean): Promise<void>;
    setTaskWorktreeWorkspace(hubId: string, taskId: string, workspaceId: string, owned: boolean): Promise<void>;
}
export interface WorkspaceCoordinatorOptions {
    workspaces: WorkspacePort;
    sessions: SessionPort;
    store: WorkspaceBindingStore;
    report?: (error: unknown) => void;
}
/**
 * Owns native workspace provisioning for the board: the shared project workspace,
 * task worktree workspaces, session-directory repair, and owned cleanup.
 */
export declare class WorkspaceCoordinator {
    private readonly options;
    constructor(options: WorkspaceCoordinatorOptions);
    ensureProject(hubId: string, project: Project): Promise<string | undefined>;
    ensureTaskWorkspace(hubId: string, task: HubTask, project: Project): Promise<string | undefined>;
    reconcile(): Promise<void>;
    cleanup(task: HubTask): Promise<void>;
    /** Visibility is presentation: a failed write is reported and never blocks the caller. */
    private setVisibility;
}
//# sourceMappingURL=workspace-coordinator.d.ts.map