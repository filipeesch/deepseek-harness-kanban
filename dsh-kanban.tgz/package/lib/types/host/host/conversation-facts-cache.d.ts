import { type ConversationFacts } from '../shared/types.js';
import type { ConversationFactsSource } from './native-facts.js';
/** Bounded re-reads after a transient facts failure; a new edge resets the allowance. */
export declare const MAX_READ_RETRIES = 5;
/** Presentation priority for one conversation's background read. */
export type FactsPriority = 'event' | 'active' | 'normal' | 'historical';
export interface ConversationFactsCacheOptions {
    source: ConversationFactsSource;
    /** How many background conversation reads may run at once. */
    concurrency?: number;
    /** Called once per resolved background batch, so the host can publish the new projection. */
    notify?: () => void;
    report?: (error: unknown) => void;
    /** Batch coalescing seam; defaults to one microtask so a wave of reads publishes once. */
    schedule?: (run: () => void) => void;
}
/**
 * Owns the conversation-facts cache, its retry allowance, and the bounded background
 * read queue. Admission reads start immediately through `read`; presentation reads are
 * queued by priority and publish once per batch. A failed read keeps its last known
 * facts so a presented indicator does not flicker, and no caller ever waits on the queue.
 */
export declare class ConversationFactsCache {
    private readonly options;
    private readonly cache;
    private readonly lastGood;
    private readonly failedReads;
    private readonly queue;
    private readonly concurrency;
    private readonly schedule;
    private active;
    private notification;
    private disposed;
    constructor(options: ConversationFactsCacheOptions);
    /** The single read used by admission and by the queue; deduped, retried by the coordinator. */
    read(sessionId: string): Promise<ConversationFacts>;
    /** Resolved facts only: never starts a read and never includes an unresolved conversation. */
    resolvedFor(sessionIds: readonly string[]): Record<string, ConversationFacts>;
    /**
     * Enqueue missing reads; an upgraded priority replaces the previous one. A conversation
     * with a failed read is retried only by the coordinator's bounded reconcile, never from
     * an `ensure` triggered by the publication it caused.
     */
    ensure(sessionIds: readonly string[], priority: FactsPriority): void;
    /** Drop one conversation's cached facts, or every conversation's facts, and reset its retry allowance. */
    touch(sessionId?: string): void;
    invalidate(sessionId?: string): void;
    clearFailures(sessionId?: string): void;
    /** Conversations still inside their bounded retry allowance. */
    failedIds(): string[];
    /** Whether this conversation currently has an in-flight or resolved read. */
    current(sessionId: string): boolean;
    /** A conversation whose retries are used up stays with its last known facts until a new edge. */
    isExhausted(sessionId: string): boolean;
    retrying(): boolean;
    /** Drop conversations that no longer belong to any task. */
    prune(known: ReadonlySet<string>): void;
    dispose(): void;
    private start;
    private pump;
    private takeNext;
    private notifyOnce;
}
//# sourceMappingURL=conversation-facts-cache.d.ts.map