import type { ConversationFacts } from '../shared/types.js';
/** The read-progress port the tracker needs; the durable store implements it. */
export interface ReadProgress {
    acknowledged(sessionId: string): number | undefined;
    acknowledge(sessionId: string, seq: number): void;
}
/**
 * Owns which conversations are being read. It acknowledges the settled turn of a
 * displayed conversation and of a closed tab, without knowing how the facts were
 * obtained or where the acknowledgment is stored.
 */
export declare class ConversationReadTracker {
    private readonly progress;
    private readonly viewers;
    private readonly facts;
    constructor(progress: ReadProgress);
    /** Refresh the facts and acknowledge every conversation that is currently displayed. */
    sync(conversations: Readonly<Record<string, ConversationFacts>>): void;
    /** Start reading one conversation; the returned release is idempotent. */
    view(sessionId: string): () => void;
    /** A closed tab stops notifying about the turn that had already settled. */
    close(sessionId: string): void;
    /** The acknowledged sequence for a conversation, as the durable store knows it. */
    acknowledged(sessionId: string): number | undefined;
    private mark;
}
//# sourceMappingURL=conversation-read-tracker.d.ts.map