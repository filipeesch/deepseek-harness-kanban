import type { Context } from '@deepseek-ai/cordis';
import { type UserMessage } from '@deepseek-ai/dsh-llm';
import type { Board, Task, Workflow } from '../shared/types.js';
import type { TaskLocator } from './task-locator.js';
/** Producer marker for the model-facing task context injected on a conversation's first turn. */
export interface KanbanTaskContextSource {
    readonly kind: 'kanban-task';
}
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'kanban-task': KanbanTaskContextSource;
    }
}
export type TaskContextInspect = (sessionId: string, signal?: AbortSignal) => Promise<{
    events: readonly unknown[];
}>;
export interface TaskContextOptions {
    inspect?: TaskContextInspect;
    report?: (error: unknown) => void;
}
/** The task envelope injected once before the first user message of a task conversation. */
export declare function buildTaskContextText(task: Task, stageName: string, hubName: string, board: Board): string;
export declare function createTaskContextMessage(task: Task, workflow: Workflow, hubName: string, board: Board): UserMessage;
/**
 * Inject the task context into the first pre-step with user input, once per live Agent.
 * The listener calls `next()` first so the existing execution guards keep their decision.
 */
export declare function registerTaskContextInjection(ctx: Context, locator: Pick<TaskLocator, 'bySession'>, options?: TaskContextOptions): () => void;
//# sourceMappingURL=task-context.d.ts.map