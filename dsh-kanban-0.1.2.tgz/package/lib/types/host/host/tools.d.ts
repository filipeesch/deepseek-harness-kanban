import type { Context } from '@deepseek-ai/cordis';
import { type ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { KanbanApp } from './app.js';
export declare function productToolDefinitions(app: KanbanApp): ToolDefinition[];
export declare function registerProductTools(ctx: Context, app: KanbanApp): () => void;
//# sourceMappingURL=tools.d.ts.map