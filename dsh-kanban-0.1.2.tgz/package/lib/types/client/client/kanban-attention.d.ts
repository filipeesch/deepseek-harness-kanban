import type { SessionStatusSnapshot } from '@deepseek-ai/dsh-client-ui-session/client';
import type { Attention, HostSnapshot } from '../shared/types.js';
/** Conversation-level and task-level attention derived from one Host snapshot. */
export interface TaskAttentionProjection {
    readonly attention: Record<string, Attention>;
    readonly conversationAttention: Record<string, Attention>;
}
/**
 * Project each task conversation's durable facts with the client-owned read
 * acknowledgment and aggregate them per task.
 */
export declare function projectTaskAttention(host: Pick<HostSnapshot, 'state' | 'conversations'>, statuses: SessionStatusSnapshot, acknowledged: (sessionId: string) => number | undefined): TaskAttentionProjection;
/** Tracks whether any conversation started running since the previous status snapshot. */
export declare class RunningSessions {
    private readonly sessions;
    /** @returns whether any conversation transitioned into running. */
    sync(statuses: SessionStatusSnapshot): boolean;
}
//# sourceMappingURL=kanban-attention.d.ts.map