import React, { type ReactNode } from 'react';
/** The active root conversation owned by the drawer's Conversations section. */
export interface ConversationActions {
    activeSessionId: string | null;
    canClose: boolean;
    pending: boolean;
    close(): void;
    label(sessionId: string): string;
}
export declare function ConversationActionsProvider({ value, children }: {
    value: ConversationActions;
    children: ReactNode;
}): React.JSX.Element;
export declare function useConversationActions(): ConversationActions;
/**
 * The drawer's close action consumes the active conversation through context:
 * the native session-header slot never receives drawer callbacks as props.
 * It renders nothing outside the drawer or when a subagent peek owns the view.
 */
export declare function ConversationCloseAction(): React.JSX.Element | null;
//# sourceMappingURL=conversation-actions.d.ts.map