import React from 'react';
import type { ClientApi, HubSharingView, HubState, SharingAuthView } from '../../../shared/types.js';
/** The Team Settings surface: one card per storage over per-storage panels. */
export declare function TeamSettings({ hub, sharing, auth, api }: {
    hub: HubState;
    sharing?: HubSharingView;
    auth?: SharingAuthView;
    api?: ClientApi;
}): React.JSX.Element;
//# sourceMappingURL=team-settings.d.ts.map