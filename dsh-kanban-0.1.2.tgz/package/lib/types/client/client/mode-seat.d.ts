import React from 'react';
import { ModeSeatController, type ModeSeatState } from './mode-seat-controller.js';
import type { ModePort } from './mode-port.js';
import { type NativeLocaleSource, type NativeSlotSource, type NativeSnapshotSource } from './native-slot-host.js';
/** One controller per hosted seat; loading is gated by the blank/root decision. */
export declare function useModeSeatController(port: ModePort | null, sessionId: string, currentPreset: () => string | undefined, enabled: boolean): {
    controller: ModeSeatController | null;
    state: ModeSeatState;
};
export interface NativeModeSeatProps {
    sessionId: string;
    source: NativeSlotSource;
    locale: NativeLocaleSource;
    standard: Record<string, unknown>;
    controller: ModeSeatController | null;
    enabled: boolean;
    developerTools?: NativeSnapshotSource;
}
/**
 * Render the host's actual agent-preset seat with a plugin controller. The
 * synthetic `useSessionRetainInfo` only satisfies the native main-view render
 * gate; the plugin never adds a real mainView retention.
 */
export declare function NativeModeSeat({ sessionId, source, locale, standard, controller, enabled, developerTools }: NativeModeSeatProps): React.JSX.Element | null;
//# sourceMappingURL=mode-seat.d.ts.map