import type { QuestionRound } from '../shared/types.js';
export interface QuestionFormProps {
    round: QuestionRound;
    hidden?: boolean;
    onSubmit(text: string): void | Promise<void>;
    onDismiss?(): void | Promise<void>;
    /** Called after the hidden form releases focus, so the host can return it to the composer. */
    onHide?(): void;
}
/** The fixed question strip docked above the composer: pages first, Additional Notes last. */
export declare function QuestionForm({ round, hidden, onSubmit, onDismiss, onHide }: QuestionFormProps): import("react").JSX.Element;
//# sourceMappingURL=QuestionForm.d.ts.map