import React from 'react';
import { type NativeLocaleSource, type NativeSlotSource } from '../native-slot-host.js';
/** DSH's composer model seat and its optional label child slot. */
export declare const MODEL_SELECTION_SLOT = "conversation.input.model";
export declare const MODEL_SELECTION_LABEL_SLOT = "conversation.input.model.label";
/** The native slot registry and locale the preparation borrows from the client generation. */
export interface PreparationSeat {
    readonly slots: NativeSlotSource;
    readonly locale: NativeLocaleSource;
}
/**
 * DSH's native model seat, mounted for a task conversation that is not rendered
 * inside the native conversation surface. The seat's own registration supplies
 * the catalog directory and its selection verbs; this adapter only supplies the
 * session identity, the locale, and the missing label-slot fallback. It never
 * calls `selectModel` itself, so an untouched seat submits nothing.
 */
export declare function NativeModelSeat({ seat, sessionId, onSelectingChange }: {
    seat: PreparationSeat;
    sessionId: string;
    onSelectingChange?: (selecting: boolean) => void;
}): React.JSX.Element;
//# sourceMappingURL=model-seat.d.ts.map