/** Publishing surfaces are scoped like every other plugin-owned selector. */
export declare const sharingStyles: string;
//# sourceMappingURL=styles.d.ts.map