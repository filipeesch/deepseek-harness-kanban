import type { Attention, BackgroundActivity, ConversationFacts } from '../shared/types.js';
/** Order the background items by family and bound each label for presentation. */
export declare function normalizeBackground(items: readonly BackgroundActivity[]): BackgroundActivity[];
/** The native status facts the projection reads; the client status snapshot satisfies it. */
export interface NativePendingStatus {
    readonly pendingInteraction?: unknown;
}
/**
 * Project one conversation's durable facts with the client-owned read acknowledgment.
 * Blue and red wait until no owned agent is running, so a delegation that has not
 * finished is never presented as a completed turn. The native status's pending
 * interaction joins the pending kinds, so the orange dot and the auto-mode hold
 * cannot disagree.
 */
export declare function projectConversation(facts: ConversationFacts, status: NativePendingStatus | undefined, acknowledged: number | undefined): Attention;
/** Combine one task's conversation attention into its card-level attention. */
export declare function aggregateTaskAttention(values: readonly Attention[]): Attention;
//# sourceMappingURL=attention-projection.d.ts.map