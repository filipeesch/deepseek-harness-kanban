import type { Session } from '@deepseek-ai/dsh-session';
import type { Context } from '@deepseek-ai/cordis';
/** The conversation facts derivable from event folds without reading a Session log. */
export interface ConversationFactsFold {
    readonly lastTurnEndSeq: number | null;
    readonly lastTurnOutcome: 'ok' | 'error' | null;
    readonly openApprovalIds: readonly string[];
}
/** Reads the registered fold for one live Session and releases its registration. */
export interface ConversationFactsReader {
    read(session: Session): ConversationFactsFold | undefined;
    dispose(): void;
}
export declare const CONVERSATION_FACTS_KEY = "kanbanConversationFacts";
interface FactsEvent {
    readonly type: string;
    readonly seq: number;
    readonly data: unknown;
}
/** Fold the settled-turn and approval facts from one committed event. */
export declare function applyConversationFacts(state: ConversationFactsFold, raw: FactsEvent): ConversationFactsFold;
/**
 * Register the host-only conversation-facts fold. The unit declares no wire
 * view, so its state never enters client payloads.
 * Registrations are awaited so the new handle API is used on newer hosts and
 * the legacy disposer plus registry read is used on older hosts.
 * @returns the reader used by the native facts port; reads are `undefined` when the registry is absent.
 */
export declare function registerConversationFacts(ctx: Context): Promise<ConversationFactsReader>;
export {};
//# sourceMappingURL=conversation-facts.d.ts.map