import { z } from 'zod';
import type { RemoteResult, RemoteStreamHandle } from '@deepseek-ai/dsh-typert-protocol';
import type { TypertContribution } from '@deepseek-ai/dsh-typert-registry';
import type { Command, DriveBrowseView, DriveDiscoveryView, HostSnapshot, HubSharingView, LocalDriveRequest, LocalDriveResult, Outcome, ProjectLocation, QuestionFeedFrame, QuestionRound, SharingAuthView, SharingCommand, SnapshotRequest } from './shared/types.js';
export declare const PACKAGE_NAME = "dsh-kanban";
export declare const CommandSchema: z.ZodType<Command>;
export declare const QuestionPageSchema: z.ZodObject<{
    question: z.ZodString;
    type: z.ZodEnum<{
        exclusive: "exclusive";
        non_exclusive: "non_exclusive";
        freetext: "freetext";
    }>;
    context: z.ZodOptional<z.ZodString>;
    options: z.ZodOptional<z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        description: z.ZodString;
    }, z.core.$strict>>>;
    weight: z.ZodOptional<z.ZodEnum<{
        critical: "critical";
        medium: "medium";
        easy: "easy";
    }>>;
    model_lean: z.ZodOptional<z.ZodString>;
    model_lean_reason: z.ZodOptional<z.ZodString>;
    answers_affect_followup: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export declare const QuestionRoundSchema: z.ZodObject<{
    id: z.ZodString;
    sessionId: z.ZodString;
    turnId: z.ZodString;
    pages: z.ZodArray<z.ZodObject<{
        callId: z.ZodString;
        sequence: z.ZodNumber;
        page: z.ZodObject<{
            question: z.ZodString;
            type: z.ZodEnum<{
                exclusive: "exclusive";
                non_exclusive: "non_exclusive";
                freetext: "freetext";
            }>;
            context: z.ZodOptional<z.ZodString>;
            options: z.ZodOptional<z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                description: z.ZodString;
            }, z.core.$strict>>>;
            weight: z.ZodOptional<z.ZodEnum<{
                critical: "critical";
                medium: "medium";
                easy: "easy";
            }>>;
            model_lean: z.ZodOptional<z.ZodString>;
            model_lean_reason: z.ZodOptional<z.ZodString>;
            answers_affect_followup: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    complete: z.ZodBoolean;
    answered: z.ZodBoolean;
}, z.core.$strict>;
export declare const QuestionFeedFrameSchema: z.ZodType<QuestionFeedFrame>;
export declare const SharingAuthViewSchema: z.ZodType<SharingAuthView>;
export declare const HubSharingViewSchema: z.ZodType<HubSharingView>;
export declare const DriveLocationViewSchema: z.ZodObject<{
    id: z.ZodString;
    rootPath: z.ZodString;
    kind: z.ZodEnum<{
        account: "account";
        legacy: "legacy";
    }>;
    status: z.ZodEnum<{
        unavailable: "unavailable";
        available: "available";
    }>;
    account: z.ZodOptional<z.ZodString>;
    driveName: z.ZodOptional<z.ZodString>;
    reason: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DriveDiscoveryViewSchema: z.ZodType<DriveDiscoveryView>;
export declare const DriveBrowseViewSchema: z.ZodType<DriveBrowseView>;
export declare const LocalDriveRequestSchema: z.ZodType<LocalDriveRequest>;
export declare const LocalDriveResultSchema: z.ZodType<LocalDriveResult>;
export declare const SnapshotRequestSchema: z.ZodType<SnapshotRequest>;
export declare const SnapshotSchema: z.ZodType<HostSnapshot>;
export declare const SharingCommandSchema: z.ZodType<SharingCommand>;
export declare const TYPERT_REMOTE: import("@deepseek-ai/dsh-typert-protocol").TypertRemoteInfo<Readonly<Record<string, import("@deepseek-ai/dsh-typert-protocol").TypertRemoteMethod<object, unknown, "unary", never, unknown> | import("@deepseek-ai/dsh-typert-protocol").TypertRemoteMethod<object, unknown, "stream", unknown, unknown>>>>;
export declare const TYPERT_HOST: TypertContribution;
export interface KanbanRemote {
    snapshot(request: SnapshotRequest): Promise<RemoteResult<Outcome<HostSnapshot>>>;
    command(request: Command): Promise<RemoteResult<Outcome<HostSnapshot>>>;
    sharing(request: SharingCommand): Promise<RemoteResult<Outcome<HostSnapshot>>>;
    branches(request: {
        taskId: string;
    }): Promise<RemoteResult<Outcome<string[]>>>;
    worktreeDefault(request: {
        taskId: string;
    }): Promise<RemoteResult<Outcome<{
        branchName: string;
        path: string;
    }>>>;
    detectProject(request: {
        path: string;
    }): Promise<RemoteResult<Outcome<ProjectLocation>>>;
    localDrive(request: LocalDriveRequest): Promise<RemoteResult<Outcome<LocalDriveResult>>>;
    dismissQuestions(request: {
        sessionId: string;
        roundId: string;
    }): Promise<RemoteResult<Outcome<QuestionRound[]>>>;
    questionsFollow(request: {
        sessionId: string;
    }, signal?: AbortSignal): RemoteStreamHandle<QuestionFeedFrame, never>;
    follow(signal?: AbortSignal): RemoteStreamHandle<HostSnapshot, never>;
}
declare module '@deepseek-ai/dsh-typert-protocol' {
    interface TypertRemoteNamespaceMap {
        kanban: KanbanRemote;
    }
    interface TypertRemoteMap {
        'kanban/snapshot': KanbanRemote['snapshot'];
        'kanban/command': KanbanRemote['command'];
        'kanban/sharing': KanbanRemote['sharing'];
        'kanban/branches': KanbanRemote['branches'];
        'kanban/worktreeDefault': KanbanRemote['worktreeDefault'];
        'kanban/detectProject': KanbanRemote['detectProject'];
        'kanban/localDrive': KanbanRemote['localDrive'];
        'kanban/dismissQuestions': KanbanRemote['dismissQuestions'];
        'kanban/questionsFollow': KanbanRemote['questionsFollow'];
        'kanban/follow': KanbanRemote['follow'];
    }
}
export default TYPERT_REMOTE;
//# sourceMappingURL=remote.d.ts.map