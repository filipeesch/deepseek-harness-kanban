import type { SessionStatusSnapshot } from '@deepseek-ai/dsh-client-ui-session/client';
import type { Attention, FullHostSnapshot } from '../shared/types.js';
/** Conversation-level and task-level attention derived from one Host snapshot. */
export interface TaskAttentionProjection {
    readonly attention: Record<string, Attention>;
    readonly conversationAttention: Record<string, Attention>;
}
/**
 * Project each task conversation's durable facts with the client-owned read
 * acknowledgment and aggregate them per task.
 */
export declare function projectTaskAttention(host: Pick<FullHostSnapshot, 'state' | 'conversations'>, statuses: SessionStatusSnapshot, acknowledged: (sessionId: string) => number | undefined): TaskAttentionProjection;
/** Whether two presented attention values are indistinguishable to every surface. */
export declare function sameAttention(left: Attention, right: Attention): boolean;
/**
 * Projects task attention while keeping each unchanged task's and conversation's object
 * identity. Memoized cards compare that identity, so an attention-only publication only
 * re-renders the cards whose presentation actually changed.
 */
export declare class AttentionProjector {
    private attention;
    private conversationAttention;
    project(host: Pick<FullHostSnapshot, 'state' | 'conversations'>, statuses: SessionStatusSnapshot, acknowledged: (sessionId: string) => number | undefined): TaskAttentionProjection;
}
/** Tracks which conversations started running since the previous status snapshot. */
export declare class RunningSessions {
    private readonly sessions;
    /** @returns the conversations that transitioned into running. */
    sync(statuses: SessionStatusSnapshot): string[];
}
//# sourceMappingURL=kanban-attention.d.ts.map