import type { Column, ConversationFacts, PendingUserWork, Task, Workflow } from '../shared/types.js';
/** One automatic advance's resolved path: every stage crossed, ending at the destination. */
export interface AutoAdvancePlan {
    /** The stage the resolution started from; admission requires the task to still be there. */
    fromColumnId: string;
    path: Column[];
    destination?: Column;
    /** The destination's entry instruction, or undefined when the destination has none. */
    instruction?: string;
}
/** Why a completed turn does not advance the task, or that it does. */
export type AdvanceDecision = 
/** The task itself is busy with a context operation, a confirmed transition, or an unresolved entry. */
{
    readonly kind: 'busy';
}
/** An open conversation is still executing; the ending conversation is retried after the settle delay. */
 | {
    readonly kind: 'running';
    readonly sessions: readonly string[];
}
/** The task still owes the user input; nothing is admitted and nothing is recorded. */
 | {
    readonly kind: 'pending';
    readonly pending: PendingUserWork;
} | {
    readonly kind: 'advance';
};
/**
 * Decide what a completed turn means for one task. The precedence is deliberate:
 * a busy task is skipped silently, an executing open conversation waits for the
 * settle delay, and pending user work is a hold that never records a pause.
 */
export declare function resolveAdvanceDecision(task: Task, facts: ReadonlyMap<string, ConversationFacts>): AdvanceDecision;
/**
 * The configured destination for one stage: the first configured allowed
 * transition when the stage configures transitions, otherwise the following
 * column in workflow order. A self or unknown target has no destination.
 */
export declare function nextConfiguredColumn(workflow: Workflow, fromColumnId: string): Column | undefined;
/**
 * Resolve the automatic advance path. Stages without an entry instruction are
 * crossed toward the first reachable instructed stage; when no reachable stage
 * has one, the path ends at the last reachable stage. A stage already visited in
 * the same resolution is never revisited, so a configured cycle cannot loop.
 */
export declare function resolveAutoAdvance(workflow: Workflow, fromColumnId: string): AutoAdvancePlan;
//# sourceMappingURL=auto-advance.d.ts.map