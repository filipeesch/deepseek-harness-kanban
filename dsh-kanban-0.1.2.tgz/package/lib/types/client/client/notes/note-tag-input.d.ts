import React from 'react';
/** Chip input: Enter or a comma turns the drafted text into a normalized chip. */
export declare function NoteTagInput({ value, suggestions, disabled, onChange }: {
    value: string[];
    suggestions: string[];
    disabled?: boolean;
    onChange: (tags: string[]) => void;
}): React.JSX.Element;
//# sourceMappingURL=note-tag-input.d.ts.map