import type { Board, HubState, HubTask } from '../shared/types.js';
/** The task scope an admission needs; the host resolves it from its task locator. */
export interface StageInstructionTarget {
    hubId: string;
    task: HubTask;
    board: Board;
}
export interface StageInstructionDeps {
    locate(taskId: string): StageInstructionTarget;
    transact(hubId: string, change: (draft: HubState) => void): Promise<unknown>;
    /** The first open conversation, creating one when every tab is closed. */
    resolveSession(task: HubTask): Promise<string>;
    assertExecutionContext(sessionId: string): Promise<void>;
    send(sessionId: string, text: string, requestId?: string): Promise<void>;
}
export interface StageInstructionRequest {
    taskId: string;
    /** The stage whose entry instruction is being admitted. */
    columnId: string;
    /** The exact instruction text to send. */
    instruction: string;
    /** When set, the current workflow instruction must still equal this reviewed value. */
    reviewedInstruction?: string;
    /** When set, the persisted entry must still carry this identity. */
    expectedEnteredAt?: number;
    /** Native prompt identity; omitted keeps a fresh identity per send. */
    requestId?: string;
    /** An already resolved target; omitted resolves the first open conversation. */
    sessionId?: string;
}
/**
 * The one host admission path for a stage instruction. The card action, the
 * confirmed-transition drain, and the automatic advance all validate the stage,
 * the reviewed text, and the entry identity here, and clear the entry marker
 * only after a successful send.
 */
export declare function admitStageInstruction(deps: StageInstructionDeps, request: StageInstructionRequest): Promise<string>;
//# sourceMappingURL=stage-instruction.d.ts.map