import React from 'react';
import type { Task } from '../shared/types.js';
import { type RunCommand } from './ui.js';
export declare function OperationStatus({ task, run, sessionTitles, onForce }: {
    task: Task;
    run: RunCommand;
    sessionTitles?: {
        title(sessionId: string): string | undefined;
    };
    onForce?: (taskId: string) => void;
}): React.JSX.Element | null;
//# sourceMappingURL=operation-status.d.ts.map