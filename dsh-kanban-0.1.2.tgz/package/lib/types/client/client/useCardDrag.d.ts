export interface CardDragState {
    taskId: string;
    sourceColumnId: string;
    overColumnId: string;
    overColumnName: string;
    indicatorY: number;
    beforeTaskId: string | null;
}
export interface CardDragOptions {
    enabled: boolean;
    canDrop: (columnId: string, taskId: string) => boolean;
    onDrop: (taskId: string, columnId: string, beforeTaskId: string | null) => void;
}
/** Pointer-driven card dragging with a cloned ghost and an insertion indicator. */
export declare function useCardDrag(options: CardDragOptions): {
    drag: CardDragState | null;
    begin: (event: React.PointerEvent<HTMLElement>, taskId: string, sourceColumnId: string) => void;
    shouldSuppressClick: () => boolean;
};
//# sourceMappingURL=useCardDrag.d.ts.map