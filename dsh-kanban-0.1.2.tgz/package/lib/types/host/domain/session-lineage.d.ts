import type { SessionLineage } from '../shared/ports.js';
/**
 * Resolve the sessions owned by a task's conversations.
 *
 * Only explicit subagent edges are followed. Fork lineage and unrelated
 * sessions remain foreign, and an unknown parent is treated as unknown rather
 * than assumed owned.
 */
export declare function ownedSessionIds(roots: readonly string[], lineage: readonly SessionLineage[]): Set<string>;
//# sourceMappingURL=session-lineage.d.ts.map