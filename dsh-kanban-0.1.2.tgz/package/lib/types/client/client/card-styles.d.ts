/** Card surface presentation; concatenated into the board styles. */
export declare const cardStyles: string;
//# sourceMappingURL=card-styles.d.ts.map