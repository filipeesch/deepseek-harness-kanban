import React, { type ComponentType, type ReactNode } from 'react';
import type { SessionReference } from '@deepseek-ai/dsh-api-session-controller/client';
import type { DrawerSubagentAddress } from './conversation-navigation.js';
/** The small owner share the retained surface needs from the Main slot. */
export interface ConversationSurfaceOwner {
    SessionProvider: ComponentType<{
        session: SessionReference;
        children: ReactNode;
    }>;
    renderSlot(key: 'kanban.session.header' | 'kanban.conversation', owner: object): ReactNode;
}
/** Application services used by the retained conversation surface. */
export interface ConversationSurfaceServices {
    claimComposer(sessionId: string): (() => void) | null;
}
/** Props for the public conversation.content occurrence embedded in a task drawer. */
export interface EmbeddedConversationBodyProps {
    sessionId: string;
    useSession: (selector: (value: {
        openState?: string;
        openError?: {
            message?: string;
        };
    }) => unknown) => unknown;
    renderFactorySlot: (name: string, input: unknown, options: unknown) => ReactNode;
    viewSession(sessionId: string): (() => void) | undefined;
}
/** Render the shared native content factory for one task conversation. */
export declare function EmbeddedConversationBody({ sessionId, useSession, renderFactorySlot, viewSession }: EmbeddedConversationBodyProps): string | number | boolean | React.JSX.Element | Iterable<React.ReactNode> | null | undefined;
declare function RetainedConversationView({ id, target, owner, services }: {
    id: string;
    target?: DrawerSubagentAddress;
    owner: ConversationSurfaceOwner;
    services: ConversationSurfaceServices;
}): React.JSX.Element;
/**
 * Retain one native session (or subagent address) through the drawer lease scope
 * and render the hosted header above the public content factory. The native
 * content owns history settling and open-failure presentation.
 */
export declare const RetainedConversation: React.MemoExoticComponent<typeof RetainedConversationView>;
export {};
//# sourceMappingURL=conversation-surface.d.ts.map