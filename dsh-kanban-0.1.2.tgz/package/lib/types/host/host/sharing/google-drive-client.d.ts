export interface GoogleDriveFile {
    id: string;
    name?: string;
    mimeType?: string;
    headRevisionId?: string;
    modifiedTime?: string;
    parents?: string[];
    driveId?: string;
    trashed?: boolean;
}
export interface GoogleDriveChange {
    fileId?: string;
    removed?: boolean;
    file?: GoogleDriveFile;
}
export interface GoogleDriveClientOptions {
    accessToken: () => Promise<string>;
    /** Force a token refresh after an API 401; the client retries once. */
    refresh?: () => Promise<string>;
    fetch?: typeof fetch;
}
/**
 * Small Drive v3 client. It owns HTTP mechanics and error mapping only; the
 * provider decides document semantics and the sync coordinator decides timing.
 */
export declare class GoogleDriveClient {
    private readonly accessToken;
    private readonly refresh;
    private readonly fetchImpl;
    constructor(options: GoogleDriveClientOptions);
    private send;
    private request;
    listDrives(): Promise<Array<{
        id: string;
        name: string;
    }>>;
    listFolders(input?: {
        driveId?: string;
        parentId?: string;
    }): Promise<Array<{
        id: string;
        name: string;
    }>>;
    getFile(fileId: string): Promise<GoogleDriveFile>;
    getContent(fileId: string): Promise<{
        content: string;
        file: GoogleDriveFile;
    }>;
    findDocument(folderId: string, driveId?: string): Promise<GoogleDriveFile | null>;
    /** Drive's `uploadType=multipart` expects RFC 2387 multipart/related, not multipart/form-data. */
    private multipart;
    createDocument(folderId: string, content: string): Promise<GoogleDriveFile>;
    updateContent(fileId: string, content: string): Promise<GoogleDriveFile>;
    getStartPageToken(driveId?: string): Promise<string>;
    listChanges(pageToken: string, driveId?: string): Promise<{
        changes: GoogleDriveChange[];
        nextPageToken?: string;
        newStartPageToken?: string;
    }>;
}
//# sourceMappingURL=google-drive-client.d.ts.map