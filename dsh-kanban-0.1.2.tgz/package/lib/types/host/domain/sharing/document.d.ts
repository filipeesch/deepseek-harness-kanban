import { z } from 'zod';
/** The published document file name shared by every storage. */
export declare const SHARED_DOCUMENT_FILE = "kanban-hub.yaml";
/** The single published artifact: one ordered board list with authored workflow text. */
export interface SharedBoardEntry {
    key: string;
    name: string;
    workflow: string;
}
export interface SharedHubDocument {
    version: 1;
    boards: SharedBoardEntry[];
}
/** Stable board keys are file- and URL-safe, and never derived from a mutable local id. */
export declare const SHARED_BOARD_KEY_PATTERN: RegExp;
/** Shape validation for durable records; `parseSharedDocument` adds the workflow semantics. */
export declare const SharedHubDocumentSchema: z.ZodType<SharedHubDocument>;
/**
 * Parse a published document, normalize board names, and reject anything the
 * Hub could not hold: unsafe keys, duplicate keys, duplicate names, or a board
 * whose workflow text is not a valid workflow.
 */
export declare function parseSharedDocument(text: string): SharedHubDocument;
/** Canonical authored text; the workflow stays a literal block so diffs stay readable. */
export declare function serializeSharedDocument(document: SharedHubDocument): string;
/** Content identity. Formatting and board order changes that preserve meaning keep the token. */
export declare function sharedDocumentToken(document: SharedHubDocument): string;
export declare function sameSharedDocument(left: SharedHubDocument | null, right: SharedHubDocument | null): boolean;
export declare function boardContentKey(entry: {
    name: string;
    workflow: string;
}): string;
//# sourceMappingURL=document.d.ts.map