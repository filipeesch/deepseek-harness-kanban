import React from 'react';
/** One active tag filter; selecting it again or All clears the filter. */
export declare function NoteTagBar({ tags, active, onSelect }: {
    tags: string[];
    active: string | null;
    onSelect: (tag: string | null) => void;
}): React.JSX.Element;
//# sourceMappingURL=note-tag-bar.d.ts.map