import React from 'react';
import type { HubSharingView, SharingBoardState } from '../../shared/types.js';
/** The Hub-level publishing indicator, alongside the existing attention dots. */
export declare function HubPublishingBadge({ view }: {
    view?: HubSharingView;
}): React.JSX.Element | null;
/** The per-board publishing indicator shown on the board tab. */
export declare function BoardPublishingBadge({ state }: {
    state?: SharingBoardState;
}): React.JSX.Element | null;
//# sourceMappingURL=indicators.d.ts.map