import type { CommandResult } from '../../shared/ports.js';
/** One plugin-owned command invocation; injectable so tests avoid subprocesses. */
export type SharingCommandRunner = (argv: string[], cwd: string, timeoutMs?: number) => Promise<CommandResult>;
export declare const defaultSharingCommandRunner: SharingCommandRunner;
//# sourceMappingURL=command-runner.d.ts.map