import React from 'react';
import type { Note } from '../../shared/types.js';
/** List cards keep a scannable Markdown excerpt and open the overlay through the pencil action. */
export declare function NoteList({ notes, onEdit }: {
    notes: Note[];
    onEdit: (note: Note) => void;
}): React.JSX.Element;
//# sourceMappingURL=note-list.d.ts.map