import React from 'react';
import type { OperationDescription } from './operation-description.js';
/**
 * Shared recovery controls for a described context operation. The confirmation,
 * the drawer status, and the board notice render the same actions.
 */
export declare function OperationRecoveryActions({ description, pending, context, onRetry, onReturn, onForce }: {
    description: OperationDescription;
    pending?: boolean;
    /** Distinguishes the same action when it is repeated in the board notice. */
    context?: string;
    onRetry?: () => void;
    onReturn?: () => void;
    onForce?: () => void;
}): React.JSX.Element | null;
//# sourceMappingURL=operation-actions.d.ts.map