import React from 'react';
import type { DirectoryPickerPort } from './directory-picker.js';
export declare function DirectoryPickerProvider({ picker, children }: {
    picker: DirectoryPickerPort | null;
    children: React.ReactNode;
}): React.JSX.Element;
/** A missing picker is a valid state: the UI keeps manual path entry available. */
export declare function useDirectoryPicker(): DirectoryPickerPort | null;
//# sourceMappingURL=services.d.ts.map