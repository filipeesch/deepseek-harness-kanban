import { type Dispatch, type SetStateAction } from 'react';
export type DrawerSection = 'Conversations' | 'Info' | 'Git' | 'Notes';
export interface InfoDraft {
    title: string;
    description: string;
}
export interface TaskPageState {
    section: DrawerSection;
    conversationId: string | null;
    conversationSelectionRequired?: boolean;
    infoDraft?: InfoDraft;
    noteTagFilter?: string;
}
/** Plugin-lifetime UI bookmarks only: never store native views, transports, or session references here. */
export interface BoardPageState {
    search: string;
    projectFilter: string;
    selectedTaskId: string | null;
    drawers: Record<string, TaskPageState>;
}
export declare function createBoardPageState(): BoardPageState;
export declare function createTaskPageState(): TaskPageState;
/** Pick the visible conversation for the tab strip and the status row. */
export declare function resolveActiveConversation(sessionIds: readonly string[], closedSessionIds: readonly string[], selected: string | null, fallbackAllowed: boolean): string | null;
export declare function taskPageState(state: BoardPageState, taskId: string): TaskPageState;
/** Write through synchronously so a navigation unmount cannot race a deferred persistence effect. */
export declare function usePageField<T extends object, K extends keyof T>(source: T, key: K): [T[K], Dispatch<SetStateAction<T[K]>>];
//# sourceMappingURL=page-state.d.ts.map