import React from 'react';
import type { Attention, Column, Task } from '../shared/types.js';
import { type AutoRunController, type AutoRunInput } from './auto-run.js';
import { type AutoModeStatus, type AutoModeView } from './auto-mode.js';
export interface TaskCardProps {
    task: Task;
    column: Column;
    projectName: string;
    attention: Attention;
    selectionMode: boolean;
    selected: boolean;
    autoRun: AutoRunController;
    autoMode: AutoModeView;
    autoModePending?: boolean;
    onToggleAutoMode: (taskId: string, enabled: boolean) => void;
    onOpen: (taskId: string) => void;
    onToggleSelect: (taskId: string) => void;
    onBeginDrag: (event: React.PointerEvent<HTMLElement>, taskId: string, columnId: string) => void;
    shouldSuppressClick: () => boolean;
    /** Prepares the first execution before the card's run action sends anything. */
    onRun?: (input: AutoRunInput) => void;
}
export interface CardStatusEntry {
    key: string;
    tone: 'danger' | 'pending';
    label: string;
    alert?: boolean;
}
/** The card's status lines, in a stable order: operation, transition, stage-instruction failure, auto mode. */
export declare function cardStatusEntries(task: Task, runFailure?: string, autoStatus?: AutoModeStatus): CardStatusEntry[];
/** One task card; every board concern arrives through props. */
export declare function TaskCard({ task, column, projectName, attention, selectionMode, selected, autoRun, autoMode, autoModePending, onToggleAutoMode, onOpen, onToggleSelect, onBeginDrag, shouldSuppressClick, onRun }: TaskCardProps): React.JSX.Element;
//# sourceMappingURL=task-card.d.ts.map