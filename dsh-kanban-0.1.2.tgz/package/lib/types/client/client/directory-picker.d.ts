/** A directory selection surface; the composition root chooses the native source. */
export interface DirectoryPickerPort {
    pick(): Promise<string | null>;
}
export interface DirectoryPickerSources {
    /** Desktop renderer injected by the host application. */
    desktop?: () => Promise<string | null>;
    /** Host-provided directory picker service. */
    host?: () => Promise<string | null>;
}
/** Prefer the desktop picker; fall back to the host service only when it is absent. */
export declare function createDirectoryPicker(sources: DirectoryPickerSources): DirectoryPickerPort;
//# sourceMappingURL=directory-picker.d.ts.map