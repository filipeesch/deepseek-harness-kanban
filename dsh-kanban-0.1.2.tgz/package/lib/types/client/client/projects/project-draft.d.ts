import type { Project, ProjectInput, ProjectLocation } from '../../shared/types.js';
export interface ProjectDraft {
    id?: string;
    name: string;
    projectPath: string;
    gitRootPath: string;
    defaultBranch: string;
    /** Fields the user changed; detection never overwrites an edited field unless it still matches the last detection. */
    edited: {
        name: boolean;
        gitRootPath: boolean;
        defaultBranch: boolean;
    };
    /** Last values produced by detection, used to keep pristine fields in sync. */
    detected: {
        gitRootPath: string;
        defaultBranch: string;
    };
}
export declare function createProjectDraft(project?: Project): ProjectDraft;
export declare function editProjectDraft(draft: ProjectDraft, field: 'name' | 'projectPath' | 'gitRootPath' | 'defaultBranch', value: string): ProjectDraft;
/** Apply a detection result without replacing values the user owns. */
export declare function applyDetection(draft: ProjectDraft, location: ProjectLocation): ProjectDraft;
export declare function canSaveProject(draft: ProjectDraft): boolean;
/** Blank Git root means a folder project; a default branch without a Git root is never sent. */
export declare function toProjectInput(draft: ProjectDraft): ProjectInput;
//# sourceMappingURL=project-draft.d.ts.map