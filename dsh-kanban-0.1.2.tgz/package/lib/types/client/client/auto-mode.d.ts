import React from 'react';
import type { AutoModePauseReason, PendingUserWork, Task, Workflow } from '../shared/types.js';
/** The card and drawer state derived from the task's persisted auto mode, transition, and pending user work. */
export type AutoModeState = 'off' | 'armed' | 'advancing' | 'failed' | 'paused' | 'held' | 'instruction' | 'dead-end';
export interface AutoModeStatus {
    tone: 'pending' | 'danger';
    label: string;
    alert?: boolean;
}
export interface AutoModeView {
    enabled: boolean;
    state: AutoModeState;
    /** Accessible name of the toggle, describing the action it performs. */
    toggleLabel: string;
    title: string;
    status?: AutoModeStatus;
    /** The drawer's sentence for the current state; absent when there is nothing to say. */
    notice?: string;
    destinationName?: string;
    reason?: AutoModePauseReason;
    /** The held state's sentence naming what the user still owes the task; absent outside that state. */
    waitLabel?: string;
}
/** The held sentence: what the user still owes, in the order the pending value keeps. */
export declare function pendingWorkLabel(pending: PendingUserWork): string;
/** The short pause sentence shared by the card status strip and the drawer notice. */
export declare function pauseLabel(reason: AutoModePauseReason, message?: string): string;
/** One derivation for the card chip, the status strip, and the drawer notice. */
export declare function autoModeView(task: Task, workflow: Workflow, pendingWork?: PendingUserWork): AutoModeView;
/** The card's always-visible toggle and state indicator. */
export declare function CardAutoModeControl({ view, pending, onToggle }: {
    view: AutoModeView;
    pending?: boolean;
    onToggle?: (enabled: boolean) => void;
}): React.JSX.Element;
/** The drawer header's mirrored toggle, presenting the same state as the card control. */
export declare function DrawerAutoModeToggle({ view, pending, disabled, onToggle }: {
    view: AutoModeView;
    pending?: boolean;
    disabled?: boolean;
    onToggle?: (enabled: boolean) => void;
}): React.JSX.Element;
/** The drawer's automatic-advance notice, shown above the section panel. */
export declare function AutoModeNotice({ view }: {
    view: AutoModeView;
}): React.JSX.Element | null;
//# sourceMappingURL=auto-mode.d.ts.map