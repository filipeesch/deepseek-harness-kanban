import React from 'react';
import type { BoardSettings as BoardSettingsInput, KanbanSettings } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
export declare function GeneralSettings({ settings, settingsRevision, run }: {
    settings?: BoardSettingsInput | KanbanSettings;
    settingsRevision: number;
    run: RunCommand;
}): React.JSX.Element;
//# sourceMappingURL=general-settings.d.ts.map