import React from 'react';
import type { Attention } from '../shared/types.js';
export type AttentionState = Pick<Attention, 'unread' | 'awaitingReply' | 'failed'>;
/** Human-readable states shared by the visible dots and the hidden summaries. */
export declare function attentionStatusLabels(value: AttentionState): string[];
/**
 * The three coexisting attention dots. Non-decorative uses expose each dot's meaning;
 * decorative uses hide them so the surrounding control keeps one stable accessible name.
 */
export declare function AttentionDots({ value, label, decorative }: {
    value: AttentionState;
    label?: string;
    decorative?: boolean;
}): React.JSX.Element | null;
/** Hidden text that folds the same states into a surrounding control's accessible name. */
export declare function AttentionStatusText({ value }: {
    value: AttentionState;
}): React.JSX.Element | null;
//# sourceMappingURL=attention-dots.d.ts.map