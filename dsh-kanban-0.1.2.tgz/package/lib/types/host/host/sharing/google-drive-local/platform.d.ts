import { type SharingCommandRunner } from '../command-runner.js';
import { type DiscoveryFs } from './filesystem.js';
import type { DiscoveryEvidence } from './mounts.js';
export interface DriveDiscoveryAdapter {
    readonly model: 'macos' | 'windows' | 'unsupported';
    discover(): Promise<DiscoveryEvidence>;
}
export interface DriveDiscoveryAdapterOptions {
    platform: NodeJS.Platform;
    home?: string;
    fs?: DiscoveryFs;
    runner?: SharingCommandRunner;
    env?: NodeJS.ProcessEnv;
}
/**
 * Pick the adapter for the current platform. The platform is injected so the
 * Windows and macOS parsers can be exercised from any test machine.
 */
export declare function createDriveDiscoveryAdapter(options: DriveDiscoveryAdapterOptions): DriveDiscoveryAdapter;
//# sourceMappingURL=platform.d.ts.map