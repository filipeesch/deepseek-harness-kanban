import type { QuestionAnswer, QuestionPage, QuestionRound } from '../shared/types.js';
/** An answer marker that cannot be confused with an agent-provided option title. */
export declare const OTHER_CHOICE = "__kanban_other__";
export type QuestionAnswers = Readonly<Record<string, QuestionAnswer>> | ReadonlyMap<string, QuestionAnswer>;
/** Validate tool-owned semantics rather than relying on unsupported JSON Schema keywords. */
export declare function validateQuestionPage(value: unknown): QuestionPage;
export declare function emptyAnswer(): QuestionAnswer;
export declare function answerFor(answers: QuestionAnswers, callId: string): QuestionAnswer | undefined;
export declare function isAnswerValid(page: QuestionPage, answer: QuestionAnswer | undefined): boolean;
/** Format exactly one ordinary user message. No decision records or native interaction replies. */
export declare function formatAnswers(round: QuestionRound, answers: QuestionAnswers, generalNotes?: string): string;
//# sourceMappingURL=validation.d.ts.map