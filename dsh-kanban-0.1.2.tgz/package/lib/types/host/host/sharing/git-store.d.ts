import { type SharedHubDocument } from '../../domain/sharing/document.js';
import { type SharingCommandRunner } from './command-runner.js';
import type { ProviderState, SharingProviderDescriptor } from './provider.js';
import type { SharedConfigStore, SharedDocumentSnapshot } from './store.js';
export { SHARED_DOCUMENT_FILE } from '../../domain/sharing/document.js';
export { sharingRoot } from './root.js';
export type { SharingCommandRunner } from './command-runner.js';
export declare class GitSharedConfigStore implements SharedConfigStore {
    private readonly options;
    private readonly runner;
    private ready;
    constructor(options: {
        root: string;
        hubId: string;
        repository: string;
        runner?: SharingCommandRunner;
    });
    private get clonePath();
    private git;
    private require;
    ensure(): Promise<void>;
    private prepare;
    private fetch;
    /** Commit of the remote default branch, or null for a repository with no commits. */
    private remoteHead;
    private branchName;
    private rawAt;
    read(signal?: AbortSignal, _cached?: SharedDocumentSnapshot | null): Promise<SharedDocumentSnapshot | null>;
    state(): ProviderState;
    write(document: SharedHubDocument, options: {
        expectedToken: string | null;
        message: string;
    }, signal?: AbortSignal): Promise<{
        token: string;
    }>;
    destroy(): Promise<void>;
}
/** The Git storage descriptor: explicit publish, repository address, managed clone. */
export declare function createGitProviderDescriptor(options: {
    root: string;
    runner?: SharingCommandRunner;
}): SharingProviderDescriptor;
//# sourceMappingURL=git-store.d.ts.map