import { type SharedHubDocument } from './document.js';
import { type BoardBindings, type OrphanMap } from './identity.js';
import type { LocalSharedBoard } from './projection.js';
/** Display states shared with the client. */
export type BoardSharingState = 'in-sync' | 'draft' | 'updates-available' | 'needs-review' | 'orphan';
export type BoardDecision = BoardSharingState | 'create' | 'adopt' | 'reconnect' | 'remove';
export interface SharingBlocker {
    code: 'SHARING_ORPHAN_COLUMNS' | 'SHARING_NAME_COLLISION' | 'SHARING_NAME_CONFLICT';
    message: string;
    boardId?: string;
    boardName?: string;
    columnId?: string;
    tasks?: number;
}
export interface SharingContent {
    name: string;
    workflow: string;
}
export interface BoardComparison {
    decision: BoardDecision;
    /** True while this decision still requires Get updates to become local state. */
    pending: boolean;
    boardId?: string;
    key?: string;
    name: string;
    local?: SharingContent;
    published?: SharingContent;
    base?: SharingContent;
    tasks: number;
}
export interface RemovedBoardComparison {
    boardId: string;
    key: string;
    name: string;
}
export interface SharingComparison {
    boards: BoardComparison[];
    removed: RemovedBoardComparison[];
    blockers: SharingBlocker[];
    drafts: number;
    updates: number;
    conflicts: number;
    /** The team changed the relative order of boards that exist in both documents. */
    orderChanged: boolean;
}
export interface SharingInput {
    /** Last received document; null before the first receive, which enables first-connection adoption. */
    base: SharedHubDocument | null;
    published: SharedHubDocument;
    local: LocalSharedBoard[];
    bindings: Readonly<BoardBindings>;
    orphans: Readonly<OrphanMap>;
    /** Keys the user removed only from this installation. */
    removed: Readonly<Record<string, {
        boardId: string;
        name: string;
    }>>;
    /** Keys this installation is about to remove for the team. */
    pendingRemovals: readonly string[];
}
export type ApplyDecision = 'updates-available' | 'create' | 'adopt' | 'reconnect';
export interface SharingPlan {
    comparison: SharingComparison;
    apply: Array<{
        boardId?: string;
        key: string;
        name: string;
        workflow: string;
    }>;
    removals: string[];
    orphans: Array<{
        boardId: string;
        lastKey: string;
        lastPublishedName: string;
    }>;
    reconnections: Array<{
        boardId: string;
        key: string;
    }>;
    conflicts: Array<{
        boardId: string;
        key: string;
        name: string;
    }>;
    /** Published order to apply; present only when the team reordered shared boards. */
    order?: Array<{
        key: string;
        boardId?: string;
    }>;
    nextBase: SharedHubDocument;
}
export declare function isApplyDecision(decision: BoardDecision): decision is ApplyDecision;
export declare function displayState(decision: BoardDecision): BoardSharingState;
/**
 * Compare the last received document, the current local Hub, and the published
 * document. Pure: no clock, no I/O, no mutation.
 */
export declare function compareSharing(input: SharingInput): SharingComparison;
/** Build the update application plan. Blockers make the plan unapplyable, never partial. */
export declare function buildUpdatePlan(input: SharingInput): SharingPlan;
export interface PublishDocument {
    document: SharedHubDocument;
    bindings: BoardBindings;
}
/**
 * Compose what this installation would publish: every local board in document
 * order, preserved entries this installation removed only locally, and no
 * orphan. Allocates keys for boards entering the document for the first time.
 */
export declare function buildPublishDocument(input: {
    base: SharedHubDocument | null;
    local: readonly LocalSharedBoard[];
    bindings: Readonly<BoardBindings>;
    orphans: Readonly<OrphanMap>;
    pendingRemovals: readonly string[];
    /** Keys that must not be reused, such as an orphan's removed key. */
    reserved?: Iterable<string>;
}): PublishDocument;
export declare function publishIsDirty(document: SharedHubDocument, base: SharedHubDocument | null): boolean;
//# sourceMappingURL=plan.d.ts.map