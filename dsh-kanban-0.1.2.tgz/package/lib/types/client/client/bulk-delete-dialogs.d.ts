import React from 'react';
import type { Attention, Task } from '../shared/types.js';
export declare function BulkDeleteDialog({ tasks, attention, onCancel, onConfirm }: {
    tasks: Task[];
    attention: Record<string, Attention>;
    onCancel: () => void;
    onConfirm: () => void;
}): React.JSX.Element;
//# sourceMappingURL=bulk-delete-dialogs.d.ts.map