/**
 * Prompt identities this host admitted itself, per conversation. A queued stage
 * instruction is the host's own work, not input the user still owes the task, so
 * the pending-user-work read skips it. The ledger is bounded rather than pruned by
 * the queue's current contents: a prompt is recorded before its queue insertion is
 * observable, so pruning on absence could forget an instruction that is about to
 * appear and read it back as user work.
 */
export declare class PluginPromptLedger {
    private readonly bySession;
    add(sessionId: string, requestId: string): void;
    has(sessionId: string, requestId: string): boolean;
}
export interface QueuedPromptDeps {
    /** The live agent inbox, absent when the conversation is not attached. */
    live(sessionId: string): {
        nextTurn: readonly unknown[];
        nextStep: readonly unknown[];
    } | undefined;
}
/**
 * Count the user messages queued for a later turn in one conversation. A live
 * conversation reads its agent inbox synchronously; otherwise the durable inbox
 * projection the caller already read is the source, so one facts read never
 * fetches it twice. Only human input counts: the `next-step` list also parks
 * host-injected context notices that are not user work. An unreadable state
 * throws so callers fail closed instead of reporting an idle conversation.
 */
export declare function createQueuedPromptReader(deps: QueuedPromptDeps, own: PluginPromptLedger): (sessionId: string, projection: unknown) => number;
//# sourceMappingURL=queued-prompts.d.ts.map