import type { GitExecutor, GitPort, GitTree } from '../shared/ports.js';
import type { CreateWorktree, GitProject } from '../shared/types.js';
/** Resolve aliases, including the existing parent of a not-yet-created path. */
export declare function canonicalPath(value: string, allowMissing?: boolean): Promise<string>;
export declare function containsPath(root: string, candidate: string): boolean;
/** Production execution is exclusively delegated to the injected confined executor. */
export declare class GitAdapter implements GitPort {
    private readonly executor;
    constructor(executor: GitExecutor);
    assertPolicy(project: GitProject, paths: string[], sessionIds: string[], write: boolean): Promise<void>;
    private checked;
    private roots;
    private commonDirectory;
    private assertTarget;
    private registered;
    projectDirectory(project: GitProject, worktreeRoot?: string): Promise<string>;
    branches(project: GitProject, sessionIds: string[]): Promise<string[]>;
    inspect(project: GitProject, value: string, sessionIds: string[]): Promise<GitTree>;
    create(project: GitProject, request: CreateWorktree, sessionIds: string[], signal?: AbortSignal): Promise<GitTree>;
    remove(project: GitProject, value: string, discardChanges: boolean, sessionIds: string[], signal?: AbortSignal): Promise<void>;
}
//# sourceMappingURL=git.d.ts.map