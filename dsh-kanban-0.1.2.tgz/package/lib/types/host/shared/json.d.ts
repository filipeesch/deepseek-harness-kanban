export type Json = null | boolean | number | string | Json[] | {
    [key: string]: Json;
};
export declare function json(value: unknown): Json;
//# sourceMappingURL=json.d.ts.map