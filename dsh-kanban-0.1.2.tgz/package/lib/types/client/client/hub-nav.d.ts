import React from 'react';
import type { Board, HubSharingView, HubState } from '../shared/types.js';
import { type ScopeActivity } from './scope-activity.js';
export interface HubNavProps {
    hubs: readonly HubState[];
    /** Omitted when no Hub is active; an empty list still renders the row with its create action. */
    boards?: readonly Board[];
    activeHubId?: string;
    activeBoardId?: string;
    /** Aggregated activity per Hub id, already projected for the whole snapshot. */
    hubActivity: ReadonlyMap<string, ScopeActivity>;
    /** Aggregated activity per board id of the active Hub. */
    boardActivity: ReadonlyMap<string, ScopeActivity>;
    onSelectHub: (hubId: string) => void;
    onSelectBoard: (hubId: string, boardId: string) => void;
    onCreateHub: () => void;
    onCreateBoard: () => void;
    /** Publishing state per Hub, projected from the host snapshot. */
    sharing?: Readonly<Record<string, HubSharingView>>;
}
/** Hub and board tab rows; every fact and callback arrives through props. */
export declare function HubNav({ hubs, boards, activeHubId, activeBoardId, hubActivity, boardActivity, onSelectHub, onSelectBoard, onCreateHub, onCreateBoard, sharing }: HubNavProps): React.JSX.Element;
//# sourceMappingURL=hub-nav.d.ts.map