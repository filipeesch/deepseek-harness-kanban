import React from 'react';
import type { Project, Task } from '../shared/types.js';
import type { DestructiveRequest } from './destructive-dialogs.js';
/** The single deletion/removal consequence list shared by destructive dialogs. */
export declare function DestructiveConsequences({ request, task, project, busy }: {
    request: DestructiveRequest;
    task: Task;
    project?: Project;
    busy?: boolean;
}): React.JSX.Element;
//# sourceMappingURL=destructive-consequences.d.ts.map