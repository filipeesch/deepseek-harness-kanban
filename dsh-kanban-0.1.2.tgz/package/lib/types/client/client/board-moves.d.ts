import React, { type ReactNode } from 'react';
import type { BoardState, Column, Command, KanbanSnapshot, Task } from '../shared/types.js';
import { type CardDragState } from './useCardDrag.js';
import { type OptimisticMove } from './useMoveRequest.js';
import type { AutoRunController, AutoRunInput } from './auto-run.js';
import type { PrepareExecution } from './execution-preparation/contract.js';
export interface BoardMovesOptions {
    state: BoardState | null;
    run: (command: Command) => Promise<KanbanSnapshot>;
    autoRun: AutoRunController;
    selectionMode: boolean;
    prepare: PrepareExecution;
    onError: (error: unknown) => void;
    /** Clears a previous board notice when a new move starts. */
    onMoveStart?: () => void;
}
export interface BoardMoves {
    optimistic: OptimisticMove | null;
    drag: CardDragState | null;
    begin: (event: React.PointerEvent<HTMLElement>, taskId: string, sourceColumnId: string) => void;
    shouldSuppressClick: () => boolean;
    moveTo: (task: Task, column: Column, beforeTaskId?: string | null) => Promise<boolean>;
    /** The card's run action: prepare the first execution when needed, then send. */
    requestRun: (input: AutoRunInput) => void;
    /** The restricted-transition confirmation owned by the move request. */
    overrideDialog: ReactNode;
}
/**
 * The board's move pipeline: drag, validated move request, optimistic placement,
 * countdown arming, and the first-execution preparation. It owns every dialog
 * the pipeline opens so `BoardView` only renders the returned nodes.
 */
export declare function useBoardMoves({ state, run, autoRun, selectionMode, prepare, onError, onMoveStart }: BoardMovesOptions): BoardMoves;
//# sourceMappingURL=board-moves.d.ts.map