import React from 'react';
import type { ScopeActivity } from './scope-activity.js';
/**
 * The scope's running-task count: a pulsing ring in the host accent with its numeral.
 * The whole mark is one labeled image so the surrounding tab keeps a single accessible name,
 * and its title exposes the running task titles on hover.
 */
export declare function RunningTasksBadge({ activity }: {
    activity: ScopeActivity;
}): React.JSX.Element | null;
//# sourceMappingURL=running-tasks-badge.d.ts.map