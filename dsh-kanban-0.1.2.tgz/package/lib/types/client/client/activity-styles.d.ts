/** Working and background activity presentation; concatenated into the board styles. */
export declare const activityStyles: string;
//# sourceMappingURL=activity-styles.d.ts.map