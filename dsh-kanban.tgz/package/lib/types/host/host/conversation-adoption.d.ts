import { type ForkLineageFacts } from '../domain/session-lineage.js';
/** Header-derived facts for one announced native session. */
export interface ForkSessionFacts extends ForkLineageFacts {
    readonly sessionId: string;
}
/** The task facts adoption needs; an absent lookup means no task retains the session. */
export interface AdoptionTaskTarget {
    readonly hubId: string;
    readonly taskId: string;
    readonly effectiveCwd: string;
}
/**
 * Everything adoption reads or writes, injected so the coordinator stays
 * independent from the host services and from cordis.
 */
export interface ForkAdoptionPorts {
    /** Resolve the task that retains this exact conversation session, when any. */
    locate(sessionId: string): AdoptionTaskTarget | undefined;
    /** Read the committed effective directory of a native conversation. */
    directory(sessionId: string): Promise<string>;
    /** Move a native conversation to the task's effective directory; the signal cancels native I/O. */
    setDirectory(sessionId: string, directory: string, signal?: AbortSignal): Promise<void>;
    /** Retain the conversation as another conversation of the task at the expected directory. */
    attach(hubId: string, taskId: string, sessionId: string, expectedEffectiveCwd: string): Promise<void>;
    /** Abortable bounded wait used between attachment attempts. */
    sleep(milliseconds: number, signal?: AbortSignal): Promise<void>;
    report?(error: unknown): void;
}
export interface ForkAdopterOptions {
    /** Attachment attempts while the task reports a pending context operation. */
    attempts?: number;
    /** Wait before each retry, in milliseconds. */
    retryDelayMs?: number;
}
export type ForkAdoptionOutcome = 'adopted' | 'ignored' | 'failed' | 'cancelled';
/** Delay used as the default retry wait; rejects when the caller's signal aborts. */
export declare function abortableSleep(milliseconds: number, signal?: AbortSignal): Promise<void>;
/**
 * Adopt a fork of a task conversation as another conversation of that task.
 *
 * Adoption is best effort and never throws: a failure is reported and the
 * native fork stays usable as an unassociated session.
 */
export declare class ForkAdopter {
    private readonly ports;
    private readonly attempts;
    private readonly retryDelayMs;
    constructor(ports: ForkAdoptionPorts, options?: ForkAdopterOptions);
    /** Adopt one announced session when it is a fork of a retained task conversation. */
    adopt(facts: ForkSessionFacts, signal?: AbortSignal): Promise<ForkAdoptionOutcome>;
    private run;
    /** Apply the same directory alignment an explicit conversation creation applies. */
    private align;
    /** Reporting is best effort and must never break the native fork. */
    private report;
}
//# sourceMappingURL=conversation-adoption.d.ts.map