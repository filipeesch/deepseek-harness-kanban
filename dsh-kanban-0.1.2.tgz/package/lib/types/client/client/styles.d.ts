/** Every selector is scoped to plugin-owned classes; native chat controls retain their host styles. */
export declare const styles: string;
//# sourceMappingURL=styles.d.ts.map