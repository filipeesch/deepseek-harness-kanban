import React from 'react';
import type { Problem } from '../shared/types.js';
export interface ConversationNotice {
    key: string;
    problem: Problem | null;
}
/** One presentation point for the Conversations section notices. */
export declare function ConversationNotices({ notices }: {
    notices: readonly ConversationNotice[];
}): React.JSX.Element;
//# sourceMappingURL=conversation-notices.d.ts.map