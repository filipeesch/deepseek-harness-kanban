import React, { type FormEvent, type ReactNode } from 'react';
import type { KanbanSnapshot, Command, Problem } from '../shared/types.js';
import { asProblem } from './problem.js';
export { asProblem };
export type RunCommand = (command: Command) => Promise<KanbanSnapshot>;
/** Entity identity belongs to the exact command response, never to a snapshot set difference. */
export declare function creationReceiptId(snapshot: KanbanSnapshot, kind: NonNullable<KanbanSnapshot['commandReceipt']>['kind']): string | undefined;
export declare function ErrorNotice({ problem }: {
    problem: Problem | null;
}): React.JSX.Element | null;
export declare function ProblemNotice({ problem, title, sessionTitles, detailsLabel }: {
    problem: Problem | null;
    title?: string;
    sessionTitles?: {
        title(sessionId: string): string | undefined;
    };
    detailsLabel?: string;
}): React.JSX.Element | null;
export declare function Markdown({ children }: {
    children: string;
}): React.JSX.Element;
export declare function useAction(run: RunCommand): {
    pending: boolean;
    error: Problem | null;
    execute: (command: Command) => Promise<KanbanSnapshot | null>;
    clearError: () => void;
};
export declare function Modal({ title, children, onClose, busy, size, initialFocus, describedBy, headerActions }: {
    title: string;
    children: ReactNode;
    onClose: () => void;
    busy?: boolean;
    size?: 'default' | 'wide';
    initialFocus?: 'first' | 'cancel' | 'target';
    describedBy?: string;
    headerActions?: ReactNode;
}): React.JSX.Element;
export declare function Tabs({ label, values, selected, onSelect, id }: {
    label: string;
    values: readonly string[];
    selected: string;
    onSelect: (value: string) => void;
    id: string;
}): React.JSX.Element;
export declare function submit(event: FormEvent): void;
//# sourceMappingURL=ui.d.ts.map