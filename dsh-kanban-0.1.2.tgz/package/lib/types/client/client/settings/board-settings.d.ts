import React from 'react';
import type { Board, BoardState, ClientApi, HubSharingView, HubState } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
export declare function BoardSettings({ state, hub, board, run, api, sharing, onDeleted, workflowDraft, setWorkflowDraft }: {
    state: BoardState;
    hub: HubState | null;
    board: Board;
    run: RunCommand;
    api?: ClientApi;
    sharing?: HubSharingView;
    onDeleted?: () => void;
    workflowDraft: {
        yaml: string;
        revision: number;
    } | null;
    setWorkflowDraft: React.Dispatch<React.SetStateAction<{
        yaml: string;
        revision: number;
    } | null>>;
}): React.JSX.Element | null;
//# sourceMappingURL=board-settings.d.ts.map