import type { CommandResult, ProjectProbe } from '../shared/ports.js';
import type { ProjectLocation } from '../shared/types.js';
/** One plugin-owned command invocation; injectable so probes run without a subprocess in tests. */
export type ProbeRunner = (argv: string[], cwd: string) => Promise<CommandResult>;
/** Canonical, existing directory resolution for a picked path. */
export interface DirectoryProbe {
    resolve(value: string): Promise<string>;
}
/** Repository top-level discovery for a directory. */
export interface RepositoryProbe {
    locate(projectPath: string): Promise<string | null>;
}
/** Suggested default branch for a repository. */
export interface DefaultBranchProbe {
    resolve(gitRootPath: string): Promise<string | undefined>;
}
export declare function createDirectoryProbe(): DirectoryProbe;
export declare function createRepositoryProbe(run: ProbeRunner): RepositoryProbe;
/** Ordered candidate resolution: origin/HEAD, local main, local master, current branch, none. */
export declare function createDefaultBranchProbe(run: ProbeRunner): DefaultBranchProbe;
/** Composes the three probes into the single detection contract used by the app and the save path. */
export declare class HostProjectProbe implements ProjectProbe {
    private readonly directory;
    private readonly repository;
    private readonly branches;
    constructor(directory: DirectoryProbe, repository: RepositoryProbe, branches: DefaultBranchProbe);
    inspect(value: string): Promise<ProjectLocation>;
}
/** Production probe: host-level, read-only, outside any session sandbox. */
export declare function createHostProjectProbe(run?: ProbeRunner): ProjectProbe;
//# sourceMappingURL=project-probe.d.ts.map