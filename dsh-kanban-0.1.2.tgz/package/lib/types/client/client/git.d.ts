import React from 'react';
import type { ClientApi, CreateWorktree, Project, Task } from '../shared/types.js';
import { type RunCommand } from './ui.js';
import { type WorktreeDraft } from './worktree-draft.js';
export declare function useBranches(api: ClientApi, taskId: string): {
    branches: string[];
    pending: boolean;
    error: import("../shared/types.js").Problem | null;
    reload: () => void;
};
export declare function WorktreeFields({ value, onChange, branches, disabled, canReset, onResetPath, defaultBranchName }: {
    value: CreateWorktree;
    onChange: (value: CreateWorktree) => void;
    branches: string[];
    disabled?: boolean;
    canReset?: boolean;
    onResetPath?: () => void;
    defaultBranchName?: string;
}): React.JSX.Element;
export declare function PendingTransitionStatus({ task, run, columnName }: {
    task: Task;
    run: RunCommand;
    columnName: string;
}): React.JSX.Element | null;
export declare function GitPanel({ task, project, api, run, worktreeBasePath, draft }: {
    task: Task;
    project?: Project;
    api: ClientApi;
    run: RunCommand;
    worktreeBasePath?: string;
    draft: WorktreeDraft;
}): React.JSX.Element;
//# sourceMappingURL=git.d.ts.map