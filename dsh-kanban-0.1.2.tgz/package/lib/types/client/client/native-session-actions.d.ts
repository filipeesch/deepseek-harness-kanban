import React from 'react';
import type { StoredEntry } from '@deepseek-ai/dsh-client-ui-slots';
/** Translation seat for one native action namespace. */
export type NativeActionTranslate = (key: string, params?: Record<string, unknown>) => string;
export type NativeActionOverride = (entry: StoredEntry, face: Record<string, unknown>) => Record<string, unknown>;
export interface NativeSessionActionsProps {
    entries: readonly StoredEntry[];
    translate: (namespace: string) => NativeActionTranslate;
    /** Session standard props forwarded to every native action component. */
    standard: Record<string, unknown>;
    /** Redirect native callbacks (for example, keep subagent navigation in the drawer). */
    overrideFace?: NativeActionOverride;
}
/** Keep only the three status actions, in their native order. */
export declare function nativeStatusActions(entries: readonly StoredEntry[]): readonly StoredEntry[];
/**
 * Render the pinned host's native header actions without the slot renderer.
 * The entry component, inject face, and locale are private host contracts; this is intentionally
 * contained to the pinned DSH release and must hide, not fake, an unavailable action.
 */
export declare function NativeSessionActions({ entries, translate, standard, overrideFace }: NativeSessionActionsProps): React.JSX.Element | null;
//# sourceMappingURL=native-session-actions.d.ts.map