import type { Command, KanbanSnapshot, Problem, Task } from '../shared/types.js';
export interface BatchAdmissionRejection {
    title: string;
    problem: Problem;
}
export interface BatchDeletionOptions {
    run: (command: Command, allowDiscard?: boolean) => Promise<KanbanSnapshot>;
    /** Admission rejections are board errors; accepted tasks stay queued on the board. */
    onRejected: (rejections: readonly BatchAdmissionRejection[]) => void;
}
export interface BatchDeletion {
    pending: boolean;
    /** Fan out one deletion per task without holding the board while admission settles. */
    confirm: (tasks: readonly Task[]) => void;
}
/** Summarize per-task admission rejections into the board's single error surface. */
export declare function batchRejectionProblem(rejections: readonly BatchAdmissionRejection[]): Problem;
/**
 * Owns the bulk deletion fan-out. The confirmation closes before admission
 * settles: every selected task is dispatched at once, accepted tasks leave the
 * board through the published snapshot, and only admission rejections are
 * reported back.
 */
export declare function useBatchDeletion(options: BatchDeletionOptions): BatchDeletion;
//# sourceMappingURL=useBatchDeletion.d.ts.map