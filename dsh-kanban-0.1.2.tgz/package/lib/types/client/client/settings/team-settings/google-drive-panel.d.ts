import React from 'react';
import type { HubSharingView, HubState, SharingAuthView } from '../../../shared/types.js';
import type { Act } from './shared.js';
export declare function GoogleDriveStoragePanel({ hub, sharing, auth, act, pending }: {
    hub: HubState;
    sharing?: HubSharingView;
    auth?: SharingAuthView;
    act: Act;
    pending: string | null;
}): React.JSX.Element;
//# sourceMappingURL=google-drive-panel.d.ts.map