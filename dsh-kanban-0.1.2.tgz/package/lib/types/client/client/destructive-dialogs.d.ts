import React from 'react';
import type { Attention, Command, Problem, Project, Task } from '../shared/types.js';
import { type RunCommand } from './ui.js';
export type DestructiveCommand = Extract<Command, {
    type: 'task.delete' | 'worktree.remove';
}>;
export interface DestructiveRequest {
    command: DestructiveCommand;
    taskId: string;
    title: string;
    path: string | null;
    expectedWorktreePath: string | null;
    branch?: string | null;
    owned?: boolean;
    /** The checkout belongs to a project that no longer has a Git root and must be retained. */
    plainCheckout?: boolean;
    error?: Problem;
}
declare function DestructiveTaskDialog({ request, task, project, attention, sessionTitles, pending, problem, onCancel, onConfirm, onRetry, onReturn, onForce }: {
    request: DestructiveRequest;
    task: Task;
    project?: Project;
    attention: Attention;
    sessionTitles?: {
        title(sessionId: string): string | undefined;
    };
    pending: boolean;
    problem: Problem | null;
    onCancel: () => void;
    onConfirm: () => void;
    onRetry?: () => void;
    onReturn?: () => void;
    onForce?: () => void;
}): React.JSX.Element;
export declare function DiscardDialog({ request, run, onClose, onDeleted }: {
    request: DestructiveRequest;
    run: RunCommand;
    onClose: () => void;
    onDeleted: () => void;
}): React.JSX.Element;
/** Semantic entry points over the shared destructive dialog implementation. */
export declare const DeleteTaskDialog: typeof DestructiveTaskDialog;
export declare const RemoveWorktreeDialog: typeof DestructiveTaskDialog;
export {};
//# sourceMappingURL=destructive-dialogs.d.ts.map