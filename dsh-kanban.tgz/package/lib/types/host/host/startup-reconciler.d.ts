export interface StartupReconcilerOptions {
    signal?: AbortSignal;
    report?: (error: unknown) => void;
    /** How many background jobs run at once. */
    concurrency?: number;
}
/**
 * Runs plugin startup reconciliation off the interaction path: bounded concurrency,
 * one reported failure per job, and a settle seam for tests and shutdown. Jobs are
 * expected to be durable recovery steps that read Session history or the workspace
 * registry; the first snapshot never waits for them.
 */
export declare class StartupReconciler {
    private readonly options;
    private running;
    private disposed;
    constructor(options?: StartupReconcilerOptions);
    run(jobs: ReadonlyArray<() => Promise<void>>): void;
    /** Resolves when every scheduled job finished or was skipped after disposal. */
    whenSettled(): Promise<void>;
    dispose(): void;
    private execute;
}
//# sourceMappingURL=startup-reconciler.d.ts.map