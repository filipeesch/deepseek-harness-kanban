import React from 'react';
import type { Board, BoardState, ClientApi, HubSharingView, HubState, KanbanSettings, SharingAuthView } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
export declare function Configuration({ state, hub, board, hubCount, settings, settingsRevision, run, api, sharing, sharingAuth, onClose, initial, onHubDeleted, onBoardDeleted, onBoardCreated }: {
    state: BoardState | null;
    hub: HubState | null;
    board: Board | null;
    hubCount: number;
    settings?: KanbanSettings;
    settingsRevision: number;
    run: RunCommand;
    api?: ClientApi;
    sharing?: HubSharingView;
    sharingAuth?: SharingAuthView;
    onClose: () => void;
    initial?: string;
    onHubDeleted?: () => void;
    onBoardDeleted?: () => void;
    onBoardCreated?: (id: string) => void;
}): React.JSX.Element;
//# sourceMappingURL=configuration.d.ts.map