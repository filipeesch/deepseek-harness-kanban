import React, { type ReactNode } from 'react';
import type { Attention, Task } from '../shared/types.js';
import { type RunCommand } from './ui.js';
import { type TaskPageState } from './page-state.js';
import { type SessionTitles } from './conversation-label.js';
import { type ConversationLineagePort, type DrawerSubagentAddress } from './conversation-navigation.js';
export interface DrawerConversationsProps {
    task: Task;
    run: RunCommand;
    renderConversation: (id: string, target?: DrawerSubagentAddress) => ReactNode;
    viewState: TaskPageState;
    sessionTitles?: SessionTitles;
    peek: DrawerSubagentAddress | null;
    onPeek: (target: DrawerSubagentAddress | null) => void;
    lineage?: ConversationLineagePort;
    conversationAttention?: Readonly<Record<string, Attention>>;
    /** The task must resolve its worktree choice before an explicit first conversation. */
    worktreeDecisionRequired?: boolean;
    /** The client snapshot cannot resolve the task's project. */
    projectUnavailable?: boolean;
}
export declare function DrawerConversations({ task, run, renderConversation, viewState, sessionTitles, peek, onPeek, lineage, conversationAttention, worktreeDecisionRequired, projectUnavailable }: DrawerConversationsProps): React.JSX.Element;
//# sourceMappingURL=drawer-conversations.d.ts.map