import type { HostSnapshot, KanbanState } from '../shared/types.js';
/** A host frame merged with the board state the client holds. */
export type MergedHostSnapshot = HostSnapshot & {
    state: KanbanState;
};
/** A frame that cannot be merged without hiding a stale board. */
export declare class SnapshotProtocolError extends Error {
    constructor(message: string);
}
/**
 * Merge one accepted host frame with the state the client already holds. A baseline must
 * carry `state`; an update omits it exactly when its revision did not change.
 */
export declare function mergeSnapshotFrame(previous: MergedHostSnapshot | undefined, frame: HostSnapshot, baseline: boolean): MergedHostSnapshot;
//# sourceMappingURL=snapshot-merge.d.ts.map