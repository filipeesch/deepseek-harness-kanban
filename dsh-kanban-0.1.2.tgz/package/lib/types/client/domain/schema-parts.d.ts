import { z } from 'zod';
import type { Task, Workflow } from '../shared/types.js';
/**
 * Shared persisted-schema fragments. The legacy board aggregate and the Hub
 * aggregate validate the same task, workflow, note, and operation shapes; only
 * their cross-record rules differ, so each aggregate composes these parts and
 * keeps its own `superRefine`.
 */
export declare const id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
export declare const nonempty: z.ZodString;
export declare const absolutePath: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
export declare const timestamp: z.ZodString;
export declare const revision: z.ZodNumber;
type JsonValue = null | boolean | number | string | JsonValue[] | {
    [key: string]: JsonValue;
};
export declare const problem: z.ZodObject<{
    code: z.ZodString;
    message: z.ZodString;
    details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
}, z.core.$strict>;
export declare const createWorktree: z.ZodObject<{
    mode: z.ZodEnum<{
        new: "new";
        existing: "existing";
    }>;
    path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    branchName: z.ZodString;
    sourceBranch: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const operationRequest: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mode: z.ZodEnum<{
        new: "new";
        existing: "existing";
    }>;
    path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    branchName: z.ZodString;
    sourceBranch: z.ZodOptional<z.ZodString>;
    kind: z.ZodLiteral<"create">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"attach">;
    path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"remove">;
    discardChanges: z.ZodBoolean;
    expectedWorktreePath: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
    force: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"delete">;
    discardChanges: z.ZodBoolean;
    expectedWorktreePath: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
    force: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"return">;
}, z.core.$strict>], "kind">;
export declare const operation: z.ZodObject<{
    id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    request: z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodEnum<{
            new: "new";
            existing: "existing";
        }>;
        path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        branchName: z.ZodString;
        sourceBranch: z.ZodOptional<z.ZodString>;
        kind: z.ZodLiteral<"create">;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"attach">;
        path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"remove">;
        discardChanges: z.ZodBoolean;
        expectedWorktreePath: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
        force: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"delete">;
        discardChanges: z.ZodBoolean;
        expectedWorktreePath: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
        force: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"return">;
    }, z.core.$strict>], "kind">;
    phase: z.ZodEnum<{
        git: "git";
        queued: "queued";
        waiting: "waiting";
        preflight: "preflight";
        switching: "switching";
        removing: "removing";
        archiving: "archiving";
        failed: "failed";
    }>;
    targetPath: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    targetDirectory: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    previousDirectories: z.ZodRecord<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>, z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    switchedSessionIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    archivedSessionIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    createAttempt: z.ZodOptional<z.ZodObject<{
        operationId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        gitRootPath: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        branchName: z.ZodString;
        mode: z.ZodEnum<{
            new: "new";
            existing: "existing";
        }>;
        absentBefore: z.ZodLiteral<true>;
    }, z.core.$strict>>;
    gitCompleted: z.ZodBoolean;
    error: z.ZodOptional<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
        details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
    }, z.core.$strict>>;
    createdAt: z.ZodString;
}, z.core.$strict>;
export declare const pendingTransition: z.ZodObject<{
    id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    fromColumnId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    columnId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    mode: z.ZodEnum<{
        move: "move";
        run: "run";
    }>;
    sessionId: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    text: z.ZodOptional<z.ZodString>;
    beforeTaskId: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
    worktreeRequest: z.ZodOptional<z.ZodObject<{
        mode: z.ZodEnum<{
            new: "new";
            existing: "existing";
        }>;
        path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        branchName: z.ZodString;
        sourceBranch: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    transitionOverride: z.ZodOptional<z.ZodBoolean>;
    status: z.ZodEnum<{
        waiting: "waiting";
        failed: "failed";
        sending: "sending";
    }>;
    error: z.ZodOptional<z.ZodObject<{
        code: z.ZodString;
        message: z.ZodString;
        details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
    }, z.core.$strict>>;
    origin: z.ZodOptional<z.ZodLiteral<"auto">>;
}, z.core.$strict>;
export declare const autoModePause: z.ZodObject<{
    reason: z.ZodEnum<{
        "turn-error": "turn-error";
        "turn-blocked": "turn-blocked";
        "turn-aborted": "turn-aborted";
        "turn-max-tokens": "turn-max-tokens";
        "advance-failed": "advance-failed";
    }>;
    at: z.ZodString;
    message: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const autoMode: z.ZodObject<{
    enabled: z.ZodBoolean;
    pause: z.ZodOptional<z.ZodObject<{
        reason: z.ZodEnum<{
            "turn-error": "turn-error";
            "turn-blocked": "turn-blocked";
            "turn-aborted": "turn-aborted";
            "turn-max-tokens": "turn-max-tokens";
            "advance-failed": "advance-failed";
        }>;
        at: z.ZodString;
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const column: z.ZodObject<{
    id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    name: z.ZodString;
    onEnterPrompt: z.ZodOptional<z.ZodString>;
    allowedTransitions: z.ZodOptional<z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
}, z.core.$strict>;
export declare const group: z.ZodObject<{
    id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    name: z.ZodString;
    columnIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
}, z.core.$strict>;
export declare const workflow: z.ZodObject<{
    name: z.ZodString;
    initialColumnId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    columns: z.ZodArray<z.ZodObject<{
        id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        name: z.ZodString;
        onEnterPrompt: z.ZodOptional<z.ZodString>;
        allowedTransitions: z.ZodOptional<z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
    }, z.core.$strict>>;
    groups: z.ZodArray<z.ZodObject<{
        id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        name: z.ZodString;
        columnIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const note: z.ZodObject<{
    id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    taskId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    content: z.ZodString;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
    tags: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export declare const project: z.ZodObject<{
    id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    name: z.ZodString;
    projectPath: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    gitRootPath: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    defaultBranch: z.ZodOptional<z.ZodString>;
    workspaceId: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    workspaceOwned: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
/** The task fields both aggregates persist; the Hub aggregate adds `boardId`. */
export declare const baseTask: z.ZodObject<{
    id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    projectId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    title: z.ZodString;
    description: z.ZodString;
    columnId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    position: z.ZodNumber;
    sessionIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    closedSessionIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    effectiveCwd: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
    worktree: z.ZodNullable<z.ZodObject<{
        path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        branch: z.ZodString;
        owned: z.ZodBoolean;
        status: z.ZodEnum<{
            preparing: "preparing";
            ready: "ready";
            error: "error";
        }>;
        error: z.ZodOptional<z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
            details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    worktreeDismissed: z.ZodOptional<z.ZodBoolean>;
    unclaimedWorktrees: z.ZodOptional<z.ZodArray<z.ZodObject<{
        path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        branch: z.ZodString;
        error: z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
            details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
        }, z.core.$strict>;
    }, z.core.$strict>>>;
    worktreeWorkspaceId: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
    worktreeWorkspaceOwned: z.ZodOptional<z.ZodBoolean>;
    operation: z.ZodNullable<z.ZodObject<{
        id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        request: z.ZodDiscriminatedUnion<[z.ZodObject<{
            mode: z.ZodEnum<{
                new: "new";
                existing: "existing";
            }>;
            path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
            branchName: z.ZodString;
            sourceBranch: z.ZodOptional<z.ZodString>;
            kind: z.ZodLiteral<"create">;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"attach">;
            path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"remove">;
            discardChanges: z.ZodBoolean;
            expectedWorktreePath: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
            force: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"delete">;
            discardChanges: z.ZodBoolean;
            expectedWorktreePath: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
            force: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"return">;
        }, z.core.$strict>], "kind">;
        phase: z.ZodEnum<{
            git: "git";
            queued: "queued";
            waiting: "waiting";
            preflight: "preflight";
            switching: "switching";
            removing: "removing";
            archiving: "archiving";
            failed: "failed";
        }>;
        targetPath: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
        targetDirectory: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
        previousDirectories: z.ZodRecord<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>, z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
        switchedSessionIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
        archivedSessionIds: z.ZodArray<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
        createAttempt: z.ZodOptional<z.ZodObject<{
            operationId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
            path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
            gitRootPath: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
            branchName: z.ZodString;
            mode: z.ZodEnum<{
                new: "new";
                existing: "existing";
            }>;
            absentBefore: z.ZodLiteral<true>;
        }, z.core.$strict>>;
        gitCompleted: z.ZodBoolean;
        error: z.ZodOptional<z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
            details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
        }, z.core.$strict>>;
        createdAt: z.ZodString;
    }, z.core.$strict>>;
    pendingTransition: z.ZodOptional<z.ZodObject<{
        id: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        fromColumnId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        columnId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        mode: z.ZodEnum<{
            move: "move";
            run: "run";
        }>;
        sessionId: z.ZodOptional<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>;
        text: z.ZodOptional<z.ZodString>;
        beforeTaskId: z.ZodOptional<z.ZodNullable<z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>>>;
        worktreeRequest: z.ZodOptional<z.ZodObject<{
            mode: z.ZodEnum<{
                new: "new";
                existing: "existing";
            }>;
            path: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
            branchName: z.ZodString;
            sourceBranch: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        transitionOverride: z.ZodOptional<z.ZodBoolean>;
        status: z.ZodEnum<{
            waiting: "waiting";
            failed: "failed";
            sending: "sending";
        }>;
        error: z.ZodOptional<z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
            details: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodType<JsonValue, unknown, z.core.$ZodTypeInternals<JsonValue, unknown>>>>;
        }, z.core.$strict>>;
        origin: z.ZodOptional<z.ZodLiteral<"auto">>;
    }, z.core.$strict>>;
    instructionPending: z.ZodOptional<z.ZodObject<{
        columnId: z.ZodString & z.ZodType<string, string, z.core.$ZodTypeInternals<string, string>>;
        enteredAt: z.ZodNumber;
    }, z.core.$strict>>;
    autoMode: z.ZodOptional<z.ZodObject<{
        enabled: z.ZodBoolean;
        pause: z.ZodOptional<z.ZodObject<{
            reason: z.ZodEnum<{
                "turn-error": "turn-error";
                "turn-blocked": "turn-blocked";
                "turn-aborted": "turn-aborted";
                "turn-max-tokens": "turn-max-tokens";
                "advance-failed": "advance-failed";
            }>;
            at: z.ZodString;
            message: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    createdAt: z.ZodString;
    updatedAt: z.ZodString;
}, z.core.$strict>;
/** The task fields the shared invariant check reads. */
export type TaskCheckValue = Pick<Task, 'projectId' | 'columnId' | 'sessionIds' | 'closedSessionIds' | 'operation' | 'pendingTransition' | 'instructionPending'>;
export declare function canonicalWorkflow(value: Workflow): string;
type Issue = (path: (string | number)[], message: string) => void;
/**
 * One shared per-task invariant pass. Both aggregates record issues at the same
 * `tasks.<index>.<field>` paths; the caller supplies the column set that applies
 * to each task, because a Hub resolves them per board.
 */
export declare function createTaskInvariantChecker(projectIds: ReadonlySet<string>, issue: Issue): {
    check(value: TaskCheckValue, index: number, columnIds: ReadonlySet<string>, columnMessage?: string): void;
};
export {};
//# sourceMappingURL=schema-parts.d.ts.map