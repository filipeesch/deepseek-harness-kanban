import type { AutoModePause, Board, BoardSettings, HubState, HubTask, KanbanState, Note, Project, ProjectInput, Workflow } from '../shared/types.js';
import type { HubStorage } from '../shared/ports.js';
import type { NoteInput, OperationDeps, TaskTextPatch } from '../domain/hub-operations.js';
export interface HubRepositoryOptions {
    id?: () => string;
    now?: () => string;
}
export interface LocatedTask {
    hubId: string;
    hub: HubState;
    board: Board;
    project: Project;
    task: HubTask;
}
/**
 * One task's identity and conversation ids without cloning the Hub that owns it. The
 * arrays belong to the stored snapshot and MUST be treated as read-only.
 */
export interface TaskSummary {
    readonly hubId: string;
    readonly boardId: string;
    readonly projectId: string;
    readonly taskId: string;
    readonly sessionIds: readonly string[];
    readonly closedSessionIds: readonly string[];
    readonly autoModeEnabled: boolean;
    readonly instructionPending: {
        readonly columnId: string;
        readonly enteredAt: number;
    } | null;
    readonly hasOperation: boolean;
    readonly hasPendingTransition: boolean;
    readonly worktreePath: string | null;
    readonly unclaimedWorktreePaths: readonly string[];
    readonly operationAttemptPath: string | null;
    readonly pendingWorktreePath: string | null;
}
/**
 * One authoritative Hub-record writer. Writes are serialized through a single
 * tail so names, the last-Hub invariant, settings, and cross-Hub ownership have
 * one ordering. The storage adapter still persists one Hub record per write.
 */
export declare class HubRepository {
    private readonly storage;
    private readonly hubs;
    private summaries;
    private meta;
    private readonly listeners;
    private readonly mutationContext;
    private tail;
    private readonly id;
    private readonly now;
    private disposed;
    private constructor();
    static open(storage: HubStorage, options?: HubRepositoryOptions): Promise<HubRepository>;
    private allocateId;
    private hubId;
    private assertLoadedOwnership;
    private assertCrossHubOwnership;
    private persistHub;
    private persistMeta;
    private changed;
    subscribe(listener: () => void): () => void;
    list(): HubState[];
    snapshot(): KanbanState;
    settingsView(): BoardSettings;
    get(hubId: string): HubState | undefined;
    requireHub(hubId: string): HubState;
    defaultHubId(): string;
    resolveHubId(hubId?: string): string;
    hub(hubId: string): HubStore;
    defaultHub(): HubStore;
    requireTask(taskId: string): LocatedTask;
    findTask(taskId: string): LocatedTask | undefined;
    findBoard(boardId: string): {
        hubId: string;
        hub: HubState;
        board: Board;
    } | undefined;
    /** Whether any task owns this Session, without cloning the Hub it belongs to. */
    hasTaskSession(sessionId: string): boolean;
    findTaskBySession(sessionId: string): LocatedTask | undefined;
    allTasks(): LocatedTask[];
    /**
     * The lightweight board read: task identity, conversation ids, and the few task
     * fields hot paths need, rebuilt once per repository change instead of cloning the
     * owning Hub per task. Consumers MUST NOT mutate the returned values.
     */
    taskSummaries(): readonly TaskSummary[];
    createHub(name: string): Promise<HubState>;
    renameHub(hubId: string, name: string, expectedRevision?: number): Promise<HubState>;
    deleteHub(hubId: string): Promise<HubState>;
    saveSettings(input: BoardSettings, expectedRevision?: number): Promise<BoardSettings>;
    transact<T>(hubId: string, change: (draft: HubState) => T | Promise<T>, expectedRevision?: number, validate?: (draft: HubState) => void): Promise<T>;
    private deps;
    /** Operation dependencies are exposed to a Hub facade so IDs and clocks stay injectable. */
    operationDeps(): OperationDeps;
    private mutate;
    close(): Promise<void>;
}
/** One Hub-scoped facade over the repository. It owns no state and no write chain of its own. */
export declare class HubStore {
    private readonly repository;
    readonly hubId: string;
    constructor(repository: HubRepository, hubId: string);
    /** Single-board compatibility view for the first board; the persisted HubState does not carry these aliases. */
    snapshot(): HubState & {
        schemaVersion: 2;
        workflow: Workflow;
        workflowYaml: string;
        settings: BoardSettings;
    };
    subscribe(listener: (state: HubState) => void): () => void;
    transact<T>(change: (draft: HubState) => T | Promise<T>, expectedRevision?: number): Promise<T>;
    requireTask(taskId: string, state?: HubState): HubTask;
    requireProject(projectId: string, state?: HubState): Project;
    requireBoard(boardId: string, state?: HubState): Board;
    saveProject(input: ProjectInput, expectedRevision?: number): Promise<Project>;
    deleteProject(projectId: string, expectedRevision?: number): Promise<Project>;
    setProjectWorkspace(projectId: string, workspaceId: string, owned: boolean): Promise<Project>;
    setTaskWorktreeWorkspace(taskId: string, workspaceId: string, owned: boolean): Promise<HubTask>;
    createTask(input: {
        projectId: string;
        title: string;
        description: string;
        boardId?: string;
    }): Promise<HubTask>;
    dismissWorktree(taskId: string): Promise<HubTask>;
    editTask(taskId: string, patch: TaskTextPatch, expectedRevision?: number): Promise<HubTask>;
    setAutoMode(taskId: string, enabled: boolean): Promise<HubTask>;
    pauseAutoMode(taskId: string, pause: AutoModePause, expectedColumnId?: string): Promise<HubTask>;
    addSession(taskId: string, sessionId: string, expectedEffectiveCwd?: string): Promise<HubTask>;
    closeSession(taskId: string, sessionId: string): Promise<HubTask>;
    reopenSession(taskId: string, sessionId: string): Promise<HubTask>;
    saveNote(taskId: string, input: NoteInput): Promise<Note>;
    deleteNote(taskId: string, noteId: string): Promise<Note>;
    deleteTask(taskId: string): Promise<HubTask>;
    addBoard(name: string): Promise<Board>;
    renameBoard(boardId: string, name: string, expectedRevision?: number): Promise<Board>;
    deleteBoard(boardId: string, expectedRevision?: number): Promise<Board>;
    saveBoardWorkflow(boardId: string, yaml: string, expectedRevision?: number): Promise<Workflow>;
    setWorkflow(yaml: string, expectedRevision?: number): Promise<Workflow>;
    rename(name: string, expectedRevision?: number): Promise<HubState>;
    private deps;
}
//# sourceMappingURL=hub-repository.d.ts.map