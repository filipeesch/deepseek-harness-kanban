import type { Project, ProjectInput } from '../shared/types.js';
/** The task facts that make a Git-association change unsafe while work is in flight. */
export interface ProjectRegistrationTask {
    projectId: string;
    operation?: unknown;
    pendingTransition?: {
        worktreeRequest?: unknown;
    } | undefined;
}
export interface ProjectRegistrationState {
    projects: Project[];
    tasks: ProjectRegistrationTask[];
}
/** A blank Git root means the project is a folder project, never an empty path. */
export declare function projectGitRoot(input: ProjectInput): string | undefined;
/**
 * Registration may add or remove a project's Git association without changing its
 * project path. A path change or a different Git root still requires the project to
 * have no tasks, and a kind change waits for in-flight worktree work.
 */
export declare function assertProjectConversion(state: ProjectRegistrationState, projectId: string, input: ProjectInput): void;
/** Build the stored project, discarding a default branch that has no Git root to belong to. */
export declare function buildProject(projectId: string, input: ProjectInput, current?: Project): Project;
//# sourceMappingURL=project-registration.d.ts.map