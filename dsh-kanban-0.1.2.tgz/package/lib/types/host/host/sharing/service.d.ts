import type { HubSharingView, SharingCommand } from '../../shared/types.js';
import type { HubRepository } from '../hub-repository.js';
import { type SharingAuthorizationPort } from './auth-coordinator.js';
import type { SharingProviderResolver } from './provider.js';
import type { HubSharingStore } from './state.js';
export declare const DEFAULT_SHARING_INTERVAL_MINUTES = 5;
export interface HubSharingOptions {
    hubs: HubRepository;
    store: HubSharingStore;
    providers: SharingProviderResolver;
    /** Device-level authorization, when the host supports a storage that needs it. */
    auth?: SharingAuthorizationPort;
    now?: () => string;
    id?: () => string;
    notify?: () => void;
    report?: (error: unknown) => void;
    /** Local changes wait this long before an automatic Drive synchronization. */
    debounceMs?: number;
}
export declare function normalizeSharingInterval(value: number | undefined, fallback?: number): number;
/**
 * Owns the publishing lifecycle for every Hub. All operations for one Hub run
 * in a single serialized lane; a public operation invoked from inside a lane
 * operation is rejected rather than deadlocking.
 */
export declare class HubSharingService {
    private readonly options;
    private readonly tails;
    private readonly inflight;
    private readonly active;
    private readonly timers;
    private readonly lanes;
    private connectTail;
    private readonly now;
    private readonly id;
    private readonly debounceMs;
    private disposed;
    constructor(options: HubSharingOptions);
    views(): Record<string, HubSharingView>;
    view(hubId: string): HubSharingView | undefined;
    private viewOf;
    /**
     * Ask a fresh store whether the storage now requires a review. An automatic
     * operation that gets `true` must not touch the Hub or the storage: the
     * review is recorded and the user decides.
     */
    private storageBlocksAutomatic;
    /** The review the storage itself requires, when it reports one. */
    private storageReviewOf;
    /** Every stored binding, so a provider can refuse an address another Hub owns. */
    private candidates;
    publishedHubs(): Array<{
        hubId: string;
        intervalMinutes: number;
    }>;
    isBound(hubId: string, boardId: string): boolean;
    busy(hubId: string): boolean;
    command(command: SharingCommand): Promise<void>;
    connect(command: Extract<SharingCommand, {
        type: 'sharing.connect';
    }>): Promise<void>;
    /**
     * Connecting and re-pointing a storage share one global lane: both validate a
     * folder against every stored binding and then persist it, so they must not
     * interleave or two Hubs could claim one folder.
     */
    private serializeLocation;
    private connectNow;
    /** Re-point a Google Drive Local Hub at another folder, keeping every local board and task. */
    private changeLocation;
    /**
     * Validate a location, read its document, and either publish the local
     * configuration or store a first-connection preview. Connecting and changing
     * a folder share every rule; only the stored record they replace differs.
     */
    private openLocation;
    receive(hubId: string): Promise<void>;
    publishInitial(hubId: string, confirmed: boolean): Promise<void>;
    check(hubId: string, manual?: boolean): Promise<void>;
    private checkNow;
    getUpdates(hubId: string): Promise<void>;
    /** Debounce a local board or workflow save into an automatic synchronization. */
    noteLocalChange(hubId: string): void;
    private autoSyncNow;
    resolve(hubId: string, boardId: string, choice: 'local' | 'team'): Promise<void>;
    publish(hubId: string): Promise<void>;
    setInterval(hubId: string, intervalMinutes: number): Promise<void>;
    disconnect(hubId: string): Promise<void>;
    /** Called after the Hub is deleted; removes local publishing state and the managed workspace. */
    removeHub(hubId: string): Promise<void>;
    removeBoard(hubId: string, boardId: string, scope: 'local' | 'team', name: string): Promise<void>;
    restore(hubId: string, boardId: string): Promise<void>;
    publishOrphan(hubId: string, boardId: string): Promise<void>;
    close(): Promise<void>;
    private storeFor;
    private requireRecord;
    private save;
    private receiveNow;
    /** Apply the non-conflicting team changes in one Hub transaction, then record the merged base. */
    private applyUpdatesNow;
    private publishNow;
    /**
     * Read the stored document and record availability and integrity failures on
     * the record, so every caller reports the same facts.
     */
    private readRemote;
    /** Any read or write failure is an availability/integrity fact the interface must show. */
    private persistFailure;
    private removeBinding;
    private refused;
    private run;
}
//# sourceMappingURL=service.d.ts.map