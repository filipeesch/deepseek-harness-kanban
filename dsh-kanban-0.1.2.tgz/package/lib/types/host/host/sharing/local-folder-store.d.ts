import { type FolderPathOptions } from './local-folder-path.js';
import type { SharingProviderDescriptor } from './provider.js';
/**
 * The shared directory store, exported under its storage-specific name for
 * callers that speak in terms of the local-folder storage.
 */
export { DirectorySharedConfigStore as LocalFolderSharedConfigStore } from './directory-store.js';
export type { DirectoryStoreOptions as LocalFolderStoreOptions } from './directory-store.js';
export interface LocalFolderProviderOptions extends FolderPathOptions {
    /** A directory the plugin owns and never accepts as a team storage. */
    managedRoot?: string;
}
/** The local folder descriptor: continuous synchronization over one directory, no account. */
export declare function createLocalFolderProviderDescriptor(options?: LocalFolderProviderOptions): SharingProviderDescriptor;
//# sourceMappingURL=local-folder-store.d.ts.map