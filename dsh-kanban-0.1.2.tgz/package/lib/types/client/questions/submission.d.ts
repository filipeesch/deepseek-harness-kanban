import type { QuestionRound } from '../shared/types.js';
/** One deterministic answer to "may this form submit right now, and why not?". */
export type SubmitState = {
    kind: 'blocked';
    reason: 'invalid' | 'awaiting-turn';
} | {
    kind: 'ready';
} | {
    kind: 'submitting';
} | {
    kind: 'failed';
    message: string;
};
export interface SubmitStateInput {
    complete: boolean;
    answersValid: boolean;
    busy: boolean;
    error: string | null;
}
/** Busy wins, then invalid answers, then the turn-completion gate, then a stale admission error. */
export declare function submitState(input: SubmitStateInput): SubmitState;
/** Whether the Additional Notes Submit action is available; a failed admission may retry. */
export declare function canSubmit(state: SubmitState): boolean;
/**
 * The one round the composer dock shows. A rolled-back round wins so its retry is
 * visible, then an in-flight submitted round so its mounted form keeps the draft;
 * otherwise the newest unresolved round wins.
 */
export declare function selectActiveRound(rounds: readonly QuestionRound[], sessionId: string, isSubmitted: (roundId: string) => boolean, focusedRoundId?: string): QuestionRound | undefined;
//# sourceMappingURL=submission.d.ts.map