import type { ContextOperation, Task } from '../shared/types.js';
export interface OperationFact {
    label: string;
    value: string;
}
export interface OperationDescription {
    title: string;
    detail: string;
    facts: OperationFact[];
    retry: boolean;
    return: boolean;
    force: boolean;
    retryLabel: string;
    returnLabel: string;
}
export declare function describeOperation(task: Task, operation: ContextOperation): OperationDescription;
//# sourceMappingURL=operation-description.d.ts.map