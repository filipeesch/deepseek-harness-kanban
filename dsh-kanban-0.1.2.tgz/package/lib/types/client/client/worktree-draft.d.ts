import type { ClientApi, CreateWorktree, Project, Task } from '../shared/types.js';
import { asProblem } from './ui.js';
export interface WorktreeSuggestion {
    branchName: string;
    path: string;
}
export declare function initialWorktree(task: Task, project?: Project, basePath?: string): CreateWorktree;
/** The host accepts an omitted source and falls back to its default branch or HEAD. */
export declare function validWorktree(value: CreateWorktree): boolean;
export declare function cleanWorktree(value: CreateWorktree): CreateWorktree;
export interface WorktreeDraft {
    value: CreateWorktree;
    suggestion: WorktreeSuggestion | null;
    suggestionPending: boolean;
    suggestionError: ReturnType<typeof asProblem> | null;
    branchTouched: boolean;
    pathTouched: boolean;
    assign(next: CreateWorktree): void;
    resetPath(): void;
    reloadSuggestion(): void;
    refreshSuggestion(): Promise<WorktreeSuggestion | null>;
}
export declare function useWorktreeDraft({ api, task, project, basePath, enabled }: {
    api: ClientApi;
    task: Task;
    project?: Project;
    basePath?: string;
    enabled: boolean;
}): WorktreeDraft;
//# sourceMappingURL=worktree-draft.d.ts.map