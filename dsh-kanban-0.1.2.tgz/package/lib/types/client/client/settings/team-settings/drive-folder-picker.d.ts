import React from 'react';
import type { DriveBrowseView, DriveDiscoveryView } from '../../../shared/types.js';
/** The discovery operations the picker needs; the panel adapts the client API to it. */
export interface DriveBrowserPort {
    roots(refresh?: boolean): Promise<DriveDiscoveryView>;
    list(path: string): Promise<DriveBrowseView>;
    pickNative?(): Promise<string | null>;
}
export interface DriveFolderPickerProps {
    open: boolean;
    busy: boolean;
    port: DriveBrowserPort;
    /** The folder to open when the picker starts, usually the bound one. */
    initialPath?: string;
    onClose: () => void;
    onSelect: (path: string) => void;
}
/** Whether a path is the root itself or lies inside it, ignoring letter case. */
export declare function isInsideLocation(root: string, value: string): boolean;
/** Breadcrumb segments from a location root to the current folder. */
export declare function breadcrumb(root: string, current: string): Array<{
    name: string;
    path: string;
}>;
/**
 * The folder browser over the discovered Drive locations: locations on the
 * left, a breadcrumb and one folder level on the right, and the native picker
 * always one click away.
 */
export declare function DriveFolderPicker({ open, busy, port, initialPath, onClose, onSelect }: DriveFolderPickerProps): React.JSX.Element;
//# sourceMappingURL=drive-folder-picker.d.ts.map