import type { HubState, Project, Task } from '../shared/types.js';
import type { HubRepository, LocatedTask } from './hub-repository.js';
import type { WorktreeStore } from './worktrees.js';
export interface LocatedProject {
    hubId: string;
    hub: HubState;
    project: Project;
}
/** Read-only task/project lookup across Hubs; no execution or mutation. */
export declare class TaskLocator {
    private readonly hubs;
    constructor(hubs: HubRepository);
    byTask(taskId: string): LocatedTask | undefined;
    bySession(sessionId: string): LocatedTask | undefined;
    hasSession(sessionId: string): boolean;
    all(): LocatedTask[];
    project(projectId: string): LocatedProject | undefined;
}
/** Adapts the repository to the worktree coordinator's task-scoped port. */
export declare class RepositoryWorktreeStore implements WorktreeStore {
    private readonly hubs;
    constructor(hubs: HubRepository);
    locate(taskId: string): {
        hubId: string;
        hub: HubState;
        task: Task;
        project: Project;
    };
    transactTask<T>(taskId: string, change: (draft: HubState) => T): Promise<T>;
    allTasks(): Task[];
}
//# sourceMappingURL=task-locator.d.ts.map