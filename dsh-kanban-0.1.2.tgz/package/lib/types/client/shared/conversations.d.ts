/** The conversation fields every task-like record shares. */
export interface ConversationScope {
    readonly sessionIds: readonly string[];
    readonly closedSessionIds: readonly string[];
}
/** Conversation sessions that still own a tab, in task order. */
export declare function openSessionIds(scope: ConversationScope): string[];
/** Closed conversation sessions in their recorded close order. */
export declare function closedSessionIds(scope: ConversationScope): string[];
/** The first conversation that can receive work, or `undefined` when every tab is closed. */
export declare function firstOpenSessionId(scope: ConversationScope): string | undefined;
/** One-based position used by the `Agent N` fallback label. */
export declare function agentOrdinal(scope: ConversationScope, sessionId: string): number;
//# sourceMappingURL=conversations.d.ts.map