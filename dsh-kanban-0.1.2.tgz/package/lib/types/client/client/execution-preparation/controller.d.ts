import type { CreateWorktree, Problem } from '../../shared/types.js';
import type { PreparationRequest } from './contract.js';
import { type PreparationWorktree } from './gate.js';
/** Everything the controller needs from the host, the board, and the native seat. */
export interface PreparationPorts {
    defaults(taskId: string): Promise<{
        branchName: string;
        path: string;
    }>;
    createWorktree(taskId: string, draft: CreateWorktree): Promise<void>;
    dismissWorktree(taskId: string): Promise<void>;
    /** Creates the task's first conversation and returns its native session identity. */
    createConversation(taskId: string): Promise<string>;
    /** Resolves when the session is retained and its native scope exists. */
    retainSession(sessionId: string): Promise<void>;
    releaseSession(sessionId: string): void;
    seatAvailable(): boolean;
}
export type PreparationPhase = 'closed' | 'worktree' | 'blocked' | 'provisioning' | 'model' | 'error';
/** The step a retry resumes from; `defaults` keeps the worktree question open. */
export type PreparationFailedStep = 'defaults' | 'worktree' | 'conversation';
export interface PreparationState {
    readonly phase: PreparationPhase;
    readonly kind: 'move' | 'run';
    readonly taskId: string;
    readonly taskTitle: string;
    readonly stageName: string;
    readonly worktree: PreparationWorktree;
    readonly model: boolean;
    readonly draft: CreateWorktree | null;
    readonly destinationMissing: boolean;
    readonly sessionId: string | null;
    readonly pending: boolean;
    readonly error: Problem | null;
    readonly failedStep: PreparationFailedStep | null;
}
/**
 * Owns one first-execution preparation: the worktree question, provisioning,
 * the native model stage, and the single proceed/cancel promise the move
 * pipeline awaits. It never retries on its own and never starts an agent.
 */
export declare class ExecutionPreparationController {
    private state;
    private readonly listeners;
    private ports;
    private request;
    private project;
    private plan;
    private answer;
    private worktreeResolved;
    private sessionId;
    private resolve;
    /** Invalidates async continuations after the user closed the dialog. */
    private generation;
    configure(ports: PreparationPorts): void;
    getSnapshot: () => PreparationState;
    subscribe: (listener: () => void) => (() => void);
    private publish;
    private set;
    /**
     * Present the preparation when the task's first execution needs it.
     * @returns true when the caller may proceed, false when the user cancelled.
     */
    open(request: PreparationRequest): Promise<boolean>;
    /**
     * Answer the worktree question and start provisioning. Continuing in the base
     * project does not need the derived defaults, so it is accepted while they load.
     */
    answerWorktree(create: boolean): void;
    /** Confirm the model stage and let the move or run action proceed. */
    confirmModel(): void;
    /** Abandon the preparation; provisioning commands are never interrupted. */
    cancel(): void;
    /** Resume the failed step without retrying the steps that already completed. */
    retry(): void;
    private draftIsValid;
    private loadDefaults;
    private provision;
    private fail;
    private settle;
}
//# sourceMappingURL=controller.d.ts.map