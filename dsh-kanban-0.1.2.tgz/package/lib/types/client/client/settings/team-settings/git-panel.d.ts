import React from 'react';
import type { HubSharingView, HubState } from '../../../shared/types.js';
import type { Act } from './shared.js';
export declare function GitStoragePanel({ hub, sharing, act, pending }: {
    hub: HubState;
    sharing?: HubSharingView;
    act: Act;
    pending: string | null;
}): React.JSX.Element;
//# sourceMappingURL=git-panel.d.ts.map