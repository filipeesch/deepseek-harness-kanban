import type { Note } from '../../shared/types.js';
/** Unique tags across the notes, alphabetically ordered; legacy values are normalized for display. */
export declare function uniqueTags(notes: readonly Note[]): string[];
/** The notes shown for one active tag; a null tag means every note. */
export declare function filterNotes(notes: readonly Note[], tag: string | null): Note[];
/** Selecting the active tag clears the filter. */
export declare function toggleTag(active: string | null, tag: string): string | null;
/** Add one drafted value with the same normalization applied before storage. */
export declare function addDraftTag(tags: readonly string[], raw: string): string[];
//# sourceMappingURL=note-tags.d.ts.map