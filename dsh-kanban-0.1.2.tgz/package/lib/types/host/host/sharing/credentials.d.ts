import { type CredentialKey, type CredentialRecord, type CredentialRecordInfo } from '@deepseek-ai/dsh-credentials';
export type { CredentialKey, CredentialRecord, CredentialRecordInfo };
export declare const GOOGLE_DRIVE_CREDENTIAL_KEY: CredentialKey;
/**
 * The subset of the host credential seam this plugin depends on. It mirrors
 * the SDK's `CredentialProvider` record contract; `modifyRecord` is the only
 * write path and receives the record as it stands while the write is exclusive.
 */
export interface CredentialStore {
    readRecord(key: CredentialKey): Promise<CredentialRecord | undefined>;
    describeRecord(key: CredentialKey): Promise<CredentialRecordInfo>;
    modifyRecord(key: CredentialKey, mutation: (record: CredentialRecord | undefined) => Promise<CredentialRecord | undefined>): Promise<CredentialRecord | undefined>;
    deleteRecord(key: CredentialKey): Promise<void>;
}
/** Resolve the host credential service without making every test provide one. */
export declare function credentialStoreFromContext(ctx: unknown): CredentialStore | undefined;
export declare function requireCredentialStore(store: CredentialStore | undefined): CredentialStore;
//# sourceMappingURL=credentials.d.ts.map