export declare const DOMAIN_ID_PATTERN: RegExp;
export declare function isDomainId(value: unknown): value is string;
export declare function isAbsolutePath(value: unknown): value is string;
export declare function assertId(value: unknown, label: string): asserts value is string;
export declare function assertRevision(value: unknown): asserts value is number;
//# sourceMappingURL=validation.d.ts.map