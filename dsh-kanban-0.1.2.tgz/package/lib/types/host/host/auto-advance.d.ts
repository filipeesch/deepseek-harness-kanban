import type { AutoModePauseReason, Board, ConversationFacts, HubTask } from '../shared/types.js';
import { type AutoAdvancePlan } from '../domain/auto-advance.js';
/** Delay before a completed turn is evaluated, so the native activity projection has settled. */
export declare const AUTO_ADVANCE_SETTLE_MS = 250;
/** Bounded re-reads while the ending conversation itself still reports activity. */
export declare const AUTO_ADVANCE_SETTLE_ATTEMPTS = 3;
/** The recorded pause for a turn ending that is not `completed`, or undefined for completed. */
export declare function pauseReasonFor(kind: string): AutoModePauseReason | undefined;
/** The `turn/end` reason kind, or undefined when the value is not a turn boundary. */
export declare function turnEndReason(event: unknown): string | undefined;
/** The event identity used to ignore a duplicated observation of the same turn boundary. */
export declare function turnEndKey(sessionId: string, event: unknown): string | undefined;
export interface AutoAdvanceTaskView {
    task: HubTask;
    board: Board;
}
export interface AutoAdvancePorts {
    /** The task and board that own a conversation, when any. */
    locateBySession(sessionId: string): AutoAdvanceTaskView | undefined;
    locate(taskId: string): AutoAdvanceTaskView | undefined;
    facts(sessionId: string): Promise<ConversationFacts>;
    /** Persist one durable advance and dispatch it; throws when nothing was admitted. */
    admit(taskId: string, plan: AutoAdvancePlan): Promise<void>;
    pause(taskId: string, reason: AutoModePauseReason, message: string | undefined, expectedColumnId: string): Promise<void>;
    schedule(callback: () => void): unknown;
    cancel(handle: unknown): void;
    report(error: unknown): void;
}
/**
 * Turns live turn boundaries into automatic advances. It owns only the trigger
 * policy: reason filtering, the settle delay, duplicate handling, and the
 * admission hand-off. The advance decision is the pure domain rule, and
 * persistence and execution stay with the injected ports.
 */
export declare class AutoAdvanceCoordinator {
    private readonly ports;
    private readonly handled;
    private readonly queued;
    private readonly generations;
    private timer;
    private armed;
    private disposed;
    constructor(ports: AutoAdvancePorts);
    /** Observe one native session event; only an open task conversation's turn end matters. */
    observe(sessionId: string, event: unknown): void;
    /** Drop a queued settle for one task; used when auto mode is disabled. */
    forget(taskId: string): void;
    dispose(): void;
    private arm;
    private settle;
    /** Read every conversation of the task, including a closed one, which still owes the user input. */
    private readTaskFacts;
    private advance;
}
//# sourceMappingURL=auto-advance.d.ts.map