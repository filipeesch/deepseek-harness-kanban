/**
 * The compare-verify contract shared by every storage that cannot offer an
 * atomic conditional write. The caller reads a token, decides, writes, and
 * verifies; these two checks are the only places that decide whether the
 * decision was still valid.
 */
/** Refuse a write whose base token no longer matches the current document. */
export declare function assertExpectedToken(expected: string | null, actual: string | null): void;
/** Report a concurrent write when the stored content differs from what was written. */
export declare function assertWrittenToken(expected: string, actual: string): void;
//# sourceMappingURL=verified-write.d.ts.map