import type { Command, KanbanSnapshot, Problem, Project, Task } from '../shared/types.js';
import type { DestructiveRequest } from './destructive-dialogs.js';
import { type SharedWorktreeBlocker } from '../shared/worktree-blockers.js';
export type DestructiveView = {
    kind: 'confirm';
    request: DestructiveRequest;
} | {
    kind: 'force';
    request: DestructiveRequest;
    blockers: SharedWorktreeBlocker[];
} | {
    kind: 'discard';
    request: DestructiveRequest;
};
export interface DestructiveState {
    view: DestructiveView | null;
    pending: boolean;
    error: Problem | null;
}
export interface DestructiveOptions {
    run: (command: Command, allowDiscard?: boolean) => Promise<KanbanSnapshot>;
    tasks: () => readonly Task[];
    retained?: (path: string) => void;
    closed?: (taskId: string) => void;
}
export declare function destructiveRequestFor(task: Task, project: Project | undefined, type: 'task.delete' | 'worktree.remove'): DestructiveRequest;
/** Build the request that repeats a recorded failed destructive operation. */
export declare function destructiveRequestFromOperation(task: Task): DestructiveRequest | null;
/**
 * Owns the destructive confirmation state machine. Acceptance is decided from
 * the command result: the host records the operation and returns before the
 * cleanup, so the dialog closes without waiting for the lifecycle.
 */
export declare function useDestructiveOperations(options: DestructiveOptions): {
    state: DestructiveState;
    close: () => void;
    open: (task: Task, project: Project | undefined, type: "task.delete" | "worktree.remove") => void;
    openDiscard: (request: DestructiveRequest) => void;
    confirm: () => void;
    retry: () => void;
    returnToBase: () => void;
    openForce: (taskId: string) => void;
    confirmForce: () => void;
    reconcile: (tasks: readonly Task[]) => void;
    retryTask: (taskId: string) => Promise<void>;
    setError: (error: Problem | null) => void;
};
//# sourceMappingURL=destructive-operations.d.ts.map