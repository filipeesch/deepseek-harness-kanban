import type { ConversationFacts } from '../shared/types.js';
import type { ConversationFactsSource } from './native-facts.js';
/** Bounded re-reads after a transient facts failure; a new edge resets the allowance. */
export declare const MAX_READ_RETRIES = 5;
/** One task whose conversations contribute to its attention. */
export interface AttentionTask {
    id: string;
    sessionIds: readonly string[];
}
export interface AttentionCoordinatorOptions {
    source: ConversationFactsSource;
    tasks: () => readonly AttentionTask[];
    runPendingWork: () => Promise<void>;
    onChange: () => void;
    report: (error: unknown) => void;
    debounceMs?: number;
    reconcileMs?: number;
}
/** Compare two conversation-fact projections for the host's publish-on-change rule. */
export declare function sameConversationFacts(left: Record<string, ConversationFacts>, right: Record<string, ConversationFacts>): boolean;
/**
 * Owns the per-conversation fact cache, invalidation, and projection. One coalesced
 * tick keeps the pending-worktree resume coupled to activity changes; the caller decides
 * when to publish.
 */
export declare class AttentionCoordinator {
    private readonly options;
    private readonly cache;
    private readonly lastGood;
    private readonly failedReads;
    private readonly debounceMs;
    private readonly reconcileMs;
    private timer;
    private timerKind;
    private last;
    private ticking;
    private tickAgain;
    private disposed;
    constructor(options: AttentionCoordinatorOptions);
    /** Drop one conversation's cached facts, or every conversation's facts. */
    invalidate(sessionId?: string): void;
    /** Invalidate the affected facts, reset its retry allowance, and coalesce an activity refresh. */
    touch(sessionId?: string): void;
    /** Project the current conversations' facts and reconcile the bounded background timer. */
    project(tasks?: readonly AttentionTask[]): Promise<Record<string, ConversationFacts>>;
    dispose(): void;
    private schedule;
    private retrying;
    private arm;
    private tick;
    private projectFresh;
    private read;
}
//# sourceMappingURL=attention.d.ts.map