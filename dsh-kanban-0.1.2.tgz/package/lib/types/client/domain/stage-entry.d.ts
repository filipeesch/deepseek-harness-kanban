import type { Column, Task } from '../shared/types.js';
/** The raw entry instruction bytes, or undefined when the stage has none. */
export declare function entryInstruction(column: Pick<Column, 'onEnterPrompt'> | undefined): string | undefined;
/** The current entry is unresolved when the persisted marker still matches its stage. */
export declare function hasUnresolvedEntry(task: Pick<Task, 'columnId' | 'instructionPending'>, columnId?: string): boolean;
/** Strictly increasing millisecond identity, even when two entries land in the same clock tick. */
export declare function nextEnteredAt(now?: number): number;
//# sourceMappingURL=stage-entry.d.ts.map