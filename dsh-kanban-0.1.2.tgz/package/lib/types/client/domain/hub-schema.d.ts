import { z } from 'zod';
import type { Board, HubState, HubTask, KanbanMeta, KanbanSettings } from '../shared/types.js';
export { canonicalWorkflow } from './schema-parts.js';
/** Persisted settings and initialization marker stored in the domain global slot. */
export declare const KanbanMetaSchema: z.ZodType<KanbanMeta>;
/** Global user settings exposed to the client. */
export declare const KanbanSettingsSchema: z.ZodType<KanbanSettings>;
/** Validates one Hub aggregate. Cross-Hub ownership is enforced by the repository. */
export declare const HubStateSchema: z.ZodType<HubState>;
/** The client-facing aggregate of all Hubs plus global settings. */
export declare const KanbanStateSchema: z.ZodObject<{
    hubs: z.ZodArray<z.ZodType<HubState, unknown, z.core.$ZodTypeInternals<HubState, unknown>>>;
    settings: z.ZodType<KanbanSettings, unknown, z.core.$ZodTypeInternals<KanbanSettings, unknown>>;
}, z.core.$strict>;
export declare function createBoard(idValue: string, name: string, now: string, workflowYaml?: string): Board;
export declare function initialHubState(idValue: string, name: string, now?: string): HubState;
export declare function defaultHubState(idValue: string, name: string, boardId: string, boardName: string, now?: string): HubState;
/** A HubTask is a Task with its required board identity; the persisted schema enforces it. */
export type { HubTask };
//# sourceMappingURL=hub-schema.d.ts.map