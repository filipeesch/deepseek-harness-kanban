import React from 'react';
import type { Note } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
/** Create or edit one shared note in a focused overlay. */
export declare function NoteEditorDialog({ taskId, note, suggestions, run, onSaved, onDeleted, onClose }: {
    taskId: string;
    note?: Note;
    suggestions: string[];
    run: RunCommand;
    onSaved(): void;
    onDeleted(): void;
    onClose(): void;
}): React.JSX.Element;
//# sourceMappingURL=note-editor-dialog.d.ts.map