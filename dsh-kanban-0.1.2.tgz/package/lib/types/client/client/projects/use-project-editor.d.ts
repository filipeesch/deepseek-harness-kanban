import type { ClientApi, Problem, Project, ProjectLocation } from '../../shared/types.js';
import { type RunCommand } from '../ui.js';
import { type ProjectDraft } from './project-draft.js';
export interface ProjectEditorController {
    draft: ProjectDraft;
    detection: ProjectLocation | null;
    pending: boolean;
    picking: boolean;
    blocked: boolean;
    error: Problem | null;
    readonly canBrowse: boolean;
    change(field: 'name' | 'projectPath' | 'gitRootPath' | 'defaultBranch', value: string): void;
    browse(): Promise<void>;
    blurPath(): void;
    save(): Promise<void>;
    cancel(): void;
}
export declare function useProjectEditor({ api, hubId, expectedRevision, project, run, onSaved, onClose }: {
    api?: ClientApi;
    hubId?: string;
    expectedRevision?: number;
    project?: Project;
    run: RunCommand;
    onSaved: (id: string) => void;
    onClose: () => void;
}): ProjectEditorController;
//# sourceMappingURL=use-project-editor.d.ts.map