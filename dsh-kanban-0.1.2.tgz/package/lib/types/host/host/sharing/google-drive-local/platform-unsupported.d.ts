import type { DiscoveryEvidence } from './mounts.js';
/** No Google Drive for desktop on this platform; discovery reports the condition. */
export declare class UnsupportedDriveDiscoveryAdapter {
    readonly model: "unsupported";
    discover(): Promise<DiscoveryEvidence>;
}
//# sourceMappingURL=platform-unsupported.d.ts.map