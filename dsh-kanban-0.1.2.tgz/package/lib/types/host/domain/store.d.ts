import type { StateStorage } from '../shared/ports.js';
import type { BoardSettings, BoardState, NewTask, Note, Project, ProjectInput, Task, Workflow } from '../shared/types.js';
import { type NoteInput } from './note.js';
export type { NoteInput } from './note.js';
export interface TaskTextPatch {
    title?: string;
    description?: string;
}
export type BoardListener = (state: BoardState) => void;
/** One authoritative writer: validate, await storage durability, then publish isolated snapshots. */
export declare class BoardStore {
    private readonly storage;
    private state;
    private tail;
    private readonly listeners;
    private readonly mutationContext;
    private constructor();
    static open(storage: StateStorage): Promise<BoardStore>;
    snapshot(): BoardState;
    /** Listeners receive commits only, never drafts or a shared mutable instance. */
    subscribe(listener: BoardListener): () => void;
    transact<T>(fn: (draft: BoardState) => T | Promise<T>, expectedRevision?: number): Promise<T>;
    requireTask(taskId: string, state?: BoardState): Task;
    requireProject(projectId: string, state?: BoardState): Project;
    saveProject(input: ProjectInput, expectedRevision?: number): Promise<Project>;
    saveSettings(input: BoardSettings, expectedRevision?: number): Promise<BoardSettings>;
    deleteProject(projectId: string, expectedRevision?: number): Promise<Project>;
    setProjectWorkspace(projectId: string, workspaceId: string, owned: boolean): Promise<Project>;
    setTaskWorktreeWorkspace(taskId: string, workspaceId: string, owned: boolean): Promise<Task>;
    createTask(input: NewTask): Promise<Task>;
    editTask(taskId: string, patch: TaskTextPatch, expectedRevision?: number): Promise<Task>;
    addSession(taskId: string, sessionId: string): Promise<Task>;
    closeSession(taskId: string, sessionId: string): Promise<Task>;
    reopenSession(taskId: string, sessionId: string): Promise<Task>;
    setWorkflow(yaml: string, expectedRevision?: number): Promise<Workflow>;
    saveNote(taskId: string, input: NoteInput): Promise<Note>;
    private assertAvailableSession;
    private changeSessionVisibility;
}
//# sourceMappingURL=store.d.ts.map