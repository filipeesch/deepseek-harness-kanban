import type { KanbanSnapshot, Command, Problem } from '../shared/types.js';
/** The product-fixed window between an instructed move and its automatic send. */
export declare const AUTO_RUN_DELAY_MS = 5000;
export interface AutoRunClock {
    now(): number;
    setTimeout(callback: () => void, delay: number): unknown;
    clearTimeout(handle: unknown): void;
}
/** Browser clock; injected so the controller is deterministic in tests. */
export declare const systemAutoRunClock: AutoRunClock;
/** The entry identity and raw instruction captured when a move resolves. */
export interface AutoRunInput {
    taskId: string;
    columnId: string;
    enteredAt: number;
    instruction: string;
}
export type AutoRunStatus = 'counting' | 'sending' | 'failed';
export interface AutoRunEntry extends AutoRunInput {
    deadline: number | null;
    status: AutoRunStatus;
    error?: Problem;
}
/** The only task fields reconciliation needs. */
export interface AutoRunTask {
    id: string;
    columnId: string;
    instructionPending?: {
        columnId: string;
        enteredAt: number;
    };
}
export type AutoRunCommand = (command: Command) => Promise<KanbanSnapshot>;
export interface AutoRunOptions {
    run: AutoRunCommand;
    clock?: AutoRunClock;
}
export declare function runInstructionCommand(input: AutoRunInput): Extract<Command, {
    type: 'task.runInstruction';
}>;
/** The card's fallback copy when an auto-run failure carries no message. */
export declare const RUN_FAILURE_FALLBACK = "The instruction could not be sent.";
/** The entry that belongs to this column, ignoring a stale entry from another stage. */
export declare function autoRunEntryForColumn(entry: AutoRunEntry | undefined, columnId: string): AutoRunEntry | undefined;
/** Owns the per-task countdown, the single execution path, and the failure record. */
export declare class AutoRunController {
    private readonly options;
    private entries;
    private readonly timers;
    private readonly listeners;
    private readonly clock;
    private disposed;
    constructor(options: AutoRunOptions);
    subscribe: (listener: () => void) => (() => void);
    getSnapshot: () => Record<string, AutoRunEntry>;
    /** Arm one window for the task; a newer entry replaces the older timer. */
    arm: (input: AutoRunInput) => void;
    /** Stop the automatic send only; no command is issued. */
    cancel: (taskId: string) => void;
    /** Cancel a pending window and execute immediately through the shared path. */
    runNow: (input: AutoRunInput) => Promise<KanbanSnapshot | null>;
    /** Drop windows whose persisted entry no longer matches the board. */
    reconcile: (tasks: readonly AutoRunTask[]) => void;
    dispose: () => void;
    private expire;
    private execute;
    private clearTimer;
    private commit;
    private remove;
    private emit;
}
//# sourceMappingURL=auto-run.d.ts.map