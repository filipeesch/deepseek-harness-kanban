import type { ConversationFacts, SettledTurn } from '../shared/types.js';
import type { ConversationFactsFold } from './conversation-facts.js';
/** One family reported by the public `workspace/session-activity` waterfall. */
export interface ActivityEntry {
    readonly kind: string;
    readonly items?: ReadonlyArray<{
        readonly id?: string;
        readonly label?: string;
    }>;
}
/** The event-log facts these folds depend on. */
export interface SessionEventsLike {
    readonly events: ReadonlyArray<{
        readonly type: string;
        readonly seq: number;
        readonly data: unknown;
    }>;
}
export interface ProjectionLike {
    readonly values?: unknown;
}
export interface NativeFactsDeps {
    activity(sessionId: string): Promise<readonly ActivityEntry[]>;
    projections(sessionId: string): Promise<ProjectionLike | null | undefined>;
    inspect(sessionId: string): Promise<SessionEventsLike>;
    /** Incremental facts for a live Session; absent for a not-live Session. */
    liveFacts?(sessionId: string): ConversationFactsFold | undefined;
    /** User messages queued for a later turn, read from the same projection hydration; absent keeps the read to the other facts. */
    queuedPrompts?(sessionId: string, projection: ProjectionLike | null | undefined): number;
}
export interface ConversationFactsSource {
    read(sessionId: string): Promise<ConversationFacts>;
}
/** Split the activity families: agent execution (own turn or descendants) and the remaining background work. */
export declare function partitionActivity(entries: readonly ActivityEntry[]): Pick<ConversationFacts, 'running' | 'background'>;
/** A conversation awaits a reply while a native question or approval is still open. */
/** A pending native approval remains open until its decision or the turn boundary that clears it. */
export declare function inspectedApprovals(inspection: SessionEventsLike): boolean;
export declare function nativePending(projection: ProjectionLike | null | undefined, inspection: SessionEventsLike): boolean;
/** A turn boundary is open until its matching `turn/end` is recorded. */
export declare function inspectedOpenTurn(inspection: SessionEventsLike): boolean;
/** The last settled turn, identified by its durable event sequence so a read state can target it. */
export declare function lastSettledTurn(inspection: SessionEventsLike): SettledTurn | null;
/** Read the native facts from injected seams: projections for a live Session, inspection otherwise. */
export declare function createNativeSessionFacts(deps: NativeFactsDeps): ConversationFactsSource;
//# sourceMappingURL=native-facts.d.ts.map