import React from 'react';
export type IconProps = {
    size?: number;
    className?: string;
};
export declare function SettingsIcon({ size, className }: IconProps): React.JSX.Element;
export declare function TrashIcon({ size, className }: IconProps): React.JSX.Element;
export declare function PencilIcon({ size, className }: IconProps): React.JSX.Element;
export declare function CloseIcon({ size, className }: IconProps): React.JSX.Element;
export declare function PlusIcon({ size, className }: IconProps): React.JSX.Element;
export declare function CheckSquareIcon({ size, className }: IconProps): React.JSX.Element;
export declare function InfoIcon({ size, className }: IconProps): React.JSX.Element;
export declare function PlayIcon({ size, className }: IconProps): React.JSX.Element;
export declare function AlertIcon({ size, className }: IconProps): React.JSX.Element;
export declare function ClockIcon({ size, className }: IconProps): React.JSX.Element;
export declare function ReopenIcon({ size, className }: IconProps): React.JSX.Element;
export declare function AutoModeIcon({ size, className }: IconProps): React.JSX.Element;
export declare function GitBranchIcon({ size, className }: IconProps): React.JSX.Element;
export declare function CloudIcon({ size, className }: IconProps): React.JSX.Element;
export declare function DriveIcon({ size, className }: IconProps): React.JSX.Element;
export declare function FolderIcon({ size, className }: IconProps): React.JSX.Element;
export declare function ChevronRightIcon({ size, className }: IconProps): React.JSX.Element;
export declare function ArrowLeftIcon({ size, className }: IconProps): React.JSX.Element;
export declare function SearchIcon({ size, className }: IconProps): React.JSX.Element;
//# sourceMappingURL=icons.d.ts.map