import type { Problem } from './types.js';
export declare class KanbanError extends Error {
    readonly code: string;
    readonly details?: Record<string, unknown> | undefined;
    constructor(code: string, message: string, details?: Record<string, unknown> | undefined);
}
export declare function problem(error: unknown): Problem;
export declare function invariant(value: unknown, code: string, message: string): asserts value;
//# sourceMappingURL=errors.d.ts.map