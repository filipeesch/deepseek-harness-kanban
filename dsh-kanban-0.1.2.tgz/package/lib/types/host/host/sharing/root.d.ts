/** `DSH_HOME` is the installation data root; provider workspaces stay under it. */
export declare function sharingRoot(env?: NodeJS.ProcessEnv, home?: string): string;
//# sourceMappingURL=root.d.ts.map