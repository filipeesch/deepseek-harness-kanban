import type { Command, FullHostSnapshot, HubTask, LocalDriveRequest, LocalDriveResult, NewTask, ProjectLocation, QuestionRound, SharingCommand, SnapshotRequest } from '../shared/types.js';
import type { GitPort, ProjectProbe, SessionPort, WorkspacePort } from '../shared/ports.js';
import type { QuestionStore } from './question-storage.js';
import { WorktreeCoordinator } from './worktrees.js';
import { HubRepository, HubStore } from './hub-repository.js';
import { TaskLocator } from './task-locator.js';
import { QuestionIndex } from '../questions/indexer.js';
import type { HubSharingService } from './sharing/service.js';
import type { SharingPollScheduler } from './sharing/scheduler.js';
import type { GoogleDriveLocalDiscovery } from './sharing/google-drive-local/discovery.js';
import { type GoogleDriveAuthCoordinator } from './sharing/auth-coordinator.js';
export interface AppOptions {
    history?: (sessionId: string) => Promise<readonly unknown[]>;
    signal?: AbortSignal;
    report?: (error: unknown) => void;
    questionStore?: QuestionStore;
    probe?: ProjectProbe;
    sharing?: HubSharingService;
    sharingAuth?: GoogleDriveAuthCoordinator;
    localDrive?: GoogleDriveLocalDiscovery;
    scheduler?: SharingPollScheduler;
}
/** Coordinates Hub-scoped commands while the host continues to own sessions and execution. */
export declare class KanbanApp {
    readonly hubs: HubRepository;
    readonly sessions: SessionPort;
    readonly git: GitPort;
    private readonly options;
    private readonly workspaces?;
    readonly questions: QuestionIndex;
    readonly worktrees: WorktreeCoordinator;
    readonly locator: TaskLocator;
    private readonly listeners;
    private readonly prepared;
    private readonly attention;
    private readonly assembler;
    private readonly pendingTransitions;
    private readonly startup;
    private readonly pendingWork;
    private readonly publisher;
    private readonly disposers;
    private sequence;
    private disposed;
    private driving;
    private driveAgain;
    private drivePromise;
    private commandTail;
    private readonly saveTimers;
    private readonly autoAdvance;
    /** The one conversation-fact read every host consumer shares; the question projection is folded in here. */
    private readonly factsSource;
    private readonly workspaceCoordinator?;
    constructor(hubs: HubRepository, sessions: SessionPort, git: GitPort, options?: AppOptions, workspaces?: WorkspacePort | undefined);
    /** The first/default Hub facade retained for single-Hub callers and tests. */
    get store(): HubStore;
    private hubStore;
    private noteSharingChange;
    private locatedTask;
    private changed;
    /**
     * Re-project one conversation's derived facts after a host-side change that emitted
     * no session event. This invalidates the facts cache and requests a publish only; it
     * deliberately does not run pending work, which a session-event touch also does.
     */
    private rederiveAttention;
    private markChanged;
    private attentionChanged;
    subscribe(listener: () => void): () => void;
    private attentionTasks;
    /**
     * Startup recovery: history-free repairs stay awaited, while the persisted question
     * projection is restored synchronously so an unanswered question still holds an
     * automatic advance. History replay and workspace reconciliation run in background.
     */
    initialize(): Promise<void>;
    /** Resolves when the background startup reconciliation has finished; used by tests and shutdown. */
    whenSettled(): Promise<void>;
    private repairInterruptedTransition;
    private scheduleStartupReconciliation;
    private restoreQuestionProjection;
    prepareQuestions(sessionId: string): Promise<void>;
    private schedulePersist;
    private persistSession;
    private persistSessionStrict;
    private flushQuestions;
    rounds(sessionId: string): Promise<QuestionRound[]>;
    dismissQuestions(sessionId: string, roundId: string): Promise<QuestionRound[]>;
    observe(sessionId: string, event: unknown): void;
    private clearInstructionPending;
    private reconcileTaskInstructionPending;
    activityChanged(): void;
    sessionActivity(sessionId?: string): void;
    /**
     * One snapshot request. Presentation projects only resolved facts and schedules the
     * rest; an explicit refresh awaits only the conversations it was asked to re-read.
     */
    snapshot(request?: SnapshotRequest, mode?: 'full' | 'cache'): Promise<FullHostSnapshot>;
    /** Publish a new snapshot after publishing or authorization state changed outside a board command. */
    sharingChanged(): void;
    /** Execute one publishing action, then reconcile automatic checks and return a fresh snapshot. */
    sharingCommand(command: SharingCommand): Promise<FullHostSnapshot>;
    branches(taskId: string): Promise<string[]>;
    worktreeDefault(taskId: string): Promise<{
        branchName: string;
        path: string;
    }>;
    detectProject(pathValue: string): Promise<ProjectLocation>;
    localDrive(request: LocalDriveRequest): Promise<LocalDriveResult>;
    assertExecutionContext(sessionId: string): Promise<void>;
    private settings;
    private project;
    private assertContext;
    private serial;
    createConversation(taskId: string): Promise<string>;
    private createConversationNow;
    createTask(input: NewTask): Promise<HubTask>;
    private createTaskNow;
    saveNote(input: Extract<Command, {
        type: 'note.save';
    }>): Promise<import("../shared/types.js").Note>;
    private saveNoteNow;
    private deleteNoteNow;
    command(command: Command): Promise<FullHostSnapshot>;
    private execute;
    /**
     * The in-memory command guard. It runs before any pending transition is cleared,
     * so a rejected command never discards confirmed workflow state; the queued
     * admission re-checks the same persisted binding before it enqueues.
     */
    private assertDestructiveTarget;
    private clearPending;
    private stageInstructionDeps;
    private move;
    private runInstruction;
    private admitAutoAdvance;
    /** The serialized adapter around the one automatic-advance admission path. */
    private admitAutoAdvanceNow;
    private dismissFailedAdvance;
    private pauseAutoMode;
    private failPending;
    private dispatchPending;
    private drainPending;
    close(): Promise<void>;
}
//# sourceMappingURL=app.d.ts.map