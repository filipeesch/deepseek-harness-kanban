import type { ModeOption, ModePort } from './mode-port.js';
export type ModeSeatError = string | {
    readonly preset: ModeOption;
    readonly reason: string;
};
export interface ModeSeatState {
    readonly options: readonly ModeOption[];
    readonly current: string;
    readonly error: ModeSeatError | null;
    readonly busy: boolean;
    readonly introduce: boolean;
}
/**
 * State for the hosted native agent-preset seat. It reads the native roster,
 * selects the exact blank session, and never stores a task-level default.
 */
export declare class ModeSeatController {
    private readonly port;
    private readonly sessionId;
    private readonly currentPreset;
    private state;
    private readonly listeners;
    private loadGeneration;
    private pendingLoad;
    constructor(port: ModePort, sessionId: string, currentPreset: () => string | undefined);
    getSnapshot: () => ModeSeatState;
    subscribe: (listener: () => void) => (() => void);
    private set;
    /** Read the roster once while a read is in flight; the newest completed read publishes. */
    load(): Promise<void>;
    private loadNow;
    /** Select one mode for this exact session; refusal returns the native reason. */
    select(id: string): Promise<string | undefined>;
    /** Acknowledge the native refusal after its Toast ends. */
    dismissRefusal(refusal: ModeSeatError): void;
    /** Acknowledge the one-shot introduction cue. */
    introduced(): void;
}
//# sourceMappingURL=mode-seat-controller.d.ts.map