import type { GitPort, SessionPort } from '../shared/ports.js';
import type { HubState, OperationRequest, Project, Task } from '../shared/types.js';
import { WorktreeSharingGuard } from './worktree-sharing.js';
export interface WorktreeStore {
    locate(taskId: string): {
        hubId: string;
        hub: HubState;
        task: Task;
        project: Project;
    };
    transactTask<T>(taskId: string, change: (draft: HubState) => T): Promise<T>;
    allTasks(): Task[];
    /** Whether any task holds a context operation; the resume path avoids cloning Hubs when it is false. */
    hasOperations?(): boolean;
}
export interface WorktreeCoordinatorOptions {
    signal?: AbortSignal;
    id?: () => string;
    now?: () => string;
    onTaskDeleted?: (task: Task, project: Project) => Promise<void>;
    sharing?: WorktreeSharingGuard;
}
/** Event-driven, journaled coordination; waiting operations never poll or hold a user request open. */
export declare class WorktreeCoordinator {
    private readonly store;
    private readonly sessions;
    private readonly git;
    private readonly controller;
    private readonly signal;
    private readonly id;
    private readonly now;
    private readonly onTaskDeleted?;
    private readonly sharing;
    private readonly journal;
    private readonly admission;
    private readonly destructive;
    private readonly queue;
    private readonly tails;
    private resumed;
    private resumeAgain;
    private disposed;
    constructor(store: WorktreeStore, sessions: SessionPort, git: GitPort, options?: WorktreeCoordinatorOptions);
    private destructiveHost;
    dispose(): void;
    settle(): Promise<void>;
    close(): Promise<void>;
    private assertOpen;
    private serial;
    private read;
    private update;
    private sameRequest;
    request(taskId: string, request: OperationRequest, options?: {
        background?: boolean;
    }): Promise<HubState>;
    private hubAfter;
    retry(taskId: string, options?: {
        background?: boolean;
    }): Promise<HubState>;
    /**
     * Admit the recorded destructive operation from persisted state only, then hand
     * execution to its repository lane. The authoritative preflight runs there, so
     * admission never inspects Git, native conversations, or the filesystem.
     */
    private admitAndQueue;
    private recordAdmissionFailure;
    /** A new confirmation may not silently substitute the target of a recorded operation. */
    private recordedTargetMatches;
    private enqueue;
    returnToBase(taskId: string): Promise<HubState>;
    /** Called at startup and by the parent's native activity events, never by a timer. */
    resumePending(): Promise<void>;
    /** Compare the confirmed target with the persisted binding; canonicalization belongs to the lane preflight. */
    private confirmationMatches;
    private start;
    private idle;
    private createProof;
    private assertRecoveredBranch;
    private sourceUnchanged;
    private switchDirectories;
    private enqueueDestructive;
    private drive;
}
//# sourceMappingURL=worktrees.d.ts.map