import type { HubState } from '../../shared/types.js';
import type { BoardBindings } from './identity.js';
/** One local board as the sharing rules see it: sharing content plus local work. */
export interface LocalSharedBoard {
    boardId: string;
    name: string;
    workflow: string;
    /** Present only while the board is bound to a published key. */
    key?: string;
    tasks: number;
    taskColumns: Array<{
        columnId: string;
        tasks: number;
    }>;
}
/**
 * Project the Hub onto the sharing model. Projects, notes, conversations, task
 * metadata, Hub names, and settings are deliberately absent.
 */
export declare function projectSharingBoards(hub: HubState, bindings: Readonly<BoardBindings>): LocalSharedBoard[];
//# sourceMappingURL=projection.d.ts.map