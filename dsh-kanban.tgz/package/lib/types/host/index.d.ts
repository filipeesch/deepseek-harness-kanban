import type { Context } from '@deepseek-ai/cordis';
import { HubRepository } from './host/hub-repository.js';
import { HubSharingService } from './host/sharing/service.js';
import { SharingPollScheduler } from './host/sharing/scheduler.js';
import type { SharingCommandRunner } from './host/sharing/command-runner.js';
import { GoogleDriveAuthCoordinator } from './host/sharing/auth-coordinator.js';
import { GoogleDriveLocalDiscovery } from './host/sharing/google-drive-local/discovery.js';
import { type DiscoveryFs } from './host/sharing/google-drive-local/filesystem.js';
import { type CredentialStore } from './host/sharing/credentials.js';
import { KanbanApp } from './host/app.js';
import { ForkAdopter } from './host/conversation-adoption.js';
import type { TaskLocator } from './host/task-locator.js';
declare module '@deepseek-ai/cordis' {
    interface Events {
        'schedule/changed'(): void;
    }
}
/** Invalidate attention from the canonical activity edges; the app owns the coalesced refresh. */
export declare function registerAttentionSignals(ctx: Context, app: Pick<KanbanApp, 'sessionActivity' | 'activityChanged'>): () => void;
/** Public native hooks, not a lease: assembly/working-directory recovery precedes both admission boundaries. */
export declare function registerTaskExecutionGuards(ctx: Context, locator: Pick<TaskLocator, 'bySession'>, app: Pick<KanbanApp, 'assertExecutionContext'>): () => void;
export interface ForkAdoptionRegistrationOptions {
    signal?: AbortSignal;
    report?: (error: unknown) => void;
}
/**
 * Adopt a native fork of a task conversation as another conversation of that task.
 * The listener returns synchronously and runs adoption detached: agent/created is a
 * serial hook that creation awaits, so a rejection here would fail agent creation.
 */
export declare function registerForkAdoption(ctx: Pick<Context, 'on'>, adopter: Pick<ForkAdopter, 'adopt'>, options?: ForkAdoptionRegistrationOptions): () => void;
export interface HubSharingRuntime {
    service: HubSharingService;
    scheduler: SharingPollScheduler;
    auth: GoogleDriveAuthCoordinator;
    discovery: GoogleDriveLocalDiscovery;
    setNotify: (notify: () => void) => void;
    close: () => Promise<void>;
}
/** Compose the publishing runtime over its own storage domain so it can be closed as one unit. */
export interface HubSharingOpenOptions {
    report?: (error: unknown) => void;
    root?: string;
    runner?: SharingCommandRunner;
    clientId?: string;
    clientSecret?: string;
    fetch?: typeof fetch;
    credentials?: CredentialStore;
    /** Home directory that owns the suggested per-Hub team folders. */
    home?: string;
    /** Platform used to pick the Drive discovery adapter; injectable for tests. */
    platform?: NodeJS.Platform;
    /** Filesystem used by Drive discovery; injectable for tests. */
    discoveryFs?: DiscoveryFs;
    /** Environment used to expand Windows mount variables. */
    env?: NodeJS.ProcessEnv;
    /** A fully composed discovery service, when the host already owns one. */
    discovery?: GoogleDriveLocalDiscovery;
    /** Delay between a local change and an automatic synchronization. */
    debounceMs?: number;
}
export declare function openHubSharing(ctx: Context, hubs: HubRepository, options?: HubSharingOpenOptions): Promise<HubSharingRuntime>;
export declare const name = "kanban";
export declare const inject: string[];
export declare function apply(ctx: Context): Promise<void>;
//# sourceMappingURL=index.d.ts.map