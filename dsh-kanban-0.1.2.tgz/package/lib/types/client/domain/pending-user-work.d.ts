import type { PendingUserWork, PendingUserWorkKind } from '../shared/types.js';
/** Stable presentation order, so a merged value never reshuffles between reads. */
export declare const PENDING_USER_WORK_KINDS: readonly PendingUserWorkKind[];
/** One pending value with a normalized kind order; a queued count always carries its kind. */
export declare function pendingUserWork(kinds: readonly PendingUserWorkKind[], queuedPrompts?: number): PendingUserWork;
/** Union of several conversations' pending work, with queued prompts summed. */
export declare function mergePendingUserWork(values: readonly PendingUserWork[]): PendingUserWork;
/** Whether the value holds any user-facing input at all. */
export declare function hasPendingUserWork(value: PendingUserWork | undefined): boolean;
/** Whether the value awaits a reply, which excludes a queued prompt the user merely typed ahead. */
export declare function awaitingReply(value: PendingUserWork | undefined): boolean;
/** Value comparison used by the attention change detection. */
export declare function samePendingUserWork(left: PendingUserWork, right: PendingUserWork): boolean;
//# sourceMappingURL=pending-user-work.d.ts.map