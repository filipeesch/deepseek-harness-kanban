/** Local board id → published board key. Board ids never cross the sharing boundary. */
export type BoardBindings = Record<string, string>;
/** A board the team removed while this installation still holds work for it. */
export interface OrphanRecord {
    lastKey: string;
    lastPublishedName: string;
}
export type OrphanMap = Record<string, OrphanRecord>;
export declare function normalizeBoardName(value: string): string;
/**
 * Allocate a stable, human-readable key. A rename never re-runs this for an
 * already published board; it only runs when the board enters the document.
 */
export declare function boardKeyFromName(name: string, taken: Iterable<string>): string;
export declare function isSharedBoardKey(value: string): boolean;
//# sourceMappingURL=identity.d.ts.map