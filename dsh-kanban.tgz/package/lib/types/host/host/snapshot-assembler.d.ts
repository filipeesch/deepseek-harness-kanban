import type { ConversationFacts, HubSharingView, KanbanState, SharingAuthView } from '../shared/types.js';
import type { HubRepository } from './hub-repository.js';
import type { GoogleDriveAuthCoordinator } from './sharing/auth-coordinator.js';
export interface SnapshotAssemblerOptions {
    hubs: Pick<HubRepository, 'snapshot'>;
    /** The team-sharing views for every Hub, when publishing is available. */
    sharing?: () => Record<string, HubSharingView>;
    sharingAuth?: GoogleDriveAuthCoordinator;
    authTtlMs?: number;
    now?: () => number;
    /** Called after a background authorization refresh so the caller can publish it. */
    onChange?: () => void;
    report?: (error: unknown) => void;
}
export interface SnapshotParts {
    state: KanbanState;
    stateRevision: number;
    conversations: Record<string, ConversationFacts>;
    sharing: Record<string, HubSharingView>;
    sharingAuth?: SharingAuthView;
}
/**
 * Composes one snapshot from independently cached parts. The Hub state is cached until
 * a repository change bumps its revision, team-sharing views until the sharing state
 * changes or the sharing projection changes, and the authorization view until it is
 * explicitly refreshed or its background refresh completes. No part of this collaborator
 * reads Session history, and no snapshot call blocks on a stale authorization view.
 */
export declare class SnapshotAssembler {
    private readonly options;
    private stateCache;
    private revision;
    private sharingCache;
    private sharingKey;
    private authCache;
    private authAt;
    private authRefresh;
    private authRefreshGeneration;
    private authGeneration;
    private authQueue;
    constructor(options: SnapshotAssemblerOptions);
    /** The repository changed: recompute the state and bump its revision. */
    invalidateState(): void;
    /** The authorization surface changed outside a command; the next snapshot re-reads it. */
    invalidateAuth(): void;
    /** Only the publishing state changed. */
    invalidateSharing(): void;
    assemble(conversations: Record<string, ConversationFacts>, options?: {
        refreshAuth?: boolean;
        allowAuthRefresh?: boolean;
    }): Promise<SnapshotParts>;
    private auth;
    private refreshAuth;
}
//# sourceMappingURL=snapshot-assembler.d.ts.map