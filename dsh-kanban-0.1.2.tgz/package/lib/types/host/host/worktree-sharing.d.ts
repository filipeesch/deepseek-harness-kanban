import type { SessionTopologyPort } from '../shared/ports.js';
import type { Task } from '../shared/types.js';
export interface WorktreeOwnershipStore {
    locate(taskId: string): {
        task: Task;
    };
    allTasks(): Task[];
}
export interface WorktreeSharingOptions {
    /** The user explicitly consented to removing a shared checkout. */
    force?: boolean;
}
/**
 * Protects destructive worktree cleanup from targets used outside the task's
 * own conversation lineage. A task owns its retained conversations and their
 * native subagent descendants; forks and unrelated sessions stay foreign.
 * Every blocker is collected so a force consent can show the whole blast radius.
 */
export declare class WorktreeSharingGuard {
    private readonly store;
    private readonly sessions;
    constructor(store: WorktreeOwnershipStore, sessions: SessionTopologyPort);
    assertExclusive(taskId: string, target: string, options?: WorktreeSharingOptions): Promise<void>;
}
//# sourceMappingURL=worktree-sharing.d.ts.map