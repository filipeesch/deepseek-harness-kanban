import type { HubSharingView, HubState, SharingAuthStatus } from '../../shared/types.js';
import { type SharingComparison } from '../../domain/sharing/plan.js';
import type { SharedHubDocument } from '../../domain/sharing/document.js';
import type { ProviderDescription } from './provider.js';
import type { HubSharingRecord } from './state.js';
export declare function publishedDocument(record: HubSharingRecord): SharedHubDocument;
export declare function sharingComparison(record: HubSharingRecord, hub: HubState): SharingComparison;
export interface SharingViewContext {
    provider: ProviderDescription;
    authorization?: SharingAuthStatus;
    syncing?: boolean;
}
/** Project stored publishing state plus the current Hub into the snapshot view. */
export declare function buildSharingView(record: HubSharingRecord, hub: HubState, context: SharingViewContext): HubSharingView;
//# sourceMappingURL=view.d.ts.map