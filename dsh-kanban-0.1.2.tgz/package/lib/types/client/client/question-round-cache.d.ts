import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { Problem, QuestionFeedFrame, QuestionRound } from '../shared/types.js';
/** One conversation's supervised question projection. Opening returns its close handle. */
export interface QuestionFeedPort {
    open(sessionId: string, onFrame: (frame: QuestionFeedFrame) => void, onError: (problem: Problem) => void): () => void;
}
/** The host-owned dismissal command, kept separate so the cache does not know the transport. */
export interface QuestionDismissPort {
    dismiss(sessionId: string, roundId: string): Promise<readonly QuestionRound[]>;
}
export interface QuestionRoundView {
    rounds: readonly QuestionRound[];
    errors: ReadonlyMap<string, Problem>;
}
export interface QuestionRoundCacheOptions {
    feed: QuestionFeedPort;
    dismissal: QuestionDismissPort;
}
export declare class QuestionRoundCache {
    private readonly options;
    private readonly state;
    readonly view: HostObservable<QuestionRoundView>;
    private rounds;
    private errors;
    private readonly refs;
    private readonly closers;
    private readonly generations;
    private readonly dismissed;
    private readonly submitted;
    private focused;
    private disposed;
    constructor(options: QuestionRoundCacheOptions);
    /** Start tracking a conversation; each call returns its own idempotent release. */
    track(sessionId: string): () => void;
    /** Reopen a failed feed without dropping the rounds already shown; untracked sessions stay closed. */
    retry(sessionId: string): void;
    isSubmitted(roundId: string): boolean;
    /** The round a failed admission wants back on screen, ahead of newer rounds. */
    get focusedRoundId(): string | undefined;
    /** Mark a valid submission before admission settles; the feed confirms it later. */
    submit(roundId: string): void;
    /**
     * Mark the admission accepted. If the feed already dropped the round while the
     * admission was in flight, the drop is the confirmation; otherwise suppression
     * waits for an answered frame.
     */
    settle(roundId: string): void;
    /** Restore a round whose admission failed; its mounted form keeps the draft. */
    rollback(roundId: string): void;
    /** Dismiss the displayed round and every unresolved round in that conversation. */
    dismiss(sessionId: string, roundId: string): Promise<readonly QuestionRound[]>;
    dispose(): void;
    private open;
    private close;
    private apply;
    private fail;
    private publish;
}
//# sourceMappingURL=question-round-cache.d.ts.map