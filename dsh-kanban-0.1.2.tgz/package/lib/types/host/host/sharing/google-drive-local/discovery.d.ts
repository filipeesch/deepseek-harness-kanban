import type { DriveBrowseView, DriveDiscoveryView, DriveLocationView } from '../../../shared/types.js';
import type { DiscoveryFs } from './filesystem.js';
import type { DriveDiscoveryAdapter } from './platform.js';
export interface GoogleDriveLocalDiscoveryOptions {
    adapter: DriveDiscoveryAdapter;
    fs: DiscoveryFs;
    now?: () => number;
    cacheMs?: number;
    maxEntries?: number;
}
export interface LocatedDriveFolder {
    location: DriveLocationView;
    /** The canonical path, with symbolic links resolved. */
    path: string;
}
/**
 * Device-scoped discovery and browsing for Google Drive for desktop. It reads
 * local evidence only, caches the result briefly, and confines every listing to
 * a discovered location.
 */
export declare class GoogleDriveLocalDiscovery {
    private readonly options;
    private readonly now;
    private readonly cacheMs;
    private readonly maxEntries;
    private cached;
    constructor(options: GoogleDriveLocalDiscoveryOptions);
    get platform(): NodeJS.Platform;
    /** Path rules follow the discovered platform, not the host running the tests. */
    private get paths();
    roots(): Promise<DriveDiscoveryView>;
    /** Re-read every local source, bypassing the cache. */
    refresh(): Promise<DriveDiscoveryView>;
    /** The discovered location that contains a path, after resolving symbolic links. */
    locate(value: string): Promise<LocatedDriveFolder | undefined>;
    /**
     * List one folder level inside a discovered location. Only directories are
     * returned; nothing is written, and `..` or a symbolic link cannot escape the
     * location because the request is resolved first and compared against it.
     */
    browse(value: string): Promise<DriveBrowseView>;
    private projectMount;
    private listFailure;
}
//# sourceMappingURL=discovery.d.ts.map