import React from 'react';
import type { Attention, Column, Task, Workflow } from '../shared/types.js';
import type { AutoRunController, AutoRunInput } from './auto-run.js';
export interface BoardCardProps {
    task: Task;
    column: Column;
    projectName: string;
    attention: Attention;
    workflow: Workflow;
    selectionMode: boolean;
    selected: boolean;
    autoRun: AutoRunController;
    autoModePending: boolean;
    onToggleAutoMode: (taskId: string, enabled: boolean) => void;
    onOpen: (taskId: string) => void;
    onToggleSelect: (taskId: string) => void;
    onBeginDrag: (event: React.PointerEvent<HTMLElement>, taskId: string, columnId: string) => void;
    shouldSuppressClick: () => boolean;
    onRun?: (input: AutoRunInput) => void;
}
/**
 * One memoized board card. Every prop is either a stable reference or a scalar, so an
 * attention-only publication that leaves this task unchanged does not re-render it.
 * The auto-mode view is derived here instead of being passed as a fresh object.
 */
export declare const BoardCard: React.NamedExoticComponent<BoardCardProps>;
//# sourceMappingURL=board-card.d.ts.map