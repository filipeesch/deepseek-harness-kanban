import React, { type ReactNode } from 'react';
import type { ClientApi, Column, ColumnGroup, Workflow } from '../shared/types.js';
import type { DirectoryPickerPort } from './directory-picker.js';
import type { SessionTitles } from './conversation-label.js';
import type { ConversationLeaseEnvironment } from './conversation-leases.js';
import type { ConversationLineagePort, DrawerSubagentAddress } from './conversation-navigation.js';
import { AutoRunController } from './auto-run.js';
import type { PreparationSeat } from './execution-preparation/model-seat.js';
import { type BoardPageState } from './page-state.js';
export { createBoardPageState } from './page-state.js';
export type { BoardPageState } from './page-state.js';
export interface BoardViewProps {
    api: ClientApi;
    renderConversation: (id: string, target?: DrawerSubagentAddress) => ReactNode;
    pageState?: BoardPageState;
    sessionTitles?: SessionTitles;
    /** Lease scope owned by each mounted task drawer; absent only in isolated render harnesses. */
    conversationLeases?: ConversationLeaseEnvironment;
    picker?: DirectoryPickerPort | null;
    /** Owned by its provider, which also reconciles it; the board reconciles only its own fallback. */
    autoRun?: AutoRunController;
    lineage?: ConversationLineagePort;
    /** Native slots and locale used by the first-execution model stage; absent in isolated harnesses. */
    nativeSeat?: PreparationSeat;
}
export declare function columnLayout(workflow: Workflow): Array<{
    key: string;
    group?: ColumnGroup;
    columns: Column[];
}>;
export declare function BoardView({ api, renderConversation, pageState, sessionTitles, conversationLeases, picker, autoRun: providedAutoRun, lineage, nativeSeat }: BoardViewProps): React.JSX.Element;
//# sourceMappingURL=board.d.ts.map