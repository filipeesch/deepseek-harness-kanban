import React from 'react';
import type { BoardState, Task } from '../../shared/types.js';
import { type TaskPageState } from '../page-state.js';
import type { RunCommand } from '../ui.js';
export declare function NotesPanel({ task, state, run, viewState }: {
    task: Task;
    state: BoardState;
    run: RunCommand;
    viewState?: TaskPageState;
}): React.JSX.Element;
//# sourceMappingURL=notes-panel.d.ts.map