import { rename } from 'node:fs/promises';
import { type SharedHubDocument } from '../../domain/sharing/document.js';
import type { SharedConfigStore, SharedDocumentSnapshot, StorageReview } from './store.js';
/** Directory state persisted beside the binding: the observation of the bytes last read. */
export declare function normalizeDirectoryState(state: Record<string, unknown>): Record<string, unknown>;
export interface DirectoryStoreOptions {
    directory: string;
    state: Record<string, unknown>;
    /** Test seam: the rename primitive, its backoff clock, and the document reader. */
    renameFile?: typeof rename;
    delay?: (ms: number) => Promise<void>;
    readDocument?: (file: string) => Promise<string>;
}
/**
 * One Hub document in a directory that the user synchronizes with a desktop
 * client. It owns the whole-document read/write contract, the change
 * observation, and the conflict-copy review; it never touches another file.
 */
export declare class DirectorySharedConfigStore implements SharedConfigStore {
    private readonly options;
    private readonly stateValue;
    private readonly renameFile;
    private readonly delay;
    private readonly readDocument;
    private reviewValue;
    private ready;
    constructor(options: DirectoryStoreOptions);
    protected get directory(): string;
    private get documentPath();
    state(): Record<string, unknown>;
    review(): StorageReview | null;
    ensure(): Promise<void>;
    private prepare;
    private detectConflictCopies;
    /** The document's current observation, or null when there is no document. */
    private observe;
    private unchanged;
    /**
     * Remember the observation of the bytes that were just read. A remembered
     * observation is what lets the next check skip reading; remembering one that
     * describes a different version would make the cache authoritative for
     * content it never contained.
     */
    private remember;
    private forget;
    /**
     * Read the document together with the observation that describes exactly
     * those bytes. The observation is taken before and after the read; when the
     * two differ another writer replaced the file during the read, and the bytes
     * cannot be paired with any observation.
     */
    private readObserved;
    /**
     * The token of the document on disk, used only to decide whether a write may
     * proceed. It deliberately records no observation: the remembered
     * observation must keep describing the last document the caller received, so
     * that a refused write is followed by a real read instead of a cached one.
     */
    private currentToken;
    read(signal?: AbortSignal, cached?: SharedDocumentSnapshot | null): Promise<SharedDocumentSnapshot | null>;
    write(document: SharedHubDocument, options: {
        expectedToken: string | null;
        message: string;
    }, signal?: AbortSignal): Promise<{
        token: string;
    }>;
    /** Replace the document through a temporary sibling so no reader sees a partial file. */
    private replace;
    /** A sync client, an antivirus, or an indexer can hold the file briefly. */
    private renameWithRetry;
    /**
     * Verify what is on disk after a write. The document was replaced during the
     * verification when the observation does not describe the bytes read, so
     * neither an unstable read nor a missing document can be reported as success.
     */
    private verify;
    destroy(): Promise<void>;
}
//# sourceMappingURL=directory-store.d.ts.map