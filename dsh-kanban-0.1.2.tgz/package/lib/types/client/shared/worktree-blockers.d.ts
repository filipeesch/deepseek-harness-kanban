import type { Problem } from './types.js';
/** One party that blocks destructive cleanup of a checkout. */
export type SharedWorktreeBlocker = {
    kind: 'task';
    taskId: string;
    title: string;
    path: string;
} | {
    kind: 'session';
    sessionId: string;
    path: string;
};
/**
 * Reads every sharing blocker from a `SHARED_WORKTREE` problem. Operations
 * recorded before blockers were collected carry only the legacy single
 * `taskId` or `sessionId` detail, which stays readable as one blocker.
 */
export declare function sharedWorktreeBlockers(problem: Problem | null | undefined): SharedWorktreeBlocker[];
/** True when a failed operation can offer the consented force action. */
export declare function canForceSharedRemoval(problem: Problem | null | undefined): boolean;
//# sourceMappingURL=worktree-blockers.d.ts.map