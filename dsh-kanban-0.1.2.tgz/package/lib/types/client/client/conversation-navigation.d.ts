import React, { type ReactNode } from 'react';
import type { Task } from '../shared/types.js';
/** Structural copy of the native direct-parent subagent address. */
export interface DrawerSubagentAddress {
    readonly parentSessionId: string;
    readonly childSessionId: string;
    readonly mode: 'one-shot' | 'continuable' | 'unknown';
}
export interface ConversationNavigation {
    /** Select a task root or peek an owned subagent ancestor. */
    openSession(sessionId: string): boolean;
    /** Peek a child selected by the native lineage or catalog. */
    openSubagent(address: DrawerSubagentAddress): boolean;
}
export declare function ConversationNavigationProvider({ value, children }: {
    value: ConversationNavigation;
    children: ReactNode;
}): React.JSX.Element;
export declare function useConversationNavigation(): ConversationNavigation;
/** The session list shape needed for native subagent lineage checks. */
export interface ConversationSessionRow {
    readonly origin?: 'subagent';
    readonly parentId?: string;
}
export interface ConversationSessionList {
    readonly byId: Readonly<Record<string, ConversationSessionRow | undefined>>;
}
/** Follow native subagent edges only; roots, forks, missing rows, and cycles fail closed. */
export declare function isOwnedSubagent(sessions: ConversationSessionList, rootSessionIds: readonly string[], sessionId: string): boolean;
/** Small adapter the drawer and tests use to resolve and validate subagent targets. */
export interface ConversationLineagePort {
    subagentAddress(sessionId: string): DrawerSubagentAddress | undefined;
    isOwnedDescendant(rootSessionIds: readonly string[], sessionId: string): boolean;
}
export declare function createConversationNavigation(options: {
    task: Task;
    selectRoot(sessionId: string): void;
    setPeek(address: DrawerSubagentAddress | null): void;
    lineage?: ConversationLineagePort;
}): ConversationNavigation;
//# sourceMappingURL=conversation-navigation.d.ts.map